//
// Created by yaozhuo on 2023/2/17.
//

#ifndef FREENAV_BRIDGE_3D_H
#define FREENAV_BRIDGE_3D_H

#include "map.h"
#include "mission.h"
#include "rim_jump/online_search/search_path_with_edge.h"

namespace fr = freeNav::RimJump;

struct MyMap : public Map
{
    MyMap(freeNav::RimJump::DimensionLength* dimension_info,
             freeNav::RimJump::IS_OCCUPIED_FUNC<3> is_occupied,
             freeNav::RimJump::SET_OCCUPIED_FUNC<3> set_occupied
             ) {

        altitude = dimension_info[2];
        height = dimension_info[1];
        width = dimension_info[0];

        min_altitude_limit = 0;
        max_altitude_limit = dimension_info[2] - 1;

        is_occupied_ = is_occupied;
        set_occupied_ = set_occupied;

    }

    void setStartAndTarget(const fr::Pointi<3>& start, const fr::Pointi<3>& target) {
        start_h = start[2];
        start_i = start[1];
        start_j = start[0];

        goal_h = target[2];
        goal_i = target[1];
        goal_j = target[0];
    }

    int getValue(int i, int j) const {
        //
    }

    bool CellIsObstacle(int i, int j, int h) const override {
        freeNav::RimJump::Pointi<3> pt;
        pt[0] = i, pt[1] = j, pt[2] = h;
        return is_occupied_(pt);
    }


    fr::Pointi<3> ToRimJumpPointi(int x, int y, int z) const {
        fr::Pointi<3> pt;
        pt[0] = x;
        pt[1] = y;
        pt[2] = z;
        return pt;
    }

    fr::DimensionLength* dimension_info_;
    fr::IS_OCCUPIED_FUNC<3> is_occupied_;
    fr::SET_OCCUPIED_FUNC<3> set_occupied_;


};


fr::Path<3> ToRimJumpPath(const SearchResult& sr);


fr::Path<3> AstarThetaStar_3D(MyMap& map,
                              const fr::Pointi<3>& start, const fr::Pointi<3>& target,
                              int planner_type = CN_SP_ST_DIJK);


#endif //FREENAV_BRIDGE_3D_H
