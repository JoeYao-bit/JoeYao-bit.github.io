#include "tileadaptor.h"
#include <iostream>
#include "rim_jump/online_search/search_path_with_edge.h"

namespace fr = freeNav::RimJump;

// the raw LazyTheta
int LazyTheta();

// after wrapper
fr::Path<2> LazyThetaWrap(const std::vector<std::vector<char> > &map, const fr::Pointi<2>& startPoint, const fr::Pointi<2>& endPoint);

fr::Path<2> ToRimJumpPath(const std::vector<Vectori>& pathraw);

std::vector<std::vector<char> > getLazyThetaMap(freeNav::RimJump::DimensionLength* dimension_info,
                                                freeNav::RimJump::IS_OCCUPIED_FUNC<2> is_occupied);
