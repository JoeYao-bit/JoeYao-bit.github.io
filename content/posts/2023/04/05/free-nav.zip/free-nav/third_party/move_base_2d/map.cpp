#include "map.h"
//
//IntMap::IntMap()
//{
//    height = -1;
//    width = -1;
//    start_i = -1;
//    start_j = -1;
//    goal_i = -1;
//    goal_j = -1;
//    grid = nullptr;
//    cellSize = 1;
//}
//
//IntMap::~IntMap()
//{
//    if (grid) {
//        for (int i = 0; i < height; ++i)
//            delete[] grid[i];
//        delete[] grid;
//    }
//}
//
//bool IntMap::CellIsTraversable(int i, int j) const
//{
//    return (grid[i][j] == CN_GC_NOOBS);
//}
//
//bool IntMap::CellIsObstacle(int i, int j) const
//{
//    return (grid[i][j] != CN_GC_NOOBS);
//}
//
//bool IntMap::CellOnGrid(int i, int j) const
//{
//    return (i < height && i >= 0 && j < width && j >= 0);
//}
//
//int IntMap::getValue(int i, int j) const
//{
//    if (i < 0 || i >= height)
//        return -1;
//
//    if (j < 0 || j >= width)
//        return -1;
//
//    return grid[i][j];
//}
