/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, 2013, Willow Garage, Inc.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Author: Eitan Marder-Eppstein
 *         David V. Lu!!
 *********************************************************************/

#ifndef MY_CORE
#define MY_CORE
#include <sys/time.h>
#include <math.h>

#include "astar.h"
#include "dijkstra.h"


#define lethal_cost_  253
using namespace std;
using namespace global_planner;
//using namespace RimJump;
extern int xs,ys; 
typedef std::vector<std::pair<float, float> > FloatPath;
bool getPath(float *potential, double start_x, double start_y, double end_x, double end_y, FloatPath &path);
bool getPathG(float* potential, double start_x, double start_y, double goal_x, double goal_y, FloatPath& path);
float gradCell(float* potential, int n);
int getIndex(double x, double y);
void outlineMap(unsigned char *costarr, int nx, int ny, unsigned char value);
float getPathLen(FloatPath &path);
void ShowPath(FloatPath & path);
FloatPath DijkstraPlanner(unsigned char *costs2, const int & sx, const int & sy, const int & ex, const int & ey, int xs_, int ys_);
FloatPath AstarPlanner(unsigned char *costs2, const int & sx, const int & sy, const int & ex, const int & ey, int xs_, int ys_);
//FloatPath ThetaPlanner(unsigned char *costs2, const int & sx, const int & sy, const int & ex, const int & ey, int xs_, int ys_);
#endif
