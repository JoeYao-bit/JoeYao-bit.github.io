#include "bridge_2d.h"

#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/geometric/SimpleSetup.h>
#include <ompl/geometric/planners/rrt/RRTstar.h>
#include <ompl/geometric/planners/rrt/RRTConnect.h>
#include <ompl/util/PPM.h>

#include <ompl/config.h>
#include <iostream>

using namespace freeNav::RimJump;

void getMap(unsigned char * cost,
            freeNav::RimJump::DimensionLength* dimension_info,
            freeNav::RimJump::IS_OCCUPIED_FUNC<2> is_occupied,
            freeNav::RimJump::SET_OCCUPIED_FUNC<2> set_occupied)
{
    Pointi<2> pt;
    for(int i=1; i<dimension_info[0]+1; i++) {
        pt[0] = i - 1;
        for(int j=1; j<dimension_info[1]+1; j++) {
            pt[1] = j - 1;
            if(is_occupied(pt)){
                cost[j*(dimension_info[0]+2) + i]=254;
            } else {
                cost[j*(dimension_info[0]+2) + i]=40;
            }
        }
    }
}

Path<2> DijkstraPlanner2(freeNav::RimJump::DimensionLength* dimension_info,
                         freeNav::RimJump::IS_OCCUPIED_FUNC<2> is_occupied,
                         freeNav::RimJump::SET_OCCUPIED_FUNC<2> set_occupied,
                         freeNav::RimJump::Pointi<2>& start,
                         freeNav::RimJump::Pointi<2>& target) {
    // reserve space for outline function
    unsigned char* cost = new unsigned char[(dimension_info[0]+2)*(dimension_info[1]+2)];
    getMap(cost, dimension_info, is_occupied, set_occupied);
    FloatPath path = DijkstraPlanner(cost, start[0], start[1], target[0], target[1],
            dimension_info[0], dimension_info[1]);
    delete[] cost;
    return ToRimJumpPath(path);
}

Path<2> AstarPlanner2(freeNav::RimJump::DimensionLength* dimension_info,
                      freeNav::RimJump::IS_OCCUPIED_FUNC<2> is_occupied,
                      freeNav::RimJump::SET_OCCUPIED_FUNC<2> set_occupied,
                      freeNav::RimJump::Pointi<2>& start,
                      freeNav::RimJump::Pointi<2>& target) {
    unsigned char* cost = new unsigned char[(dimension_info[0]+2)*(dimension_info[1]+2)];
    getMap(cost,  dimension_info, is_occupied, set_occupied);
    FloatPath path = AstarPlanner(cost, start[0], start[1], target[0], target[1],
            dimension_info[0], dimension_info[1]);
    delete[] cost;
    return ToRimJumpPath(path);
}

Path<2> ToRimJumpPath(const FloatPath& fp) {
    Path<2> path;
    Pointi<2> pt(2);
    for(int i=0; i<fp.size(); i++) {
        pt[0] = fp[i].first;
        pt[1] = fp[i].second;
        path.push_back(pt);
    }
    return path;
}
