//
// Created by yaozhuo on 2023/1/28.
//

#ifndef FREENAV_SAMPLING_PATH_PLANNING_H
#define FREENAV_SAMPLING_PATH_PLANNING_H

/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2013, Rice University
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the Rice University nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************/

/* Author: Ioan Sucan */

#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/geometric/SimpleSetup.h>
#include <ompl/geometric/planners/rrt/RRTstar.h>
#include <ompl/geometric/planners/rrt/RRTConnect.h>
#include <ompl/geometric/planners/rrt/InformedRRTstar.h>
#include <ompl/geometric/planners/rrt/LBTRRT.h>
#include <ompl/geometric/planners/rrt/STRRTstar.h>
#include <ompl/geometric/planners/prm/PRMstar.h>
#include <ompl/geometric/planners/prm/LazyPRMstar.h>
#include <ompl/util/PPM.h>
#include <ompl/base/samplers/DeterministicStateSampler.h>
#include <ompl/base/samplers/deterministic/HaltonSequence.h>
#include <ompl/config.h>


#include <boost/filesystem.hpp>
#include <iostream>

namespace ob = ompl::base;
namespace og = ompl::geometric;

#include "rim_jump/online_search/search_path_with_edge.h"

namespace fr = freeNav::RimJump;

/* interfaces for various sampling based path planning */
template <class PlannerType, fr::Dimension N>
class SamplingPlannerEnvironment
{


public:
    SamplingPlannerEnvironment(freeNav::RimJump::DimensionLength* dimension_info,
                               freeNav::RimJump::IS_OCCUPIED_FUNC<N> is_occupied,
                               freeNav::RimJump::SET_OCCUPIED_FUNC<N> set_occupied,
                               int repeat_times = 5,
                               bool use_deterministic_sampling = true)
    {
        bool ok = true;//false;
        useDeterministicSampling_ = use_deterministic_sampling;

        dimension_info_ = dimension_info;
        is_occupied_ = is_occupied;
        set_occupied_ = set_occupied;
        repeat_times_ = repeat_times;
        if (ok)
        {
            auto space(std::make_shared<ob::RealVectorStateSpace>());

            for(int i=0; i<N; i++) {
                space->addDimension(0.0, dimension_info[i]);
            }
//            maxWidth_  = dimension_info[0] - 1;//ppm_.getWidth() - 1;
//            maxHeight_ = dimension_info[1] - 1;//ppm_.getHeight() - 1;
            ss_ = std::make_shared<og::SimpleSetup>(space);
            //OMPL_INFORM("sas");
            ompl::msg::setLogLevel(ompl::msg::LOG_WARN);
            // set state validity checking for this space
            ss_->setStateValidityChecker([this](const ob::State *state) { return isStateValid(state); });
            space->setup();
            ss_->getSpaceInformation()->setStateValidityCheckingResolution(1.0 / space->getMaximumExtent());

            // set the deterministic sampler
            // 2D space, no need to specify bases specifically
            if (useDeterministicSampling_)
            {
                // PRMstar can use the deterministic sampling
                //ss_->setPlanner(std::make_shared<og::PRMstar>(ss_->getSpaceInformation()));
                ss_->setPlanner(std::make_shared<PlannerType>(ss_->getSpaceInformation()));
                space->setStateSamplerAllocator(std::bind(&SamplingPlannerEnvironment::allocateHaltonStateSamplerRealVector,
                                                          this, std::placeholders::_1, N
                                                          ,std::vector<unsigned int>(N, 3)
                                                          //,std::vector<unsigned int>{N, 3}
                                                          ));
                ss_->setup();
            }
        }
    }

    freeNav::RimJump::Path<N> plan(fr::Pointi<N> start_pt, fr::Pointi<N> goal_pt)
    {
        if (!ss_)
            return {};
        ob::ScopedState<> start(ss_->getStateSpace());
        for(int i=0; i<N; i++) {
            start[i] = start_pt[i];
        }
        ob::ScopedState<> goal(ss_->getStateSpace());
        for(int i=0; i<N; i++) {
            goal[i] = goal_pt[i];
        }
        ss_->setStartAndGoalStates(start, goal);
        // generate a few solutions; all will be added to the goal;
        for (int i = 0; i < repeat_times_; ++i)
        {
            if (ss_->getPlanner())
                ss_->getPlanner()->clear();
            ss_->solve();
        }
        const std::size_t ns = ss_->getProblemDefinition()->getSolutionCount();
        OMPL_INFORM("Found %d solutions", (int)ns);
        freeNav::RimJump::Path<N> retv;
        if (ss_->haveSolutionPath())
        {
            if (!useDeterministicSampling_)
                ss_->simplifySolution();

            og::PathGeometric &p = ss_->getSolutionPath();
            if (!useDeterministicSampling_)
            {
                ss_->getPathSimplifier()->simplifyMax(p);
                ss_->getPathSimplifier()->smoothBSpline(p);
            }

            //og::PathGeometric &p = ss_->getSolutionPath();
            p.interpolate();
            for (std::size_t i = 0; i < p.getStateCount(); ++i)
            {
                //const int w = std::min(dimension_info_[0]-1, (int)p.getState(i)->as<ob::RealVectorStateSpace::StateType>()->values[0]);
                //const int h = std::min(dimension_info_[1]-1, (int)p.getState(i)->as<ob::RealVectorStateSpace::StateType>()->values[1]);

                freeNav::RimJump::Pointi<N> pt;
                for(int j=0; j<N; j++)
                {
                    pt[j] = std::min(dimension_info_[j]-1, (int)p.getState(i)->as<ob::RealVectorStateSpace::StateType>()->values[j]);
                }
                retv.push_back(pt);
            }
            return retv;
        }
        return {};
    }

    void save(const char *filename)
    {
        if (!ss_)
            return;
        //ppm_.saveFile(filename);
    }

private:
    bool isStateValid(const ob::State *state) const
    {
        freeNav::RimJump::Pointi<N> pt;
        for(int i=0; i<N; i++)
        {
            pt[i] = std::min((int)state->as<ob::RealVectorStateSpace::StateType>()->values[i], dimension_info_[i] - 1);
        }
        return !is_occupied_(pt);
    }

    ob::StateSamplerPtr allocateHaltonStateSamplerRealVector(const ompl::base::StateSpace *space, unsigned int dim,
                                                             std::vector<unsigned int> bases = {})
    {
        // specify which deterministic sequence to use, here: HaltonSequence
        // optionally we can specify the bases used for generation (otherwise first dim prime numbers are used)
//        if (bases.size() != 0)
//            return std::make_shared<ompl::base::RealVectorDeterministicStateSampler>(
//                    space, std::make_shared<ompl::base::HaltonSequence>(bases.size(), bases));
//        else
            return std::make_shared<ompl::base::RealVectorDeterministicStateSampler>(
                    space, std::make_shared<ompl::base::HaltonSequence>(dim));
    }

    og::SimpleSetupPtr ss_;
    //int maxWidth_;
    //int maxHeight_;
    //ompl::PPM ppm_;
    bool useDeterministicSampling_;

    freeNav::RimJump::DimensionLength* dimension_info_;
    freeNav::RimJump::IS_OCCUPIED_FUNC<N> is_occupied_;
    freeNav::RimJump::SET_OCCUPIED_FUNC<N> set_occupied_;

    int repeat_times_ = 10;

};

#endif //FREENAV_SAMPLING_PATH_PLANNING_H
