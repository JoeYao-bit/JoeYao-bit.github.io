//
// Created by yaozhuo on 2023/2/17.
//

#include "bridge_3d.h"

fr::Path<3> AstarThetaStar_3D(MyMap& map,
                              const fr::Pointi<3>& start, const fr::Pointi<3>& target,
                              int planner_type ) {

        Mission mission;

        map.start_i = start[0];
        map.start_j = start[1];
        map.start_h = start[2];


        map.goal_i = target[0];
        map.goal_j = target[1];
        map.goal_h = target[2];

        mission.map = &map;

        /****set config from RimJump****/
        mission.config.SearchParams = new double[11];

        mission.config.SearchParams[CN_SP_ST] = planner_type;

        mission.config.SearchParams[CN_SP_AD] = 0.; //AllowDiagonal

        mission.config.SearchParams[CN_SP_AC] = 0.; //CutCorners

        mission.config.SearchParams[CN_SP_AS] = 0.; //AllowSqueeze

        mission.config.SearchParams[CN_SP_MT] = CN_SP_MT_MANH; //MetricType

        mission.config.SearchParams[CN_SP_BT] = CN_SP_BT_GMAX;

        mission.config.SearchParams[CN_SP_LC] = CN_MC_LINE;

        mission.config.SearchParams[CN_SP_DC] = CN_MC_LINE*sqrt(2);

        mission.config.SearchParams[CN_SP_HW] = 1;

        mission.config.SearchParams[CN_SP_SL] = CN_SP_SL_NOLIMIT;

        //std::cout<<"-*-*- Dijkstra : Config Setted" << std::endl;

        mission.createEnvironmentOptions();
        mission.createSearch();

        //std::cout<<"-*-*- Dijkstra : Ready for Search" << std::endl;

        mission.startSearch();

        //mission.printSearchResultsToConsole();

        delete[] mission.config.SearchParams;

        return ToRimJumpPath(mission.sr);
}

fr::Path<3> ToRimJumpPath(const SearchResult& sr) {
    fr::Path<3> path;
    if(!sr.pathfound) return {};
    if(sr.lppath->List.size()==0) return path;
    std::list<Node>::const_iterator iter = sr.lppath->List.begin();
    fr::Pointi<3> pt;
    while (iter != sr.lppath->List.end()) {
        pt[0] = iter->i;
        pt[1] = iter->j;
        pt[2] = iter->z;
        path.push_back(pt);
        //std::cout << " (" << pt[0] << ", " << pt[1] << ", " << pt[2] << ")" << std::endl;
        ++iter;
    }
    return path;
}