#ifndef BRIDGE_2D
#define BRIDGE_2D
/*
A Bridge that Conects RimJump* and other 2D path plannning algorithms' implementations
*/

#include "rim_jump/basic_elements/point.h"

#include "my_core.h"
#include "map.h"

/***** Dijkstra and A* from move_base@ROS *******/

freeNav::RimJump::Path<2> DijkstraPlanner2(freeNav::RimJump::DimensionLength* dimension_info,
                                           freeNav::RimJump::IS_OCCUPIED_FUNC<2> is_occupied,
                                           freeNav::RimJump::SET_OCCUPIED_FUNC<2> set_occupied,
                                           freeNav::RimJump::Pointi<2>& start,
                                           freeNav::RimJump::Pointi<2>& target);

freeNav::RimJump::Path<2> AstarPlanner2(freeNav::RimJump::DimensionLength* dimension_info,
                                        freeNav::RimJump::IS_OCCUPIED_FUNC<2> is_occupied,
                                        freeNav::RimJump::SET_OCCUPIED_FUNC<2> set_occupied,
                                        freeNav::RimJump::Pointi<2>& start,
                                        freeNav::RimJump::Pointi<2>& target);

void getMap(unsigned char * cost,
            freeNav::RimJump::DimensionLength* dimension_info,
            freeNav::RimJump::IS_OCCUPIED_FUNC<2> is_occupied,
            freeNav::RimJump::SET_OCCUPIED_FUNC<2> set_occupied);

freeNav::RimJump::Path<2> ToRimJumpPath(const FloatPath& fp);

//RimJump::Path RRTPlanner2(RimJump::RimJump2D &planner_2d); // with out smooth, raw RRT

/***** ThetaStar from mixr26@GitHub **********/

//RimJump::Path ThetaPlanner2(const RimJump::RimJump2D& planner_2d);


//TODO
/***** LazyTheta* from lapinozz@GitHub *****/
//RimJump::Path LazyThetaPlanner1(const RimJump::RimJump2D& planner_2d);

//TODO
/***** Sampling-based Motion Planning (SMP) from Sertac Karaman @MIT  *****/

//TODO
/***** RRT(*) Library from Sertac Karaman @MIT  *****/

#endif
