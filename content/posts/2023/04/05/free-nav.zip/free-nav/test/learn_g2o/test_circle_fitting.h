//
// Created by yaozhuo on 2021/9/21.
//

#ifndef FREENAV_TEST_CIRCLE_FITTING_H
#define FREENAV_TEST_CIRCLE_FITTING_H

#include <Eigen/Core>
#include <iostream>

#include "g2o/stuff/sampler.h"
#include "g2o/stuff/command_args.h"
#include "g2o/core/sparse_optimizer.h"
#include "g2o/core/block_solver.h"
#include "g2o/core/solver.h"
#include "g2o/core/optimization_algorithm_levenberg.h"
#include "g2o/core/base_vertex.h"
#include "g2o/core/base_unary_edge.h"
#include "g2o/solvers/dense/linear_solver_dense.h"



#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/StdVector>
using namespace std;

class CircleVertex : public g2o::BaseVertex<3, Eigen::Vector3d> {
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW;
    CircleVertex()
    {
    }

    virtual bool read(std::istream& /*is*/)
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }

    virtual bool write(std::ostream& /*os*/) const
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }

    virtual void setToOriginImpl()
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
    }

    virtual void oplusImpl(const double* update)
    {
        Eigen::Vector3d::ConstMapType v(update);
        _estimate += v;
    }

};

class CircleEdge : public g2o::BaseUnaryEdge<1, Eigen::Vector2d, CircleVertex>
{
public:
    /*
     *  在生成定长的Matrix或Vector对象时，需要开辟内存，调用默认构造函数，
     *  通常x86下的指针是32位，内存位数没对齐就会导致程序运行出错。
     *  而对于动态变量(例如Eigen::VectorXd)会动态分配内存，因此会自动地进行内存对齐。
     */
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    CircleEdge()
    {
    }
    virtual bool read(std::istream& /*is*/)
    {
        /* C语言中获取函数名，一般是__func__,GCC还支持__FUNCTION__.
         * 同时，__PRETTY_FUNCTION__对函数的打印会带上参数。
         */
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }
    virtual bool write(std::ostream& /*os*/) const
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }

    void computeError()
    {
        const CircleVertex* params = static_cast<const CircleVertex*>(vertex(0));
        const double& c_x    = params->estimate()(0);
        const double& c_y    = params->estimate()(1);
        const double& radius = params->estimate()(2);
        double fval = fabs(sqrt(pow(c_x - measurement()[0], 2) + pow(c_y - measurement()[1], 2)) - radius);
        _error(0) = fval;
    }
};

#endif //FREENAV_TEST_CIRCLE_FITTING_H
