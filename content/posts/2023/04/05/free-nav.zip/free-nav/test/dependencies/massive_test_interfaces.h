//
// Created by yaozhuo on 2022/11/26.
//

#ifndef FREENAV_MASSIVE_TEST_INTERFACES_H
#define FREENAV_MASSIVE_TEST_INTERFACES_H
#include <istream>
#include <fstream>
#include "rim_jump/online_search/search_path_with_edge.h"
#include "path_planning_interface.h"
#include "ScenarioLoader2D.h"
#include "ScenarioLoader3D.h"
#include <iomanip>
/*
 * there is only ONE map in one scene file,
 * store start and target coordinates, and minimum result path length
 * */

namespace freeNav::RimJump {

    template <freeNav::RimJump::Dimension N>
    using SingleMapTestConfig = std::map<std::string, std::string>;

    template <freeNav::RimJump::Dimension N>
    using SingleMapTestConfigs = std::vector<SingleMapTestConfig<N> >;

    // for 2d grid map data set from https://www.movingai.com/benchmarks/grids.html
    bool SceneTest2D(const std::string &config_file_path,
                     const Point2PointPathPlannings<2, freeNav::RimJump::Pointi<2>, freeNav::RimJump::Pointi<2>> &p2p_plan_test,
                     StatisticSS &statisticss,
                     OutputStreamSS &output_streamss,
                     int max_count_of_case = 20000) {

        statisticss.clear();
        output_streamss.clear();
        ScenarioLoader2D sl(config_file_path.c_str());
        int count_of_experiments = sl.GetNumExperiments();
        std::cout << "get " << count_of_experiments << " 2d experiments" << std::endl;
        if (count_of_experiments <= 0) return false;

        struct timezone tz;
        struct timeval tvpre;
        struct timeval tvafter;
        gettimeofday (&tvpre , &tz);

        // load experiment data
        for (int i = 0; i < std::min(max_count_of_case, count_of_experiments); i++) {
            const auto &experiment = sl.GetNthExperiment(i);
            int sx = experiment.GetGoalX(), sy = experiment.GetGoalY(), gx = experiment.GetStartX(), gy = experiment.GetStartY();
            double length = experiment.GetDistance();
            // do test
            StatisticS statistics;
            OutputStreamS output_streams;
            freeNav::RimJump::Pointi<2> start, target;
            start[0] = sx, start[1] = sy, target[0] = gx, target[1] = gy;
            //std::cout << "index " << i << ": (" << sx << ", " << sy << ") -> (" << gx << ", " << gy << "), shortest length = " << length << std::endl;
            if (!Point2PointPathPlanningTest<2, freeNav::RimJump::Pointi<2>, freeNav::RimJump::Pointi<2> >(start,
                                                                                                           target,
                                                                                                           p2p_plan_test,
                                                                                                           statistics,
                                                                                                           output_streams)) {
                std::cout << "failed index " << i << ": (" << sx << ", " << sy << ") -> (" << gx << ", " << gy
                          << "), shortest length = " << length << std::endl;
            }
//            if (i % 100 == 0) {
//                std::cout << "finish " << i << " cases " << std::endl;
//            }
            gettimeofday (&tvafter , &tz);
            double time_interval = (tvafter.tv_sec-tvpre.tv_sec)+(tvafter.tv_usec-tvpre.tv_usec)/10e6;
            if(time_interval > .1) {
                std::cout << " finish :  " << i << " cases " << std::endl;
                gettimeofday (&tvpre , &tz);
            }
            // print after one second
//            if(statistics[0].front() > length + EPS_FR) {
//                std::cout << "index " << i << ": (" << sx << ", " << sy << ") -> (" << gx << ", " << gy << "), shortest length = " << length << std::endl;
//                std::cout << "statistics[0].front() > length : " << statistics[0].front() << " > " << length << std::endl;
//            }
            for (auto &statistic : statistics) {
                statistic.push_back(length);
            }
            for (auto &output_stream : output_streams) {
                std::stringstream sst;
                sst << output_stream << length;
                output_stream = sst.str();
            }
            statisticss.push_back(statistics);
            output_streamss.push_back(output_streams);
        }
        std::cout << " finish " <<  std::min(max_count_of_case, count_of_experiments) << " cases" << std::endl;
        return true;
    }

    // for 2d grid map data set from https://www.movingai.com/benchmarks/grids.html
    bool SceneTest2DIndividual(const std::string &config_file_path,
                               const Point2PointPathPlannings<2, freeNav::RimJump::Pointi<2>, freeNav::RimJump::Pointi<2>> &p2p_plan_tests,
                               StatisticSS &statisticss,
                               OutputStreamSS &output_streamss,
                               int max_count_of_case = 20000) {

        statisticss.clear();
        output_streamss.clear();
        ScenarioLoader2D sl(config_file_path.c_str());
        int count_of_experiments = sl.GetNumExperiments();
        std::cout << "get " << count_of_experiments << " 2d experiments" << std::endl;
        if (count_of_experiments <= 0) return false;



        for(const auto& method : p2p_plan_tests) {

            // load experiment data
            for (int i = 0; i < std::min(max_count_of_case, count_of_experiments); i++) {
                const auto &experiment = sl.GetNthExperiment(i);
                int sx = experiment.GetGoalX(), sy = experiment.GetGoalY(), gx = experiment.GetStartX(), gy = experiment.GetStartY();
                double length = experiment.GetDistance();
                for(int j=0; j<10; j++) {
                    // do test
                    StatisticS statistics;
                    OutputStreamS output_streams;
                    freeNav::RimJump::Pointi<2> start, target;
                    start[0] = sx, start[1] = sy, target[0] = gx, target[1] = gy;
                    //std::cout << "index " << i << ": (" << sx << ", " << sy << ") -> (" << gx << ", " << gy << "), shortest length = " << length << std::endl;
                    if (!SinglePoint2PointPathPlanningTest<2, freeNav::RimJump::Pointi<2>, freeNav::RimJump::Pointi<2> >(
                            start, target, method,
                            statistics, output_streams)) {
                        std::cout << "failed index " << i << ": (" << sx << ", " << sy << ") -> (" << gx << ", " << gy
                                  << "), shortest length = " << length << std::endl;
                    }
                    if (i % 100 == 0) {
                        std::cout << "finish " << i << " cases " << std::endl;
                    }
                    for (auto &statistic : statistics) {
                        statistic.push_back(length);
                    }
                    for (auto &output_stream : output_streams) {
                        std::stringstream sst;
                        sst << output_stream << length;
                        output_stream = sst.str();
                    }
                    statisticss.push_back(statistics);
                    output_streamss.push_back(output_streams);
                    if(i%1000 == 0) {
                        statisticss.shrink_to_fit();
                        output_streamss.shrink_to_fit();
                    }
                }
            }

        }
        return true;
    }

    // for 3d voxel map data set from https://www.movingai.com/benchmarks/voxels.html
    bool SceneTest3D(const std::string &config_file_path,
                     const Point2PointPathPlannings<3, freeNav::RimJump::Pointi<3>, freeNav::RimJump::Pointi<3> > &p2p_plan_test,
                     StatisticSS &statisticss,
                     OutputStreamSS &output_streamss,
                     int max_count_of_case = 20000) {

        statisticss.clear();
        output_streamss.clear();
        ScenarioLoader3D sl(config_file_path.c_str());
        auto all_experiments = sl.getAllTestCases();
        int experiment_size = all_experiments.size();
        std::cout << "get " << all_experiments.size() << " 3d experiments" << std::endl;
        if (all_experiments.size() <= 0) return false;
        struct timezone tz;
        struct timeval tvpre;
        struct timeval tvafter;
        gettimeofday (&tvpre , &tz);
        // load experiment data
        for (int i = 0; i < std::min(max_count_of_case, experiment_size); i++) {
            const auto &experiment = all_experiments[i];
            double length = experiment.path_length_;
            // do test
            StatisticS statistics;
            OutputStreamS output_streams;
            freeNav::RimJump::Pointi<3> start = experiment.test_case_.first, target = experiment.test_case_.second;
            std::cout << "index " << i  << ": " << start << "->" << target << ", shortest length = " << length << std::endl;
            if (!Point2PointPathPlanningTest<3, freeNav::RimJump::Pointi<3>, freeNav::RimJump::Pointi<3> >(start,
                                                                                                           target,
                                                                                                           p2p_plan_test,
                                                                                                           statistics,
                                                                                                           output_streams)) {
                std::cout << "failed index " << i  << ": " << start << "->" << target << ", shortest length = " << length << std::endl;
            }
//            if (i % 100 == 0) {
//                std::cout << "finish " << i << " cases " << std::endl;
//            }
            gettimeofday (&tvafter , &tz);
            double time_interval = (tvafter.tv_sec-tvpre.tv_sec)+(tvafter.tv_usec-tvpre.tv_usec)/10e6;
            if(time_interval > .1) {
                std::cout << " finish :  " << i << " cases " << std::endl;
                gettimeofday (&tvpre , &tz);
            }
            for (auto &statistic : statistics) {
                statistic.push_back(length);
            }
            for (auto &output_stream : output_streams) {
                std::stringstream sst;
                sst << output_stream << length;
                output_stream = sst.str();
            }
            statisticss.push_back(statistics);
            output_streamss.push_back(output_streams);
            if(i%1000 == 0) {
                statisticss.shrink_to_fit();
                output_streamss.shrink_to_fit();
            }
            //break;
        }
        return true;
    }

    template<freeNav::RimJump::Dimension N>
    bool SingleMapTestDataAnalysis(const SingleMapTestConfig <N> &test_data, int planner_count = -1) {
        const auto &data_path = test_data.at("output_path");
        std::ifstream fin(data_path);
        std::string line;
        std::map<string, StatisticS> data;
        std::vector<std::pair<string, StatisticS> > data_v;
        int expected_size = 2 * N + 7;
        int count_of_line = 0;
        while (getline(fin, line)) {
            //std::cout << line << std::endl;
            std::istringstream sin(line);
            std::vector<string> fields;
            std::string field;
            while (sin.rdbuf()->in_avail() != 0) {
                sin >> field;
                fields.push_back(field);
            }
            if (!fields.empty()) {
                if (fields[0] == std::string("TYPE")) continue;
            }
            if (fields.size() != expected_size) {
                std::cout << " FATAL: field.size() " << field.size() << " != expected_size " << expected_size
                          << std::endl;
            }
            Statistic current_line;
            current_line.reserve(expected_size - 1);
            for (int i = 1; i < fields.size(); i++) {
                current_line.push_back(atof(fields[i].c_str()));
            }
            if(planner_count < 0) {
                if (data.find(fields[0]) == data.end()) {
                    data.insert({fields[0], {}});
                }
                auto iter = data.find(fields[0]);
                iter->second.push_back(current_line);
            } else {
                if(count_of_line < planner_count) {
                    data_v.push_back({fields[0], {}});
                }
                data_v[count_of_line % planner_count].second.push_back(current_line);
            }
            count_of_line ++;
        }
        if(planner_count < 0) {
            for (const auto &iter : data) {
                double init_time_cost = 0;
                double search_time_cost = 0;
                PathLen path_length = 0;
                PathLen path_length_standard = 0;
                int path_count = 0;
                std::string type_name;
                type_name = iter.first;
                int success_count = 0;
                for (const Statistic &case_data : iter.second) {
                    if(case_data[2 * N + 0] < 100000) { success_count ++; }
                    else { continue; }
                    //if(case_data[2 * N + 4] <= 1) continue;
                    if(case_data[2 * N + 0] >= 100000) std::cout  << " error path length " << case_data[2 * N + 0] << std::endl;
                    path_length          += case_data[2 * N + 0];
                    init_time_cost       += case_data[2 * N + 2];
                    search_time_cost     += case_data[2 * N + 3];
                    path_length_standard += case_data[2 * N + 5];
                    path_count           += case_data[2 * N + 4];
    //                std::cout << " path len         " << case_data[2 * N + 0] << std::endl;
    //                std::cout << " init_time_cost   " << case_data[2 * N + 2] << std::endl;
    //                std::cout << " search_time_cost " << case_data[2 * N + 3] << std::endl;
    //                std::cout << " search_time_cost " << case_data[2 * N + 4] << std::endl;
                }
                std::cout << std::setprecision(5)
                          << type_name << ": m_init_time  = \t" << init_time_cost / success_count <<
                          ", m_search_cost = \t" << search_time_cost / success_count <<
                          ", m_total_cost  = \t" << (init_time_cost+search_time_cost) / success_count <<
                          ", m_length = \t" << path_length / success_count <<
                          ", success_rate = \t" << success_count*100. / iter.second.size() << "%" <<
                          ", std_length = \t" << path_length_standard / success_count <<
                          ", path count = \t " << path_count / success_count
                        << std::endl;
            }
        } else {
            for (const auto &iter : data_v) {
                double init_time_cost = 0;
                double search_time_cost = 0;
                PathLen path_length = 0;
                PathLen path_length_standard = 0;
                int path_count = 0;
                std::string type_name;
                type_name = iter.first;
                int success_count = 0;
                for (const Statistic &case_data : iter.second) {
                    if(case_data[2 * N + 0] < 100000) { success_count ++; }
                    else { continue; }
                    //if(case_data[2 * N + 4] <= 1) continue;
                    if(case_data[2 * N + 0] >= 100000) std::cout  << " error path length " << case_data[2 * N + 0] << std::endl;
                    path_length          += case_data[2 * N + 0];
                    init_time_cost       += case_data[2 * N + 2];
                    search_time_cost     += case_data[2 * N + 3];
                    path_length_standard += case_data[2 * N + 5];
                    path_count           += case_data[2 * N + 4];
                    //                std::cout << " path len         " << case_data[2 * N + 0] << std::endl;
                    //                std::cout << " init_time_cost   " << case_data[2 * N + 2] << std::endl;
                    //                std::cout << " search_time_cost " << case_data[2 * N + 3] << std::endl;
                    //                std::cout << " search_time_cost " << case_data[2 * N + 4] << std::endl;
                }
                std::cout << std::setprecision(5)
                          << type_name << ": m_init_time  = \t" << init_time_cost / success_count <<
                          ", m_search_cost = \t" << search_time_cost / success_count <<
                          ", m_total_cost  = \t" << (init_time_cost+search_time_cost) / success_count <<
                          ", m_length = \t" << path_length / success_count <<
                          ", success_rate = \t" << success_count*100. / iter.second.size() << "%" <<
                          ", std_length = \t" << path_length_standard / success_count <<
                          ", path count = \t " << path_count / success_count
                          << std::endl;
            }
        }
        return true;
    }

}
#endif //FREENAV_MASSIVE_TEST_INTERFACES_H
