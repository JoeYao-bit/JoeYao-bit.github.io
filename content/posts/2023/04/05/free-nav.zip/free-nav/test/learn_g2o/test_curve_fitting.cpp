//
// Created by yaozhuo on 2021/9/19.
//

#include <gtest/gtest.h>
#include "test_curve_fitting.h"
#include "canvas.h"

using namespace std;
using namespace freeNav::RimJump;

// generate random data
double a = 2.;
double b = 0.4;
double lambda = 0.2;

double targetFunction(double x) {
    return a * exp(-lambda * x) + b;
}

int main(int argc, char** argv)
{

}