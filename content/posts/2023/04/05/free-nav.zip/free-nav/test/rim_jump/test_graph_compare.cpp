//
// Created by yaozhuo on 2022/9/6.
//

#include <2d_grid/text_map_loader.h>
#include <rim_jump/surface_processor/surface_processor_LineScanner.h>
#include "canvas.h"
#include "gtest/gtest.h"
#include "2d_grid/picture_loader.h"
#include "rim_jump/graph_construction/tangent_graph_build.h"
#include "rim_jump/online_search/create_initial_paths_with_edge.h"
#include "thread_pool.h"
#include "sys/time.h"
#include "rim_jump/constraints/point_to_point_constraints.h"
#include "rim_jump/constraints/edge_transfer_constraints.h"
#include "2d_grid/2d_ENLSVG_grid.h"
#include "2d_grid/text_map_loader.h"
using namespace freeNav::RimJump;


TEST(GraphCompare, test) {

}