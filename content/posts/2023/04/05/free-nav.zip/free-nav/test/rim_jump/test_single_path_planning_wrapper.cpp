//
// Created by yaozhuo on 2022/7/3.
//


#include "gtest/gtest.h"
#include "sys/time.h"

#include "rim_jump/constraints/edge_transfer_constraints.h"
#include "rim_jump/constraints/iteration_constraints.h"
#include "2d_grid/2d_ENLSVG_grid.h"
#include "2d_grid/picture_loader.h"
#include "ScenarioLoader2D.h"
#include "path_planning_interface.h"
#include "canvas.h"
#include "thread_pool.h"
#include "rimjump_loader.h"

using namespace freeNav::RimJump;

auto is_grid_occupied1 = [](const cv::Vec3b& color) -> bool {
    if (color != cv::Vec3b::all(255)) return true;
    return false;
};

auto is_grid_occupied2 = [](const cv::Vec3b& color) -> bool {
    if (color[0] <= 200 || color[1] <= 200 || color[2] <= 200) return true;
    return false;
};

std::string map_name = "/home/yaozhuo/code/free-nav/resource/map/TheFrozenSea.png";//"fr-campus-rectified";//"curve1";//"corridor";//"rectangle";//"cube";//"TheFrozenSea";//"maze512-8-5";//"jump_test1";//"jump_test2";//"maze512-1-0";//"16room_004";//"map";//"corridor";//"article_map2";//"maze512-1-0";//"Berlin_0_1024";//"AR0011SR";
std::string vis_file_name = "/home/yaozhuo/code/free-nav/resource/binary/TheFrozenSea.vis";
freeNav::RimJump::Pointi<2> pt1(2), pt2(2);


int zoom_rate = 1;

TEST(RIMJUMP, SINGLE_PATH_SEARCH) {

}


bool set_pt1 = true, plan_finish = false, new_pair = false;

PictureLoader pl(map_name, is_grid_occupied2);
auto is_occupied = [](const freeNav::RimJump::Pointi<2> &pt) -> bool { return pl.isOccupied(pt); };
bool (*f1)(const freeNav::RimJump::Pointi<2>&) = is_occupied;


TEST(RIMJUMP, WARPPER) {

}