//
// Created by yaozhuo on 2021/9/21.
//


#include <gtest/gtest.h>
#include "test_circle_fitting.h"
#include "canvas.h"

using namespace std;
using namespace freeNav::RimJump;

// generate random data
double c_x = 2.;
double c_y = 0.4;
double radius = 2.2;


int main(int argc, char** argv)
{
    int numPoints;
    int maxIterations;
    bool verbose;
    std::vector<int> gaugeList;
    string dumpFilename;
    g2o::CommandArgs arg;
    arg.param("dump", dumpFilename, "", "dump the points into a file");
    arg.param("numPoints", numPoints, 20, "number of points sampled from the curve");
    arg.param("i", maxIterations, 20, "perform n iterations");
    arg.param("v", verbose, false, "verbose output of the optimization process");

    arg.parseArgs(argc, argv);


    std::vector<Eigen::Vector2d> points(numPoints);
    for (int i = 0; i < numPoints; ++i) {
        double angle = g2o::Sampler::uniformRand(-M_PI, M_PI);
        double x = c_x + radius*cos(angle) + g2o::Sampler::gaussRand(0, 0.3);
        // add Gaussian noise
        double y = c_y + radius*sin(angle) + g2o::Sampler::gaussRand(0, 0.3);
        points[i].x() = x;
        points[i].y() = y;
    }

    if (dumpFilename.size() > 0) {
        ofstream fout(dumpFilename.c_str());
        for (int i = 0; i < numPoints; ++i)
            fout << points[i].transpose() << endl;
    }

    // some handy typedefs
    typedef g2o::BlockSolver< g2o::BlockSolverTraits<Eigen::Dynamic, Eigen::Dynamic> >  MyBlockSolver;
    typedef g2o::LinearSolverDense<MyBlockSolver::PoseMatrixType> MyLinearSolver;

    // setup the solver
    g2o::SparseOptimizer optimizer;
    optimizer.setVerbose(false);

    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg(
            g2o::make_unique<MyBlockSolver>(g2o::make_unique<MyLinearSolver>()));

    optimizer.setAlgorithm(solver);

    // build the optimization problem given the points
    // 1. add the parameter vertex
    CircleVertex* params = new CircleVertex();
    params->setId(0);
    params->setEstimate(Eigen::Vector3d(c_x,c_y,radius)); // some initial value for the params
    optimizer.addVertex(params);
    // 2. add the points we measured to be on the curve
    for (int i = 0; i < numPoints; ++i) {
        CircleEdge* e = new CircleEdge;
        /*  信息矩阵：协方差矩阵之逆 */
        e->setInformation(Eigen::Matrix<double, 1, 1>::Identity());
        e->setVertex(0, params);
        e->setMeasurement(points[i]);
        optimizer.addEdge(e);
    }

    // perform the optimization
    optimizer.initializeOptimization();
    optimizer.setVerbose(verbose);
    optimizer.optimize(maxIterations);

    if (verbose)
        cout << endl;

    double c_x_e = params->estimate()(0),
           c_y_e = params->estimate()(1),
           radius_e = params->estimate()(2);

    // print out the result
    cout << "Target curve" << endl;
    cout << "Iterative least squares solution" << endl;
    cout << "a      = " << c_x_e << endl;
    cout << "b      = " << c_y_e << endl;
    cout << "lambda = " << radius_e << endl;
    cout << endl;


    Canvas canvas("curve fitting", 1000, 800, 50);
    while (1) {
        canvas.resetCanvas();
        canvas.drawAxis(8., 6.);
        for(int i=0; i<numPoints; i++) {
            canvas.drawCircle(points[i].x(), points[i].y(), .05, -1, COLOR_TABLE[2]);
        }
        canvas.drawCircle(c_x, c_y, radius, 1, COLOR_TABLE[0]);
        canvas.drawCircle(c_x_e, c_y_e, radius_e, 1, COLOR_TABLE[2]);

        canvas.show();
        cv::waitKey(33);
    }

    return 0;
}