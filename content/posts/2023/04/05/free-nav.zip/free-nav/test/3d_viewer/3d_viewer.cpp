//
// Created by yaozhuo on 2022/2/26.
//

#include "3d_viewer.h"
#include "color_table.h"
using namespace freeNav::RimJump;
bool window_running = true;
bool Viewer3D::viewer_set_start = true;

using namespace freeNav::RimJump;

freeNav::RimJump::Pointi<3> Viewer3D::start_;

freeNav::RimJump::Pointi<3> Viewer3D::target_;

std::mutex three_dimension_mutex_;

void Viewer3D::DrawPoint(double px, double py, double pz)
{
    glPointSize(8.0f);
    glBegin(GL_POINTS);
    //float xf = px*2*halfsize+min_x, yf = py*2*halfsize+min_y, zf = pz*2*halfsize+min_z;
    glColor3f(.1, .1, .1);
    glVertex3f(px, py, pz);
    glEnd();
}

void Viewer3D::DrawLine(const freeNav::RimJump::Pointi<3> &p1, const freeNav::RimJump::Pointi<3> &p2, float r, float g, float b) {
    glLineWidth(4);
    glBegin(GL_LINES);
    glColor3f(r,g,b);
    glVertex3f(p1[0], p1[1], p1[2]);
    glVertex3f(p2[0], p2[1], p2[2]);
    glEnd();
}

void Viewer3D::DrawTangentNode(const fr::RoadMapGraphPtr<3>& tg, const fr::NodeId& node_id, const cv::Vec3b& color) {
    auto & ns = tg->nodes_;
    freeNav::RimJump::Pointi<3> center = ns[node_id]->sg_->pt_;
    DrawPoint(center[0], center[1], center[2]);
    for(const auto& vid : tg->nextNodes(ns[node_id])) {
        const auto& pt2 = ns[vid]->sg_->pt_;
        DrawLine(center, pt2, color[0], color[1], color[2]);
    }
}

void Viewer3D::DrawTangentGraph(const freeNav::RimJump::RoadMapGraphPtr<3>& tg) {
    auto & es = tg->edges_;
    auto & ns = tg->nodes_;

    int color_count = 0;
    if(!es.empty()) {
        for(const auto& node_ptr : tg->nodes_) {
            for(const auto& branch_id : node_ptr->nextEdges(true)) {
                freeNav::RimJump::Pointi<3> center = ns[es[branch_id]->nextNode(false)]->sg_->pt_;
                DrawPoint(center[0], center[1], center[2]);
                freeNav::RimJump::Pointi<3> end = ns[es[branch_id]->nextNode(true)]->sg_->pt_;
                DrawLine(center, end,
                         COLOR_TABLE[color_count][0],
                         COLOR_TABLE[color_count][1],
                         COLOR_TABLE[color_count][2]);
                color_count ++;
                color_count = color_count%30;
            }
            for(const auto& branch_id : node_ptr->nextEdges(false)) {
                freeNav::RimJump::Pointi<3> center = ns[es[branch_id]->nextNode(false)]->sg_->pt_;
                DrawPoint(center[0], center[1], center[2]);
                freeNav::RimJump::Pointi<3> end = ns[es[branch_id]->nextNode(true)]->sg_->pt_;
                DrawLine(center, end,
                         COLOR_TABLE[color_count][0],
                         COLOR_TABLE[color_count][1],
                         COLOR_TABLE[color_count][2]);
                color_count ++;
                color_count = color_count%30;
            }
        }
    } else {
        for(NodeId id=0; id<ns.size(); id++) {
            DrawTangentNode(tg, id, COLOR_TABLE[color_count]);
            color_count ++;
            color_count = color_count%29 + 1;
        }
    }
}

void Viewer3D::DrawLine(double x1, double y1, double z1, double x2, double y2, double z2) {
    glLineWidth(2);
    glBegin(GL_LINES);
    glColor3f(1,0,0);
    glVertex3f(x1, y1, z1);
    glVertex3f(x2, y2, z2);
    glEnd();
}

void Viewer3D::heightMapColor(double h, double& r, double &g, double& b)
{
    double s = 1.0;
    double v = 1.0;
    h -= floor(h);
    h *= 6;
    int i;
    double m, n, f;
    i = floor(h);
    f = h - i;
    if(!(i & 1)) {
        f = 1 - f;
    }
    m = v * (1-s);
    n = v * (1- s*f);
    switch(i) {
        case 6:
        case 0:
            r = v; g = n; b = m;
            break;
        case 1:
            r = n; g = v; b = m;
            break;
        case 2:
            r = m; g = v; b = n;
            break;
        case 3:
            r = m; g = n; b = v;
            break;
        case 4:
            r = n; g = m; b = v;
            break;
        case 5:
            r = v; g = m; b = n;
            break;
        default:
            r = 1; g = 0.5; b = 0.5;
            break;
    }
}


Viewer3D::Viewer3D() {
    mImageWidth = 640;
    mImageHeight = 480;
    mViewpointX = 0.;
    mViewpointY = 0.;
    mViewpointZ = 20.;
    mViewpointF = 1000.;
    under_planning = false;
}

Viewer3D::~Viewer3D() {}

void MyHandler3D::Keyboard(pangolin::View& view_, unsigned char key, int x, int y, bool pressed) {
    three_dimension_mutex_.lock();
    if(key == 32) { // 32 = space
        window_running = false;
        std::cout << "** terminated from key board" << std::endl;
        exit(0);
    }
    three_dimension_mutex_.unlock();
}

void Viewer3D::drawRoadMapEdgeAsPath(fr::RoadMapGraphPtr<3>& tg, freeNav::RimJump::RoadMapEdgeTraitPtr<3> edge, const cv::Vec3b& color) {
    drawEdge(tg, edge, false, false, color);
//    auto to_start = tg.edge_close_edge_to(edge->edge_id_, true, true, MIN_TIME);
//    while(to_start!=nullptr) {
//        drawEdge(tg, to_start, false, false, color);
//        to_start = tg.edge_close_edge_to(to_start->edge_id_, true, true, MIN_TIME);
//    }
//    auto to_target = tg.edge_close_edge_to(edge->edge_id_, false, true, MIN_TIME);
//    while(to_target!=nullptr) {
//        drawEdge(tg, to_target, false, false, color);
//        to_target = tg.edge_close_edge_to(to_target->edge_id_, false, true, MIN_TIME);
//    }
}

void Viewer3D::drawEdge(fr::RoadMapGraphPtr<3>& tg, const freeNav::RimJump::RoadMapEdgeTraitPtr<3>& edge, bool only_loop, bool draw_branch, const cv::Vec3b& color) {
    if(only_loop) {
        if(!edge->isLoopEdge()) return;
        //if(!freeNav::RimJump::RoadMapGraphBuilder<2>::isHyperLoopEdge(edge)) return;
        if(!edge->isHyperLoopEdge()) return;
    }

    auto & ns = tg->nodes_;
    auto & es = tg->edges_;

    Pointi<3> pre     = ns[edge->nextNode(true)]->sg_->pt_;
    Pointi<3> current = ns[edge->nextNode(false)]->sg_->pt_;
    DrawLine(current, pre, color[0], color[1], color[2]);

    int color_count = 0;
    if(draw_branch) {
        for(const auto& next_edge_id : tg->nextEdges(edge, true, true)) {
            pre     = ns[es[next_edge_id]->nextNode(true)]->sg_->pt_;
            current = ns[es[next_edge_id]->nextNode(false)]->sg_->pt_;
            DrawLine(current, pre, color[0], color[1], color[2]);            color_count ++;
        }
        for(const auto& pre_edge_id : tg->nextEdges(edge, false, true)) {
            pre     = ns[es[pre_edge_id]->nextNode(true)]->sg_->pt_;
            current = ns[es[pre_edge_id]->nextNode(false)]->sg_->pt_;
            DrawLine(current, pre, color[0], color[1], color[2]);            color_count ++;
        }
    }
}

void Viewer3D::drawRoadMapEdgesAsPath(fr::RoadMapGraphPtr<3>& tg, freeNav::RimJump::RoadMapEdgeTraitPtrs<3>& edges) {
    int color_count = 0;
    for(const auto& edge : edges) {
        cv::Vec3b color;
        drawRoadMapEdgeAsPath(tg, edge, COLOR_TABLE[color_count]); color_count ++;
    }
}

void Viewer3D::DrawPath(const freeNav::RimJump::Path<3> &path, float r, float g, float b) {
    if(path.size() < 2) return;
    for(int i=0; i<path.size()-1; i++) {
        DrawLine(path[i], path[i+1], r, g, b);
    }
}


void Viewer3D::drawRoadMapEdges(fr::RoadMapGraphPtr<3>& tg, freeNav::RimJump::RoadMapEdgeTraitPtrss<3>& edgess) {
    int color_count = 0;
    for(const auto& edges : edgess) {
        for(const auto& edge : edges) {
            drawEdge(tg, edge, false, false, COLOR_TABLE[color_count]);
        }
        color_count ++;
    }
}

void Viewer3D::DrawOctoMap(OctoMapLoader& octomap)
{
    three_dimension_mutex_.lock();
    //octomap::OcTree octo_map_(*(buff_space->octo_map));
    double max_z = octomap.max_z, min_z = octomap.min_z;
    int depth_offset = octomap.depth_offset;
    three_dimension_mutex_.unlock();
    octomap::OcTree::tree_iterator it  = octomap.getOctoMap()->begin_tree();
    octomap::OcTree::tree_iterator end = octomap.getOctoMap()->end_tree();
    int counter = 0;
    double occ_thresh = 0.9;
    int level = 16;
    glClearColor(1.0f,1.0f,1.0f,1.0f);

    glDisable(GL_LIGHTING);
    glEnable (GL_BLEND);
    //// DRAW OCTOMAP BEGIN //////
    double stretch_factor = 128/(1 - occ_thresh); //occupancy range in which the displayed cubes can be
    /***NOTICE: small block of obstacle is not shown in the pangolin window ***/
    for(; it != end; ++counter, ++it)
    {
        // it refer to all depth leaf nodes !
        // the higher depth_offset, the lower depth
        if(level-depth_offset != it.getDepth())
        {
            continue;
        }
        double occ = it->getOccupancy();
        if(occ < occ_thresh)
        {
            continue;
        }
        float halfsize = it.getSize()/2.0;
        float x = it.getX();
        float y = it.getY();
        float z = it.getZ();
        DrawVoxel(x, y, z, halfsize, min_z, max_z);
    }
}

void Viewer3D::DrawOctoMapGrid(OctoMapLoader& octomap) {
    auto dimension = octomap.getDimensionInfo();
    for(int i=0; i<dimension[0]; i++) {
        for(int j=0; j<dimension[1]; j++) {
            for(int k=0; k<dimension[2]; k++) {
                freeNav::RimJump::Pointi<3> pt;
                pt[0] = i, pt[1] = j, pt[2] = k;
                if(octomap.isOccupied(pt)) {
                    DrawVoxel(i, j, k, .5, 0, dimension[2]);
                }
            }
        }
    }
}

void Viewer3D::DrawVoxelMap(freeNav::RimJump::TextMapLoader_3D& voxel_map) {
    for(const auto& voxel : voxel_map.occ_voxels_) {
        DrawVoxel(voxel[0], voxel[1], voxel[2], .5, 0, voxel_map.getDimensionInfo()[2]);
    }
}

void Viewer3D::KeyBoardCallBack_W() {
    three_dimension_mutex_.lock();
    if(viewer_set_start) start_[1] += 1;
    else target_[1] += 1;
    three_dimension_mutex_.unlock();
}

void Viewer3D::KeyBoardCallBack_S() {
    three_dimension_mutex_.lock();
    if(viewer_set_start) start_[1] -= 1;
    else target_[1] -= 1;
    three_dimension_mutex_.unlock();
}

void Viewer3D::KeyBoardCallBack_A() {
    three_dimension_mutex_.lock();
    if(viewer_set_start) start_[0] -= 1;
    else target_[0] -= 1;
    three_dimension_mutex_.unlock();
}

void Viewer3D::KeyBoardCallBack_D() {
    three_dimension_mutex_.lock();
    if(viewer_set_start) start_[0] += 1;
    else target_[0] += 1;
    three_dimension_mutex_.unlock();
}

void Viewer3D::KeyBoardCallBack_Q() {
    three_dimension_mutex_.lock();
    if(viewer_set_start) start_[2] -= 1;
    else target_[2] -= 1;
    three_dimension_mutex_.unlock();
}

void Viewer3D::KeyBoardCallBack_E() {
    three_dimension_mutex_.lock();
    if(viewer_set_start) start_[2] += 1;
    else target_[2] += 1;
    three_dimension_mutex_.unlock();
}

void Viewer3D::DrawBound(double min_x_, double max_x_,double min_y_, double max_y_,double min_z_, double max_z_) {

    DrawLine(max_x_, min_y_,  min_z_, min_x_, min_y_, min_z_);
    DrawLine(min_x_, max_y_,  min_z_, min_x_, min_y_, min_z_);
    DrawLine(max_x_, min_y_, min_z_, max_x_, max_y_, min_z_);
    DrawLine(min_x_, max_y_, min_z_, max_x_, max_y_, min_z_);

    DrawLine(max_x_, min_y_,  max_z_, min_x_, min_y_, max_z_);
    DrawLine(min_x_, max_y_,  max_z_, min_x_, min_y_, max_z_);
    DrawLine(max_x_, min_y_, max_z_, max_x_, max_y_, max_z_);
    DrawLine(min_x_, max_y_, max_z_, max_x_, max_y_, max_z_);

    DrawLine(min_x_, min_y_,  min_z_, min_x_, min_y_, max_z_);
    DrawLine(min_x_, max_y_,  min_z_, min_x_, max_y_, max_z_);
    DrawLine(max_x_, min_y_, min_z_, max_x_, min_y_, max_z_);
    DrawLine(max_x_, max_y_, min_z_, max_x_, max_y_, max_z_);
}

void Viewer3D::init() {
    std::cout << "-- start 3D Viewer thread... " << std::endl;
    /*
    (0.0, 1.0) means the panel has the same high as the window
    (0, pangolin::Attach::Pix(175)) set the width and the start of the panel
    */
    pangolin::CreateWindowAndBind("3D Viewer",1024,768);
    pangolin::CreatePanel("menu").SetBounds(.0, 1., 0.0,pangolin::Attach::Pix(175));


    pangolin::RegisterKeyPressCallback('w', KeyBoardCallBack_W);
    pangolin::RegisterKeyPressCallback('a', KeyBoardCallBack_A);
    pangolin::RegisterKeyPressCallback('s', KeyBoardCallBack_S);
    pangolin::RegisterKeyPressCallback('d', KeyBoardCallBack_D);
    pangolin::RegisterKeyPressCallback('q', KeyBoardCallBack_Q);
    pangolin::RegisterKeyPressCallback('e', KeyBoardCallBack_E);


}

void Viewer3D::Run()
{
    //
}

void Viewer3D::DrawVoxel(double x, double y, double z, float halfsize, double min_z, double max_z)
{
    double h = ( std::min(std::max((max_z-z)/(max_z-min_z), 0.0), 1.0))*0.8;
    double r = .8, g = .8, b = .8;
    if(!show_grey_voxel) heightMapColor(h, r,g,b);
    else {
        r -= h;
        g = r;
        b = r;
    }
    glBegin(GL_TRIANGLES);
    //Front
    glColor3d(r, g, b);
    glVertex3f(x-halfsize,y-halfsize,z-halfsize); // - - - 1
    glVertex3f(x-halfsize,y+halfsize,z-halfsize); // - + - 2
    glVertex3f(x+halfsize,y+halfsize,z-halfsize); // + + -3

    glVertex3f(x-halfsize,y-halfsize,z-halfsize); // - - -
    glVertex3f(x+halfsize,y+halfsize,z-halfsize); // + + -
    glVertex3f(x+halfsize,y-halfsize,z-halfsize); // + - -4

    //Back
    glVertex3f(x-halfsize,y-halfsize,z+halfsize); // - - + 1
    glVertex3f(x+halfsize,y-halfsize,z+halfsize); // + - + 2
    glVertex3f(x+halfsize,y+halfsize,z+halfsize); // + + + 3

    glVertex3f(x-halfsize,y-halfsize,z+halfsize); // - - +
    glVertex3f(x+halfsize,y+halfsize,z+halfsize); // + + +
    glVertex3f(x-halfsize,y+halfsize,z+halfsize); // - + + 4

    //Left
    glVertex3f(x-halfsize,y-halfsize,z-halfsize); // - - - 1
    glVertex3f(x-halfsize,y-halfsize,z+halfsize); // - - + 2
    glVertex3f(x-halfsize,y+halfsize,z+halfsize); // - + + 3

    glVertex3f(x-halfsize,y-halfsize,z-halfsize); // - - -
    glVertex3f(x-halfsize,y+halfsize,z+halfsize); // - + +
    glVertex3f(x-halfsize,y+halfsize,z-halfsize); // - + - 4

    //Right
    glVertex3f(x+halfsize,y-halfsize,z-halfsize);
    glVertex3f(x+halfsize,y+halfsize,z-halfsize);
    glVertex3f(x+halfsize,y+halfsize,z+halfsize);

    glVertex3f(x+halfsize,y-halfsize,z-halfsize);
    glVertex3f(x+halfsize,y+halfsize,z+halfsize);
    glVertex3f(x+halfsize,y-halfsize,z+halfsize);

    //top
    glVertex3f(x-halfsize,y-halfsize,z-halfsize);
    glVertex3f(x+halfsize,y-halfsize,z-halfsize);
    glVertex3f(x+halfsize,y-halfsize,z+halfsize);

    glVertex3f(x-halfsize,y-halfsize,z-halfsize);
    glVertex3f(x+halfsize,y-halfsize,z+halfsize);
    glVertex3f(x-halfsize,y-halfsize,z+halfsize);

    //bottom
    glVertex3f(x-halfsize,y+halfsize,z-halfsize);
    glVertex3f(x-halfsize,y+halfsize,z+halfsize);
    glVertex3f(x+halfsize,y+halfsize,z+halfsize);

    glVertex3f(x-halfsize,y+halfsize,z-halfsize);
    glVertex3f(x+halfsize,y+halfsize,z+halfsize);
    glVertex3f(x+halfsize,y+halfsize,z-halfsize);
    glEnd();

#define DRAW_LINE 1
#if DRAW_LINE
    if(show_line_for_voxel) {
        glLineWidth(2);
        halfsize += .05*halfsize;
        glBegin(GL_LINES);
        glColor3f(0,0,0);
        // x
        glVertex3f(x+halfsize,y+halfsize,z+halfsize);
        glVertex3f(x-halfsize,y+halfsize,z+halfsize);

        glVertex3f(x+halfsize,y-halfsize,z-halfsize);
        glVertex3f(x-halfsize,y-halfsize,z-halfsize);

        glVertex3f(x+halfsize,y-halfsize,z+halfsize);
        glVertex3f(x-halfsize,y-halfsize,z+halfsize);

        glVertex3f(x+halfsize,y+halfsize,z-halfsize);
        glVertex3f(x-halfsize,y+halfsize,z-halfsize);

        // y
        glVertex3f(x+halfsize,y-halfsize,z+halfsize);
        glVertex3f(x+halfsize,y+halfsize,z+halfsize);

        glVertex3f(x-halfsize,y-halfsize,z-halfsize);
        glVertex3f(x-halfsize,y+halfsize,z-halfsize);

        glVertex3f(x+halfsize,y-halfsize,z-halfsize);
        glVertex3f(x+halfsize,y+halfsize,z-halfsize);

        glVertex3f(x-halfsize,y-halfsize,z+halfsize);
        glVertex3f(x-halfsize,y+halfsize,z+halfsize);

        // z
        glVertex3f(x+halfsize,y-halfsize,z-halfsize);
        glVertex3f(x+halfsize,y-halfsize,z+halfsize);

        glVertex3f(x-halfsize,y-halfsize,z+halfsize);
        glVertex3f(x-halfsize,y-halfsize,z-halfsize);

        glVertex3f(x+halfsize,y+halfsize,z-halfsize);
        glVertex3f(x+halfsize,y+halfsize,z+halfsize);

        glVertex3f(x-halfsize,y+halfsize,z+halfsize);
        glVertex3f(x-halfsize,y+halfsize,z-halfsize);

        glEnd();
    }
#endif
}

void Viewer3D::DrawGrid() {
    glLineWidth(5);
    glBegin(GL_LINES);
    glLineWidth(1);
    glColor3f(0.5,0.5,0.5); //gray
    int size = 20;
    for(int i = -size; i <= size ; i++) {
        glVertex3f(i,  size, .0);
        glVertex3f(i, -size, .0);
        glVertex3f( size, i, .0);
        glVertex3f(-size, i, .0);
    }
    glEnd();
}

