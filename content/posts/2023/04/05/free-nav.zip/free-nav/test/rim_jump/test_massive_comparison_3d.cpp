//
// Created by yaozhuo on 2022/11/26.
//

#include "rim_jump/online_search/search_path_with_node.h"
#include "3d_textmap/voxel_loader.h"
#include "gtest/gtest.h"
#include "test_data.h"
#include "rim_jump/constraints/edge_transfer_constraints.h"
#include "rim_jump/constraints/iteration_constraints.h"
#include "rim_jump/constraints/point_to_point_constraints.h"
#include "ScenarioLoader3D.h"


#include "rim_jump/online_search/breadth_first_search_with_node.h"
#include "rim_jump/online_search/depth_first_search_with_node.h"
#include "rim_jump/online_search/create_initial_paths_with_node.h"

#include "jps_planner/jps_planner/jps_planner.h"
#include "jps_planner/distance_map_planner/distance_map_planner.h"
#include <jps_basis/data_utils.h>

#include "sampling_path_planning.h"


using namespace freeNav::RimJump;

struct timezone tz;
struct timeval tv_pre;
struct timeval tv_after;

// node and edge constraints
PointTransferConstraints<3> ptcs({
                                         PTC_LocalCrossPartially // result fail
                                 });
PointTransferConstraints<3> ptcs_ordered;
// edge transfer constraints
EdgeTransferConstraints3<3> etcs({ETC_NotLookBack3 // ok
                                         , ETC_NoUselessPoint3 // not ok ?
                                         , ETC_IC_GetCloserToObstacle3
                                 });

IterationConstraints<3, freeNav::RimJump::GridPtr<3> > ics({});


// MapTestConfig_Full4 // run out of space, shrink space 4
// MapTestConfig_Simple // success
// MapTestConfig_DA2
// MapTestConfig_DC1 // one bywave, need 8~14s
// MapTestConfig_Complex
// MapTestConfig_A1
// MapTestConfig_FA2
SingleMapTestConfig<3> config = MapTestConfig_Complex;

TEST(VOXEL_LOADER, test) {
    std::string map_file_path = config.at("map_path");
    TextMapLoader_3D voxel_loader(map_file_path);
}

TEST(SCENCE_LOADER, test) {
    std::string config_file_path = config.at("config_path");
    ScenarioLoader3D scene_loader(config_file_path);
    const auto& test_cases = scene_loader.getAllTestCases();
    for(const auto& test_case : test_cases) {
        std::cout << test_case.test_case_.first << "->" << test_case.test_case_.second
                  << ", path length: " << test_case.path_length_ << ", unknown: " << test_case.unknown_value_ << std::endl;
    }
}


bool SingleMapTest3D(const SingleMapTestConfig <3> &map_test_config) {

    TextMapLoader_3D tl(map_test_config.at("map_path"));
    std::cout << "start SingleMapTest 3D from map " << map_test_config.at("map_path") << std::endl;
    auto dimension = tl.getDimensionInfo();

    IS_OCCUPIED_FUNC<3> is_occupied_func;

    SET_OCCUPIED_FUNC<3> set_occupied_func;

    auto is_occupied = [&tl](const freeNav::RimJump::Pointi<3> &pt) -> bool { return tl.isOccupied(pt); };
    is_occupied_func = is_occupied;

    auto set_occupied = [&tl](const freeNav::RimJump::Pointi<3> &pt) { tl.setOccupied(pt); };
    set_occupied_func = set_occupied;

    /* initialize rim jump start */
    gettimeofday(&tv_pre, &tz);
    auto surface_processor = std::make_shared<SurfaceProcessorSparse<3> >(dimension, is_occupied_func, set_occupied_func, tl.occ_voxels_, tl.occ_voxel_ids_);

    RoadMapGraphBuilder<3> *tgb = new RoadMapGraphBuilder<3>(surface_processor, ptcs, ptcs_ordered, etcs,map_test_config.at("vis_path")
                                                             ,false, false, 6);
    gettimeofday(&tv_after, &tz);
    freeNav::RimJump::RoadMapGraphPtr<3> tg = tgb->getRoadMapGraph();

    std::cout << "the tangent graph has " << tg->nodes_.size() << " nodes " << std::endl;
    std::cout << "the tangent graph has " << tg->edges_.size() << " nodes " << std::endl;

    double build_cost = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
    std::cout << "-- build graph end in " << build_cost << "ms" << std::endl << std::endl;

    GeneralGraphPathPlannerWithNode<3> g2p2(tg);

    /* initialize rim jump end */

    /* initialize RRTConnect */

    SamplingPlannerEnvironment<og::LazyPRM, 3> lazyprm_path_planner(dimension, is_occupied_func, set_occupied_func,
                                                                    10, false);

    SamplingPlannerEnvironment<og::RRTConnect, 3> rrtconnect_path_planner(dimension, is_occupied_func, set_occupied_func,
                                                                       10, false);

    /* initialize RRTConnect */

    /* init JPS map */
    //JPS::MapReader<Vec2i, Vec2f> reader(argv[1], true); // Map read from a given file
    std::shared_ptr<JPS::VoxelMapUtil_RJ> map_util = std::make_shared<JPS::VoxelMapUtil_RJ>();
    map_util->setMap(dimension, is_occupied_func);

    std::unique_ptr<JPSPlanner3D> JPS_planner_ptr(new JPSPlanner3D(false)); // Declare a planner
    JPS_planner_ptr->setMapUtil(map_util); // Set collision checking function
    JPS_planner_ptr->updateMap();
    /* end JPS map */

    /* construct the planning interfaces start */

    bool is_edge = true, is_dynamic = false, is_depth_first = false, global_shortest = true;
    int minimum_reach_count = -1; // exit only when all reach target
    ExitCode ec;

    auto rim_jump_path_planning = [&](const freeNav::RimJump::Pointi<3> &start,
                                      const freeNav::RimJump::Pointi<3> &target,
                                      freeNav::RimJump::Pointis<3> &path,
                                      Statistic &statistic,
                                      OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<3> > paths;

        //g2p2.planning(start, target, ics, paths, true, true, false); // pass

        //g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, ics, paths, false, true, false); //pass
        //g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, ics, paths, true, true, true); //pass
        //g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, ics, paths, true, true, false); //pass
        g2p2.planningWithNode(start, target,
                                   ptcs,
                                   etcs, {}, paths, false, true, true); //fastest, pass

        //g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, distinctive_without_ics, paths, true, false, false, 2); //pass

        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    int repeat_times = 1;

    /* construct OMPL LazyPRM planning interfaces start */
    auto lazyprm_path_planning = [&](const freeNav::RimJump::Pointi<3> &start,
                                  const freeNav::RimJump::Pointi<3> &target,
                                  freeNav::RimJump::Pointis<3> &path,
                                  Statistic &statistic,
                                  OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<3> path_ompl;
        for(int i=0; i<repeat_times; i++)
        {
            path_ompl = lazyprm_path_planner.plan(start, target);
        }
        path = path_ompl;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "LazyPRM " << start.toStr() << " " << target.toStr() << " ";
        if (path_ompl.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_ompl));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(path.size());
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* construct OMPL LazyPRM planning interfaces start */
    auto rrtconnect_path_planning = [&](const freeNav::RimJump::Pointi<3> &start,
                                     const freeNav::RimJump::Pointi<3> &target,
                                     freeNav::RimJump::Pointis<3> &path,
                                     Statistic &statistic,
                                     OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<3> path_ompl;
        for(int i=0; i<repeat_times; i++)
        {
            path_ompl = rrtconnect_path_planner.plan(start, target);
        }
        path = path_ompl;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "RRTConnect " << start.toStr() << " " << target.toStr() << " ";
        if (path_ompl.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_ompl));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(path.size());
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* construct JPS planning interfaces start */
    auto jps_path_planning = [&](const freeNav::RimJump::Pointi<3> &start,
                                 const freeNav::RimJump::Pointi<3> &target,
                                 freeNav::RimJump::Pointis<3> &path,
                                 Statistic &statistic,
                                 OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<3> path_jps;
        for(int i=0; i<repeat_times; i++)
        {
            path_jps  = JPS_planner_ptr->plan(start, target, 1, true); // Plan from start to goal using JPS
        }
        path = path_jps;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        std::cout << " search_graph_time " << search_graph_time << std::endl;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "JPS " << start.toStr() << " " << target.toStr() << " ";
        if (path_jps.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_jps));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(path_jps.empty());
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* construct ENL-SVG planning interfaces finish */
    StatisticSS statisticss;
    OutputStreamSS output_streamss;
    // rim_jump_path_planning
    // ENL_SVG_path_planning
    Point2PointPathPlannings<3, Pointi<3>, Pointi<3> > path_plannings = {rim_jump_path_planning,
                                                                         //lazyprm_path_planning,
                                                                         //rrtconnect_path_planning,
                                                                         //jps_path_planning,
                                                                         };
    SceneTest3D(map_test_config.at("config_path"), path_plannings, statisticss, output_streamss
                , 200);

    delete tgb;

    std::ofstream os(map_test_config.at("output_path"));
    //os << "TYPE START_X START_Y TARGET_X TARGET_Y PATH_LENGTH RESET_TIME INITIAL_TIME SEARCH_TIME" << std::endl;
    for (const auto &multi_method_output : output_streamss) {
        for (const auto method_output : multi_method_output) {
            os << method_output << std::endl;
        }
    }
    os.close();
    return true;
}

// TODO: considering transfer into octomap to save time ?
SingleMapTestConfigs<3> configs = {//MapTestConfig_Simple, // AC
                                   MapTestConfig_Complex, // AC partly
                                   MapTestConfig_A1, // -- build graph end in 7.578e+05ms // AC partly
                                   MapTestConfig_A2, // -- build graph end in 7.7032e+05ms // AC partly
                                   MapTestConfig_A3, // -- build graph end in 8.5128e+05ms // AC partly
                                   MapTestConfig_A4, // AC partly
                                   MapTestConfig_A5, // AC partly // JPS not finish

                                   MapTestConfig_BC1, // -- build graph end in 6.9444e+06ms
                                   MapTestConfig_BC2, // AC partly
                                   MapTestConfig_DA1, // AC partly
                                   MapTestConfig_DA2, // AC partly
                                   MapTestConfig_DB1, // AC partly
                                   MapTestConfig_DB2, // AC partly
                                   MapTestConfig_DC1, // AC partly

                                   MapTestConfig_DC2, // AC partly
                                   MapTestConfig_EB1, // AC partly
                                   MapTestConfig_EB2, // AC partly
                                   MapTestConfig_EC1, // AC partly
                                   MapTestConfig_EC2, // AC partly
};




TEST(RIMJUMP, MASSIVE_PATH_SEARCH_3D) {
    for(const auto& config : configs) {
        SingleMapTest3D(config);
    }
    for(const auto& config : configs) {
        std::cout << config.at("map_name") << ":" << std::endl;
        SingleMapTestDataAnalysis<3>(config);
        std::cout << std::endl;
    }
}

