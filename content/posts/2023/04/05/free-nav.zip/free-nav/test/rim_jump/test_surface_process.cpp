//
// Created by yaozhuo on 2022/1/9.
//

#include "canvas.h"
#include "gtest/gtest.h"
#include "2d_grid/picture_loader.h"
#include "rim_jump/graph_construction/tangent_graph_build.h"

auto is_grid_occupied1 = [](const cv::Vec3b& color) -> bool {
    if (color != cv::Vec3b::all(255)) return true;
    return false;
};

auto is_grid_occupied2 = [](const cv::Vec3b& color) -> bool {
    if (color[0] <= 200 || color[1] <= 200 || color[2] <= 200) return true;
    return false;
};

auto is_char_occupied = [](const char& value) -> bool {
    if (value != '.' && value != 'G' && value != 'S') return true;
    return false;
};

auto is_char_occupied1 = [](const char& value) -> bool {
    if (value == '.') return false;
    return true;
};

using namespace freeNav::RimJump;
std::string file_name = "corridor";//"fr-campus-rectified";//"curve1";//"corridor";//"rectangle";//"cube";//"TheFrozenSea";//"maze512-8-5";//"jump_test1";//"jump_test2";//"maze512-1-0";//"16room_004";//"map";//"corridor";//"article_map2";//"maze512-1-0";//"Berlin_0_1024";//"AR0011SR";
PictureLoader loader("/home/yaozhuo/code/free-nav/resource/map/" + file_name + ".bmp", is_grid_occupied2);
std::string vis_file_path = "/home/yaozhuo/code/free-nav/resource/binary/" + file_name + ".vis";

bool draw_candidate = true;

auto dimension = loader.getDimensionInfo();
auto is_occupied = [](const freeNav::RimJump::Pointi<2> & pt) -> bool { return loader.isOccupied(pt); };
bool (*f1)(const freeNav::RimJump::Pointi<2>&) = is_occupied;
auto set_occupied = [](const freeNav::RimJump::Pointi<2> & pt) { loader.setOccupied(pt); };
void (*f2)(const freeNav::RimJump::Pointi<2>&) = set_occupied;

TEST(RIMJUMP, DETECT_SURFACE) {

}


