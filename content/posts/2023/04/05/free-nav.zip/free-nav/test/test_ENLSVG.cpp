//
// Created by yaozhuo on 2022/3/24.
//

#include "canvas.h"
#include "gtest/gtest.h"
#include "2d_grid/picture_loader.h"

#include "thread_pool.h"
#include "sys/time.h"

#include "ENLSVG.h"

std::shared_ptr<Pathfinding::Grid> grid_ptr = nullptr;


auto is_occupied = [](const freeNav::RimJump::Pointi<2> & pt) -> bool { return grid_ptr->isBlocked(pt[0], pt[1]); };

bool (*f1)(const freeNav::RimJump::Pointi<2>&) = is_occupied;

int zoom_rate = 1;

freeNav::RimJump::Pointi<2> pt1(2), pt2(2);

bool set_pt1 = true;

bool new_pair = false;
bool plan_finish = false;

using namespace freeNav::RimJump;

int main() {
}

