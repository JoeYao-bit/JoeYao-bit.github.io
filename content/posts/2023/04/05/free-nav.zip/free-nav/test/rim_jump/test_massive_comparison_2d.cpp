//
// Created by yaozhuo on 2022/7/8.
//

#include "ScenarioLoader2D.h"
#include "path_planning_interface.h"
#include "rim_jump/constraints/edge_transfer_constraints.h"
#include "rim_jump/constraints/iteration_constraints.h"
#include "rim_jump/surface_processor/surface_processor_LineScanner.h"
#include "gtest/gtest.h"

#include "2d_grid/2d_ENLSVG_grid.h"
#include "2d_grid/text_map_loader.h"
#include "2d_grid/picture_loader.h"
#include "rim_jump/surface_processor/surface_processor_ENLSVG_LineScanner.h"

#include "rim_jump/online_search/search_path_with_edge.h"
#include "rim_jump/online_search/breadth_first_search_with_edge.h"
#include "rim_jump/online_search/depth_first_search_with_edge.h"
#include "rim_jump/online_search/create_initial_paths_with_edge.h"

#include "rim_jump/online_search/search_path_with_node.h"
#include "rim_jump/online_search/breadth_first_search_with_node.h"
#include "rim_jump/online_search/depth_first_search_with_node.h"
#include "rim_jump/online_search/create_initial_paths_with_node.h"

#include "canvas.h"
#include "test_data.h"

#include "massive_test_interfaces.h"
#include "directory_loader.h"

#include "bridge_2d.h"
#include "sampling_path_planning.h"


#include "jps_planner/jps_planner/jps_planner.h"
#include "jps_planner/distance_map_planner/distance_map_planner.h"

#include <jps_basis/data_utils.h>

#include "lazy_theta.h"

using namespace freeNav::RimJump;

struct timezone tz;
struct timeval tv_pre;
struct timeval tv_after;

// determine whether a pixel in picture is occupied
auto is_grid_occupied = [](const cv::Vec3b& color) -> bool {
    if (color[0] == 0 && color[1] == 0 && color[2] == 0) return true;
    return false;
};

auto is_char_occupied = [](const char& value) -> bool {
    if (value != '.' && value != 'G' && value != 'S') return true;
    return false;
};

auto is_char_occupied1 = [](const char& value) -> bool {
    if (value != '.') return false;
    return true;
};

// node and edge constraints
PointTransferConstraints<2> ptcs({PTC_LocalCrossPartially,
                                  PTC_DoNotCrossObstacle
                                 }
);

PointTransferConstraints<2> ptcs_ordered;

// edge transfer constraints
EdgeTransferConstraints3<2> etcs({//ETC_NotLookBack3
                                         ETC_NoUselessPoint3
                                         ,ETC_IC_GetCloserToObstacle3
                                         //,ETC_IC_GetCloserToObstacle_ENLSVG
                                         //,ETC_Taut_2D
                                 });

IterationConstraints<2, freeNav::RimJump::GridPtr<2>> ics({
                                                                  //IC_EdgeNLevelLimitUndirectedGraph
                                                          });

IterationConstraints<2, freeNav::RimJump::GridPtr<2>> distinctive_ics({IC_NoLoop, IC_EdgeNLevelLimit});

PointTransferConstraints<2> init_ptcs({PTC_CrosserToObstacle_2D});
EdgeTransferConstraints3<2> init_etcs({ETC_Taut_2D});

IterationConstraints<2, freeNav::RimJump::GridPtr<2>> distinctive_without_ics({
                                                                                      IC_EdgeNLevelLimitUndirectedGraph,
                                                                                      IC_NoLoop
                                                                              });


#define WITH_EDGE_M2 1

bool SingleMapTest2D(const SingleMapTestConfig <2> &map_test_config) {

    TextMapLoader tl(map_test_config.at("map_path"), is_char_occupied);
    std::cout << "start SingleMapTest from map " << map_test_config.at("map_path") << std::endl;
    auto dimension = tl.getDimensionInfo();

    IS_OCCUPIED_FUNC<2> is_occupied_func;

    SET_OCCUPIED_FUNC<2> set_occupied_func;

    auto is_occupied = [&tl](const freeNav::RimJump::Pointi<2> &pt) -> bool { return tl.isOccupied(pt); };
    is_occupied_func = is_occupied;

    auto set_occupied = [&tl](const freeNav::RimJump::Pointi<2> &pt) { tl.setOccupied(pt); };
    set_occupied_func = set_occupied;

    /* initialize rim jump start */
    gettimeofday(&tv_pre, &tz);
    //auto surface_processor = std::make_shared<SurfaceProcessor<2> >(dimension, is_occupied_func, set_occupied_func);
    auto surface_processor = std::make_shared<SurfaceProcess_ENLSVG_LineScanner>(dimension, is_occupied_func, set_occupied_func);


#if WITH_EDGE_M2
    RoadMapGraphBuilder<2> *tgb = new RoadMapGraphBuilder<2>(surface_processor,
                                                             init_ptcs, ptcs_ordered, init_etcs,
                                                             map_test_config.at("vis_path")
                                                             //, true
    );

#else
    RoadMapGraphBuilder<2> *tgb = new RoadMapGraphBuilder<2>(surface_processor,
                                                             init_ptcs, ptcs_ordered, init_etcs,
                                                             map_test_config.at("vis_path")
                                                             , false, false
    );
#endif

//    RoadMapGraphBuilder<2> *tgb = new RoadMapGraphBuilder<2>(surface_processor,
//                                                             ptcs, ptcs_ordered, etcs,
//                                                             map_test_config.at("vis_path"), true
//    );

    gettimeofday(&tv_after, &tz);
    freeNav::RimJump::RoadMapGraphPtr<2> tg = tgb->getRoadMapGraph();
    std::cout << "the tangent graph has " << tg->nodes_.size() << " nodes " << std::endl;
    std::cout << "the tangent graph has " << tg->edges_.size() << " edges " << std::endl;

    double build_cost = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
    std::cout << "-- build graph end in " << build_cost << "ms" << std::endl << std::endl;
#if WITH_EDGE_M2
    GeneralGraphPathPlannerWithEdge<2> g2p2(tg);
#else
    GeneralGraphPathPlannerWithNode<2> g2p2(tg);
#endif
    /* initialize rim jump end */

    /* construct the planning interfaces start */

    bool is_edge = true, is_dynamic = false, is_depth_first = false, global_shortest = true;
    int minimum_reach_count = -1; // exit only when all reach target
    ExitCode ec;

    int repeat_times = 1; // NOTICE: the more times repeat, the less time cost

    auto rim_jump_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                      const freeNav::RimJump::Pointi<2> &target,
                                      freeNav::RimJump::Pointis<2> &path,
                                      Statistic &statistic,
                                      OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<2> > paths;
#if WITH_EDGE_M2

        //g2p2.planningWithOutLength(start, target, ics, paths, false, true, true); // pass
//        g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, ics, paths, false, true, false); //pass
//        g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, ics, paths, true, true, true); //pass
        //g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, ics, paths, true, true, false); //pass
        //g2p2.planningWithEdge(start, target, init_ptcs, init_etcs, ics, paths, false, true, true); //fastest, pass
        for(int i=0; i<repeat_times; i++)
        {
            g2p2.planningWithEdge(start, target, init_ptcs, init_etcs, ics, paths, false, true, true); //fastest, pass
        }
        //ec = g2p2.planningWithOutLength(start, target, {}, etcs,ics, paths, true, true, true);
        //ec = g2p2.planningWithOutLength(start, target, {}, etcs,ics, paths, false, true, true);
#else
        ec = g2p2.planningWithNode(start, target, init_ptcs, init_etcs, {}, paths, false, true, true);
#endif

        //g2p2.planningWithOutLength(start, target, init_ptcs, init_etcs, distinctive_without_ics, paths, true, false, false, 2); //pass

        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    /* initialize ENL-SVG start */
    auto ENL_SVG_grid = getENL_SVG_Module(dimension, is_occupied_func);
    gettimeofday(&tv_pre, &tz);
    // Preprocess the grid to build a visibility graph.
    Pathfinding::ENLSVG::Algorithm algo(ENL_SVG_grid);
    algo.printStatistics();
    // Initialise a memory object for the algorithm. The algorithm uses this memory object for its path computations.
    Pathfinding::ENLSVG::Memory memory(ENL_SVG_grid);
    gettimeofday(&tv_after, &tz);
    double cost_ms1 = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
    std::cout << "-- ENL-SVG Preprocess end in " << cost_ms1 << " ms" << std::endl;
    /* initialize ENL-SVG finish */

    /* construct ENL-SVG planning interfaces start */
    auto ENL_SVG_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                     const freeNav::RimJump::Pointi<2> &target,
                                     freeNav::RimJump::Pointis<2> &path,
                                     Statistic &statistic,
                                     OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Pathfinding::Path ENL_SVG_path;
        for(int i=0; i<repeat_times; i++)
            //for(int i=0; i<5; i++)
        {
            ENL_SVG_path = algo.computePath(memory, start[0], start[1], target[0], target[1],
                                            initial_time, search_graph_time);
        }
        //algo.printStatistics();
        gettimeofday(&tv_after, &tz);
        cost_ms1 = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        path.clear();
        std::stringstream ss;
        ss << "SVG " << start.toStr() << " " << target.toStr() << " ";
        if (ENL_SVG_path.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            for (const auto &pt : ENL_SVG_path) {
                freeNav::RimJump::Pointi<2> way_point;
                way_point[0] = pt.x, way_point[1] = pt.y;
                path.push_back(way_point);
            }
            statistic.push_back(calculatePathLength(path));
            //statistic.push_back(2.3);
        }
        statistic.push_back(0);
        statistic.push_back(initial_time);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };
    /* construct ENL-SVG planning interfaces finish */



    /* init sampling based planner */
    SamplingPlannerEnvironment<og::LBTRRT, 2> lbtrrt_path_planner(dimension, is_occupied_func, set_occupied_func, 1);
    /* end  sampling based planner */

    /* construct OMPL planning interfaces start */
    auto lbtrrt_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                  const freeNav::RimJump::Pointi<2> &target,
                                  freeNav::RimJump::Pointis<2> &path,
                                  Statistic &statistic,
                                  OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<2> path_ompl;
        for(int i=0; i<repeat_times; i++)
        {
            path_ompl = lbtrrt_path_planner.plan(start, target);
        }
        path = path_ompl;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "LBTRRT " << start.toStr() << " " << target.toStr() << " ";
        if (path_ompl.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_ompl));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* init sampling based planner */
    SamplingPlannerEnvironment<og::LazyPRM, 2> prmstar_path_planner(dimension, is_occupied_func, set_occupied_func, 1);
    /* end  sampling based planner */

    /* construct OMPL planning interfaces start */
    auto prmstar_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                    const freeNav::RimJump::Pointi<2> &target,
                                    freeNav::RimJump::Pointis<2> &path,
                                    Statistic &statistic,
                                    OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<2> path_ompl;
        for(int i=0; i<repeat_times; i++)
        {
            path_ompl = prmstar_path_planner.plan(start, target);
        }
        path = path_ompl;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "LazyPRM " << start.toStr() << " " << target.toStr() << " ";
        if (path_ompl.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_ompl));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* init sampling based planner */
    SamplingPlannerEnvironment<og::RRTConnect, 2> rrtstar_path_planner(dimension, is_occupied_func, set_occupied_func, 1);
    /* end  sampling based planner */

    /* construct OMPL planning interfaces start */
    auto rrtstar_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                 const freeNav::RimJump::Pointi<2> &target,
                                 freeNav::RimJump::Pointis<2> &path,
                                 Statistic &statistic,
                                 OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<2> path_ompl;
        for(int i=0; i<repeat_times; i++)
        {
            path_ompl = rrtstar_path_planner.plan(start, target);
        }
        path = path_ompl;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "RRTstar " << start.toStr() << " " << target.toStr() << " ";
        if (path_ompl.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_ompl));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* init JPS map */
    //JPS::MapReader<Vec2i, Vec2f> reader(argv[1], true); // Map read from a given file
    std::shared_ptr<JPS::OccMapUtil_RJ> map_util = std::make_shared<JPS::OccMapUtil_RJ>();
    map_util->setMap(dimension, is_occupied_func);

    std::unique_ptr<JPSPlanner2D> JPS_planner_ptr(new JPSPlanner2D(false)); // Declare a planner
    JPS_planner_ptr->setMapUtil(map_util); // Set collision checking function
    JPS_planner_ptr->updateMap();
    /* end JPS map */

    /* construct OMPL planning interfaces start */
    auto jps_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                 const freeNav::RimJump::Pointi<2> &target,
                                 freeNav::RimJump::Pointis<2> &path,
                                 Statistic &statistic,
                                 OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<2> path_jps;
        for(int i=0; i<repeat_times; i++)
        {
            path_jps  = JPS_planner_ptr->plan(start, target, 1, true); // Plan from start to goal using JPS
        }
        path = path_jps;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "JPS " << start.toStr() << " " << target.toStr() << " ";
        if (path_jps.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_jps));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* init move_base_2d map */
    unsigned char* cost_move_base_2d = new unsigned char[(dimension[0]+2)*(dimension[1]+2)];
    getMap(cost_move_base_2d, dimension, is_occupied, set_occupied);
    /* end move_base_2d map */

    /* construct Dijkstra planning interfaces start */
    auto dijk_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                  const freeNav::RimJump::Pointi<2> &target,
                                  freeNav::RimJump::Pointis<2> &path,
                                  Statistic &statistic,
                                  OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<2> path_dijk;
        for(int i=0; i<repeat_times; i++)
        {
            FloatPath path_dijkf = DijkstraPlanner(cost_move_base_2d, start[0], start[1], target[0], target[1],
                                                   dimension[0], dimension[1]);
            path_dijk = ToRimJumpPath(path_dijkf);
        }
        path = path_dijk;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "Dijk " << start.toStr() << " " << target.toStr() << " ";
        if (path_dijk.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_dijk));
            //statistic.push_back(11.3);
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* construct Astar planning interfaces start */
    auto astar_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                   const freeNav::RimJump::Pointi<2> &target,
                                   freeNav::RimJump::Pointis<2> &path,
                                   Statistic &statistic,
                                   OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<2> path_astar;
        for(int i=0; i<repeat_times; i++)
        {
            FloatPath path_astarf = AstarPlanner(cost_move_base_2d, start[0], start[1], target[0], target[1],
                                                 dimension[0], dimension[1]);
            path_astar = ToRimJumpPath(path_astarf);
        }
        path = path_astar;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "Astar " << start.toStr() << " " << target.toStr() << " ";
        if (path_astar.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_astar));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* init lazy theta star */
    auto lazy_theta_star_map = getLazyThetaMap(dimension, is_occupied);

    /* construct OMPL planning interfaces start */
    auto lazy_theta_star_path_planning = [&](const freeNav::RimJump::Pointi<2> &start,
                                             const freeNav::RimJump::Pointi<2> &target,
                                             freeNav::RimJump::Pointis<2> &path,
                                             Statistic &statistic,
                                             OutputStream &output_stream) {
        gettimeofday(&tv_pre, &tz);
        double initial_time = 0, search_graph_time = 0;
        Path<2> path_lazy_theta_star;
        for(int i=0; i<repeat_times; i++)
        {
            path_lazy_theta_star = LazyThetaWrap(lazy_theta_star_map, start, target);
        }
        path = path_lazy_theta_star;
        gettimeofday(&tv_after, &tz);
        search_graph_time = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
        statistic.clear();
        output_stream.clear();
        std::stringstream ss;
        ss << "LTstar " << start.toStr() << " " << target.toStr() << " ";
        if (path_lazy_theta_star.empty()) {
            statistic.push_back(MAX<PathLen>);
        } else {
            statistic.push_back(calculatePathLength(path_lazy_theta_star));
        }
        statistic.push_back(0);
        statistic.push_back(0);
        statistic.push_back(search_graph_time);
        statistic.push_back(1);
        for (const auto &data : statistic) {
            ss << data << " ";
        }
        output_stream = ss.str();
    };

    /* end lazy theta star */

    StatisticSS statisticss;
    OutputStreamSS output_streamss;
    // rim_jump_path_planning
    // ENL_SVG_path_planning
    Point2PointPathPlannings<2, Pointi<2>, Pointi<2> > path_plannings = {rim_jump_path_planning,
                                                                         //ENL_SVG_path_planning,
                                                                         //lbtrrt_path_planning,
                                                                         //prmstar_path_planning,
                                                                         //rrtstar_path_planning
                                                                         //jps_path_planning,
                                                                         //dijk_path_planning,
                                                                         //astar_path_planning,
//                                                                         lazy_theta_star_path_planning,
    };
//    delete tgb;
//    delete[] cost_move_base_2d;
    SceneTest2D(map_test_config.at("config_path"), path_plannings, statisticss, output_streamss);
    delete tgb;
    delete[] cost_move_base_2d;
    //SceneTest2DIndividual(map_test_config.at("config_path"), path_plannings, statisticss, output_streamss);
    std::ofstream os(map_test_config.at("output_path"));
    //os << "TYPE START_X START_Y TARGET_X TARGET_Y PATH_LENGTH RESET_TIME INITIAL_TIME SEARCH_TIME" << std::endl;
    for (const auto &multi_method_output : output_streamss) {
        for (const auto method_output : multi_method_output) {
            os << method_output << std::endl;
        }
    }
    os.close();
    return true;
}

//MapTestConfig_Berlin_1_256;
//MapTestConfig_FloodedPlains;
//MapTestConfig_Boston_0_1024;
//MapTestConfig_TheFrozenSea;
//MapTestConfig_maze512_4_8;
//MapTestConfig_maze512_4_0;
//MapTestConfig_Boston_0_1024,
//MapTestConfig_Aurora
//MapTestConfig_8room_002
//MapTestConfig_random512_10_0  //run out of memory, ENLSVG take 1G memory, but rj failed, because of too many edge ?
SingleMapTestConfigs<2> configs = {
        MapTestConfig_Berlin_1_256,  // pass
        MapTestConfig_Boston_0_1024,
        MapTestConfig_Denver_2_512,
        MapTestConfig_London_0_256,

        MapTestConfig_TheFrozenSea,  // pass, all distinctive test failed, after 2400, bywave every slow after 2300
        MapTestConfig_FloodedPlains, // pass
        MapTestConfig_Entanglement,// pass, all distinctive test failed, after 2400, run out of storage space
        MapTestConfig_Aurora,

        MapTestConfig_maze512_4_8,   // pass
        MapTestConfig_maze512_4_0,   // pass
        MapTestConfig_maze512_16_3,
        MapTestConfig_maze512_8_6,

        MapTestConfig_8room_002,
        MapTestConfig_16room_001,
        MapTestConfig_8room_009,
        MapTestConfig_32room_003,

//        MapTestConfig_random512_10_0,
        //MapTestConfig_random512_35_2,
};

TEST(RIMJUMP, MASSIVE_PATH_SEARCH_2D) {
//    configs = {
//            MapTestConfig_Berlin_1_256, // ok
//            MapTestConfig_Denver_2_512, // ok
//            MapTestConfig_Boston_2_256, // pass
//            MapTestConfig_Milan_1_512, // pass
//            MapTestConfig_Moscow_2_256, // pass
//            MapTestConfig_Shanghai_0_512, // pass
//            MapTestConfig_Sydney_1_256, // pass
//            MapTestConfig_Paris_0_512
//    }; // single test
    for(const auto& config : configs) {
        SingleMapTest2D(config);
    }
    for(const auto& config : configs) {
        std::cout << config.at("map_name") << ":" << std::endl;
        SingleMapTestDataAnalysis<2>(config);
        std::cout << std::endl;
    }
}

TEST(RIMJUMP, DATA_PROCESS) {

    for(const auto& config : configs) {
        std::cout << config.at("map_name") << ":" << std::endl;
        SingleMapTestDataAnalysis<2>(config);
        std::cout << std::endl;
    }

}

bool SingleMapStatistic2D(const SingleMapTestConfig <2> &map_test_config) {

    TextMapLoader tl(map_test_config.at("map_path"), is_char_occupied);
    std::cout << "start SingleMapTest from map " << map_test_config.at("map_path") << std::endl;
    auto dimension = tl.getDimensionInfo();

    IS_OCCUPIED_FUNC<2> is_occupied_func;

    SET_OCCUPIED_FUNC<2> set_occupied_func;

    auto is_occupied = [&tl](const freeNav::RimJump::Pointi<2> &pt) -> bool { return tl.isOccupied(pt); };
    is_occupied_func = is_occupied;

    auto set_occupied = [&tl](const freeNav::RimJump::Pointi<2> &pt) { tl.setOccupied(pt); };
    set_occupied_func = set_occupied;

    /* initialize rim jump start */
    gettimeofday(&tv_pre, &tz);
    auto surface_processor = std::make_shared<SurfaceProcessor<2> >(dimension, is_occupied_func, set_occupied_func);
    RoadMapGraphBuilder<2> *tgb = new RoadMapGraphBuilder<2>(surface_processor,
                                                             ptcs, ptcs_ordered, etcs,
                                                             map_test_config.at("vis_path")
                                                             , true
                                                             , true
                                                             , 3
    );

    //auto surface_processor = std::make_shared<SurfaceProcess_ENLSVG_LineScanner>(dimension, is_occupied_func, set_occupied_func);
//    RoadMapGraphBuilder<2> *tgb = new RoadMapGraphBuilder<2>(surface_processor,
//                                                             init_ptcs, ptcs_ordered, init_etcs,
//                                                             map_test_config.at("vis_path"), true
//    );

    gettimeofday(&tv_after, &tz);
    freeNav::RimJump::RoadMapGraphPtr<2> tg = tgb->getRoadMapGraph();
    std::cout << "the tangent graph has " << tg->nodes_.size() << " nodes " << std::endl;
    std::cout << "the tangent graph has " << tg->edges_.size() << " edges " << std::endl;

    double build_cost = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
    std::cout << "-- build graph end in " << build_cost << "ms" << std::endl;

    tg->getStatistics();
    delete tgb;
    return true;
}

TEST(RIMJUMP, MASSIVE_STATISTIC_2D) {
//    configs = {//MapTestConfig_TheFrozenSea,
//               //MapTestConfig_FloodedPlains, // pass
//               //MapTestConfig_Entanglement,// pass, all distinctive test failed, after 2400, run out of storage space
//               MapTestConfig_Aurora,
//               MapTestConfig_8room_002
//    }; // single test
    for(const auto& config : configs) {
        SingleMapStatistic2D(config);
    }
}

TEST(RIMJUMP, MASSIVE_STATISTIC_2D_ALL_IN_ONE) {

    std::string folder = "/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/map-all-in-one/";
    std::string format_name = std::string("map");
    auto files = getFilesWithFormat(folder.c_str(), format_name);
    int i=0;
    std::vector< std::map<std::string, std::string> > configs;
    for(const auto file : files) {
        std::cout << ++i << ": " << file << std::endl;
        auto config = convertFromMapToTestConfig(file);
//        for(const auto& config_pair : config) {
//            std::cout << config_pair.first << " : " << config_pair.second << std::endl;
//        }
        configs.push_back(config);
    }
    for(const auto& config : configs) {
        SingleMapTest2D(config);
    }
    for(const auto& config : configs) {
        std::cout << config.at("map_name") << ":" << std::endl;
        SingleMapTestDataAnalysis<2>(config);
        std::cout << std::endl;
    }

}




NodeIterationConstraints<2, freeNav::RimJump::GridPtr<2>> ics_node_topology({
                                                                                    NIC_NoLoop, // if is global shortest, no need to add IC_NoLoop
                                                                                    //IC_EdgeNLevelLimit
                                                                                    NIC_NoStraightExtend
                                                                            });


bool SingleMapTestDistinctiveTopology2D(const SingleMapTestConfig <2> &map_test_config) {

    TextMapLoader tl(map_test_config.at("map_path"), is_char_occupied);
    std::cout << "start SingleMapTest from map " << map_test_config.at("map_path") << std::endl;
    auto dimension = tl.getDimensionInfo();

    IS_OCCUPIED_FUNC<2> is_occupied_func;

    SET_OCCUPIED_FUNC<2> set_occupied_func;

    auto is_occupied = [&tl](const freeNav::RimJump::Pointi<2> &pt) -> bool { return tl.isOccupied(pt); };
    is_occupied_func = is_occupied;

    auto set_occupied = [&tl](const freeNav::RimJump::Pointi<2> &pt) { tl.setOccupied(pt); };
    set_occupied_func = set_occupied;

    /* initialize rim jump start */
    gettimeofday(&tv_pre, &tz);
    //auto surface_processor = std::make_shared<SurfaceProcessor<2> >(dimension, is_occupied_func, set_occupied_func);
    auto surface_processor = std::make_shared<SurfaceProcess_ENLSVG_LineScanner>(dimension, is_occupied_func,
                                                                                 set_occupied_func);


    RoadMapGraphBuilder<2> *tgb = new RoadMapGraphBuilder<2>(surface_processor,
                                                             init_ptcs, ptcs_ordered, init_etcs,
                                                             map_test_config.at("vis_path")
                                                             , false, false
    );

    gettimeofday(&tv_after, &tz);
    freeNav::RimJump::RoadMapGraphPtr<2> tg = tgb->getRoadMapGraph();
    std::cout << "the tangent graph has " << tg->nodes_.size() << " nodes " << std::endl;
    std::cout << "the tangent graph has " << tg->edges_.size() << " edges " << std::endl;

    double build_cost = (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
    std::cout << "-- build graph end in " << build_cost << "ms" << std::endl << std::endl;

    GeneralGraphPathPlannerWithNode<2> g2p2(tg);
    /* initialize rim jump end */

    /* construct the planning interfaces start */

    bool is_edge = true, is_dynamic = false, is_depth_first = false, global_shortest = true;
    int minimum_reach_count = -1; // exit only when all reach target
    ExitCode ec;

    int repeat_times = 1; // NOTICE: the more times repeat, the less time cost

    auto rim_jump_path_planning_10 = [&](const freeNav::RimJump::Pointi<2> &start,
                                          const freeNav::RimJump::Pointi<2> &target,
                                          freeNav::RimJump::Pointis<2> &path,
                                          Statistic &statistic,
                                          OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<2> > paths;
        for(int i=0; i<repeat_times; i++) {
            ec = g2p2.planningWithNode(start, target, init_ptcs, init_etcs, ics_node_topology, paths,
                                       false, false, false,
                                       10);
        }
        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    auto rim_jump_path_planning_20 = [&](const freeNav::RimJump::Pointi<2> &start,
                                         const freeNav::RimJump::Pointi<2> &target,
                                         freeNav::RimJump::Pointis<2> &path,
                                         Statistic &statistic,
                                         OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<2> > paths;
        for(int i=0; i<repeat_times; i++) {
            ec = g2p2.planningWithNode(start, target, init_ptcs, init_etcs, ics_node_topology, paths,
                                       false, false, false,
                                       20);
        }
        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    auto rim_jump_path_planning_40 = [&](const freeNav::RimJump::Pointi<2> &start,
                                          const freeNav::RimJump::Pointi<2> &target,
                                          freeNav::RimJump::Pointis<2> &path,
                                          Statistic &statistic,
                                          OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<2> > paths;
        for(int i=0; i<repeat_times; i++) {
            ec = g2p2.planningWithNode(start, target, init_ptcs, init_etcs, ics_node_topology, paths,
                                       false, false, false,
                                       40);
        }
        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    auto rim_jump_path_planning_80 = [&](const freeNav::RimJump::Pointi<2> &start,
                                          const freeNav::RimJump::Pointi<2> &target,
                                          freeNav::RimJump::Pointis<2> &path,
                                          Statistic &statistic,
                                          OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<2> > paths;
        for(int i=0; i<repeat_times; i++) {
            ec = g2p2.planningWithNode(start, target, init_ptcs, init_etcs, ics_node_topology, paths,
                                       false, false, false,
                                       80);
        }
        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    auto rim_jump_path_planning_160 = [&](const freeNav::RimJump::Pointi<2> &start,
                                      const freeNav::RimJump::Pointi<2> &target,
                                      freeNav::RimJump::Pointis<2> &path,
                                      Statistic &statistic,
                                      OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<2> > paths;
        for(int i=0; i<repeat_times; i++) {
            ec = g2p2.planningWithNode(start, target, init_ptcs, init_etcs, ics_node_topology, paths,
                                       false, false, false,
                                       160);
        }
        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    auto rim_jump_path_planning_320 = [&](const freeNav::RimJump::Pointi<2> &start,
                                          const freeNav::RimJump::Pointi<2> &target,
                                          freeNav::RimJump::Pointis<2> &path,
                                          Statistic &statistic,
                                          OutputStream &output_stream) {
        std::vector<freeNav::RimJump::Path<2> > paths;
        for(int i=0; i<repeat_times; i++) {
            ec = g2p2.planningWithNode(start, target, init_ptcs, init_etcs, ics_node_topology, paths,
                                       false, false, false,
                                       320);
        }
        if (!paths.empty()) path = paths.front();
        else path.clear();
        statistic = g2p2.getStatistic();
        output_stream = g2p2.getOutputStream();
    };

    StatisticSS statisticss;
    OutputStreamSS output_streamss;
    // rim_jump_path_planning
    // ENL_SVG_path_planning
    Point2PointPathPlannings<2, Pointi<2>, Pointi<2> > path_plannings = {rim_jump_path_planning_10,
                                                                         rim_jump_path_planning_20,
                                                                         rim_jump_path_planning_40,
                                                                         rim_jump_path_planning_80,
                                                                         rim_jump_path_planning_160,
                                                                         rim_jump_path_planning_320
                                                                        };
//    delete tgb;
//    delete[] cost_move_base_2d;
    SceneTest2D(map_test_config.at("config_path"), path_plannings, statisticss, output_streamss);
    delete tgb;
    //SceneTest2DIndividual(map_test_config.at("config_path"), path_plannings, statisticss, output_streamss);
    std::ofstream os(map_test_config.at("output_path"));
    //os << "TYPE START_X START_Y TARGET_X TARGET_Y PATH_LENGTH RESET_TIME INITIAL_TIME SEARCH_TIME" << std::endl;
    for (const auto &multi_method_output : output_streamss) {
        for (const auto method_output : multi_method_output) {
            os << method_output << std::endl;
        }
    }
    os.close();
    return true;
}


TEST(RIMJUMP, MASSIVE_DISTINCTIVE_TOPOLOGY_PATH_SEARCH_2D) {
    configs = {
            MapTestConfig_Berlin_1_256, // ok
//            MapTestConfig_Denver_2_512, // ok， fast
//            MapTestConfig_Boston_2_256, // pass, fast
//            MapTestConfig_Milan_2_256, // pass
//            MapTestConfig_Moscow_2_256, // pass, 330 slow
//            MapTestConfig_Shanghai_0_512, // pass, with failed, and failed disappear
//            MapTestConfig_Sydney_1_256, // pass // ok, fast
//            MapTestConfig_Paris_0_512 // ss
            //MapTestConfig_TheFrozenSea // too slow
    }; // single test
    for(const auto& config : configs) {
        SingleMapTestDistinctiveTopology2D(config);
    }
    for(const auto& config : configs) {
        std::cout << config.at("map_name") << ":" << std::endl;
        SingleMapTestDataAnalysis<2>(config, 6);
        std::cout << std::endl;
    }
}










































