//
// Created by yaozhuo on 2021/9/19.
//

#ifndef FREENAV_TEST_LEARN_G2O_H
#define FREENAV_TEST_LEARN_G2O_H

#include <Eigen/Core>
#include <iostream>

#include "g2o/stuff/sampler.h"
#include "g2o/stuff/command_args.h"
#include "g2o/core/sparse_optimizer.h"
#include "g2o/core/block_solver.h"
#include "g2o/core/solver.h"
#include "g2o/core/optimization_algorithm_levenberg.h"
#include "g2o/core/base_vertex.h"
#include "g2o/core/base_unary_edge.h"
#include "g2o/solvers/dense/linear_solver_dense.h"



#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/StdVector>

using namespace std;

/**
 * \brief the params, a, b, and lambda for a * exp(-lambda * t) + b
 */
class VertexParams : public g2o::BaseVertex<3, Eigen::Vector3d>
{
public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW;
    VertexParams()
    {
    }

    virtual bool read(std::istream& /*is*/)
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }

    virtual bool write(std::ostream& /*os*/) const
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }

    virtual void setToOriginImpl()
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
    }

    virtual void oplusImpl(const double* update)
    {
        Eigen::Vector3d::ConstMapType v(update);
        _estimate += v;
    }

};

/**
 * \brief measurement for a point on the curve
 *
 * Here the measurement is the point which is lies on the curve.
 * The error function computes the difference between the curve
 * and the point.
 */
class EdgePointOnCurve : public g2o::BaseUnaryEdge<1, Eigen::Vector2d, VertexParams>
{
public:
    /*
     *  在生成定长的Matrix或Vector对象时，需要开辟内存，调用默认构造函数，
     *  通常x86下的指针是32位，内存位数没对齐就会导致程序运行出错。
     *  而对于动态变量(例如Eigen::VectorXd)会动态分配内存，因此会自动地进行内存对齐。
     */
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    EdgePointOnCurve()
    {
    }
    virtual bool read(std::istream& /*is*/)
    {
        /* C语言中获取函数名，一般是__func__,GCC还支持__FUNCTION__.
         * 同时，__PRETTY_FUNCTION__对函数的打印会带上参数。
         */
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }
    virtual bool write(std::ostream& /*os*/) const
    {
        cerr << __PRETTY_FUNCTION__ << " not implemented yet" << endl;
        return false;
    }

    void computeError()
    {
        const VertexParams* params = static_cast<const VertexParams*>(vertex(0));
        const double& a = params->estimate()(0);
        const double& b = params->estimate()(1);
        const double& lambda = params->estimate()(2);
        double fval = a * exp(-lambda * measurement()(0)) + b;
        _error(0) = fval - measurement()(1);
    }
};

#endif //FREENAV_TEST_LEARN_G2O_H
