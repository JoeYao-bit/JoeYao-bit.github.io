//
// Created by yaozhuo on 2022/7/5.
//

#ifndef FREENAV_PATH_PLANNING_INTERFACE_H
#define FREENAV_PATH_PLANNING_INTERFACE_H

#include "rim_jump/online_search/search_path_with_edge.h"

namespace freeNav::RimJump {

    /* p2p_planning = point to point path planning
     * start: start point of path planning
     * target: target point of path planning
     * path: resulted path
     * statistics: the value we need, path length, time cost, etc
     * return false if failed, otherwise success
     * */
    template <Dimension N, typename START_TYPE, typename TARGET_TYPE>
    using Point2PointPathPlanning = std::function<void (const Pointi<N>& start,
                                                        const TARGET_TYPE& target,
                                                        std::vector<Pointi<N> >& path,
    Statistic& statistic,
            OutputStream& outputStream)>;

    template <Dimension N, typename START_TYPE, typename TARGET_TYPE>
    using Point2PointPathPlannings = std::vector<Point2PointPathPlanning<N, START_TYPE, TARGET_TYPE> >;

    // a couple of start and target for multiple methods
    // return true is all pass, return false is one is failed
    template <Dimension N, typename START_TYPE, typename TARGET_TYPE>
    bool SinglePoint2PointPathPlanningTest(const START_TYPE& start,
                                           const TARGET_TYPE& target,
                                           const Point2PointPathPlanning<N, START_TYPE, TARGET_TYPE>& path_planning,
                                           StatisticS& statistics,
                                           OutputStreamS& output_streams) {
        statistics.clear();
        output_streams.clear();
        bool is_failed = false;
        Statistic statistic;
        OutputStream output_stream;
        Pointis<N> path;
        path_planning(start, target, path, statistic, output_stream);
        statistics.push_back(statistic);
        output_streams.push_back(output_stream);
        if(path.empty()) {
            std::cout << "planning from " << start << " to " <<  target << " failed " << std::endl;
            is_failed = true;
        }
        return !is_failed;
    }

    // a couple of start and target for multiple methods
    // return true is all pass, return false is one is failed
    template <Dimension N, typename START_TYPE, typename TARGET_TYPE>
    bool Point2PointPathPlanningTest(const START_TYPE& start,
                                     const TARGET_TYPE& target,
                                     const Point2PointPathPlannings<N, START_TYPE, TARGET_TYPE>& path_plannings,
                                     StatisticS& statistics,
                                     OutputStreamS& output_streams) {
        statistics.clear();
        output_streams.clear();
        bool is_failed = false;
        for(const auto& path_planning : path_plannings) {
            Statistic statistic;
            OutputStream output_stream;
            Pointis<N> path;
            path_planning(start, target, path, statistic, output_stream);
            statistics.push_back(statistic);
            output_streams.push_back(output_stream);
            if(path.empty()) {
                std::cout << "planning from " << start << " to " <<  target << " failed " << std::endl;
                is_failed = true;
            }
        }
        return !is_failed;
    }

}

#endif //FREENAV_PATH_PLANNING_INTERFACE_H
