//
// Created by yaozhuo on 2022/7/8.
//

#ifndef FREENAV_RIMJUMP_LOADER_H
#define FREENAV_RIMJUMP_LOADER_H

#include "path_planning_interface.h"

//#include "auto_ptr.h"
#include "canvas.h"

namespace freeNav::RimJump {



}

#endif //FREENAV_RIMJUMP_LOADER_H
