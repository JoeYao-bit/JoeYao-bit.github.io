#ifndef _MOTION_PLANNER_H_
#define _MOTION_PLANNER_H_

#include "states.h"
#include "vehicle.h"
#include "environment.h"
namespace freeNav {

    // TODO: how to define cost function ?

    class MotionPlanner {
    public:

        virtual bool plan(ControlCmd & cmd) = 0;

        bool updateTarget(const MotionStates& target_states) {
            if (target_states.empty()) { return false; }
            target_states_ = target_states;
            return true;
        }

        bool setVehicle(VehiclePtr vehicle) {
            if (vehicle == nullptr) { return false; }
            vehicle_ = std::move(vehicle);
            return true;
        }

        bool setEnvironment(EnvironmentPtr environment) {
            if (environment == nullptr) { return false; }
            environment_ = std::move(environment);
            return true;
        }

        VehiclePtr getVehicle() const {
            return vehicle_;
        }

        EnvironmentPtr getEnvironment() const {
            return environment_;
        }

    private:

        EnvironmentPtr environment_;
        VehiclePtr vehicle_;
        MotionStates target_states_;
        Velocity lower_velocity_boundary_;
        Velocity upper_velocity_boundary_;

    };

    typedef std::shared_ptr<MotionPlanner> MotionPlannerPtr;

}
#endif