//
// Created by yaozhuo on 2022/5/14.
//

#ifndef FREENAV_SELF_SORTED_QUEUE_H
#define FREENAV_SELF_SORTED_QUEUE_H

#include "rim_jump/graph_construction/tangent_graph.h"
#include <vector>
#include <assert.h>
/*
 * the queue use in DFS for auto sorted
 * */
namespace freeNav::RimJump {

    template <typename VALUE>
    struct withIndex {
        withIndex(const VALUE& val, const std::shared_ptr<NodeId>& index_in_queue)
                           :val_(val),index_in_queue_(index_in_queue) {
            if(index_in_queue == nullptr)
                index_in_queue_ = std::make_shared<NodeId>(MAX<NodeId>);
        }
        std::shared_ptr<NodeId> index_in_queue_ = nullptr;
        VALUE val_;
    };

    /* T1 must be a comparable type  */
    template<typename KEY, typename VALUE>
    using SortPair = std::pair<KEY, withIndex<VALUE> >;

    /* O(n^2) sort */
    template<typename KEY, typename VALUE>
    class AutoSortQueue {
    public:
        AutoSortQueue() {}

        /* insert a minor value */
        // return the location in queue
        int insertMin(const SortPair<KEY, VALUE>& element) {
            if(queue_.empty()) {
                queue_.push_back(element);
                return 0;
            }
            /* TODO: replace with logN insert */
            for(auto iter = queue_.end() - 1; iter != queue_.begin(); iter--) {
                if((*iter).first > element.first) {
                    iter ++;
                    queue_.insert(iter, element);
                    return iter - queue_.begin();
                }
            }
            if(element.first > queue_[0].first) {
                queue_.insert(queue_.begin(), element);
                return 0;
            } else {
                queue_.insert(queue_.begin() + 1, element);
                return 1;
            }
        }

        SortPair<KEY, VALUE> popMin() {
            emptyQueueCheck();
            auto retv = queue_.back();
            queue_.pop_back();
            return retv;
        }

        const SortPair<KEY, VALUE>& getMin() const {
            emptyQueueCheck();
            return queue_.back();
        }

        const std::vector<SortPair<KEY, VALUE> > & queue() const {
            return queue_;
        }

        static std::string toValueString(const std::vector<SortPair<KEY, VALUE> > & queue) {
            if(queue.empty()) return "";
            std::stringstream ssr;
            for(const auto& pair : queue) {
                ssr << "(" << pair.first << "," << pair.second.val_ << " | id: " << * (pair.second.index_in_queue_) << ") > ";
            }
            return ssr.str();
        }

    private:

        void emptyQueueCheck() {
            if(queue_.empty()) {
                std::cout << "ASQ::pM: empty queue" << std::endl;
                exit(0);
            }
        }

        std::vector<SortPair<KEY, VALUE> > queue_;

    };

    template<typename KEY, typename VALUE>
    using SortQueue = std::vector<SortPair<KEY, VALUE> >;


    int HeapInsert(int *heap, int n, int num);
    int HeapDelete(int *heap, int n);
    int HeapAdjust(int *heap, int top, int n);
    int HeapSort(int *heap, int n);
    int CreatHeap(int *array, int n);

    template<typename KEY, typename VALUE>
    int HeapInsert(SortQueue<KEY, VALUE>& heap, int n, const SortPair<KEY, VALUE>& num)
    {
        int i, j;

        heap[n] = num;
        i = n;
        j = (n - 1) / 2;

        while (j >= 0 && i != 0)
        {
            if (heap[j].first <= num.first)
                break;
            heap[i] = heap[j];
            i = j;
            j = (i - 1) / 2;
        }
        heap[i] = num;

        return 0;
    }

    template<typename KEY, typename VALUE>
    int HeapAdjust(SortQueue<KEY, VALUE>& heap, int top, int n)
    {
        int j = 2 * top + 1;
        SortPair<KEY, VALUE> temp = heap[top];

        while (j < n)
        {
            if (j + 1 < n && heap[j + 1].first < heap[j].first)
                j++;
            if (heap[j].first >= temp.first)
                break;
            heap[top] = heap[j];
            top = j;
            j = 2 * top + 1;
        }
        heap[top] = temp;
        return 0;
    }

    template<typename KEY, typename VALUE>
    int HeapDelete(SortQueue<KEY, VALUE>& heap, int n)
    {
        heap[0] = heap[n - 1];
        HeapAdjust(heap, 0, n - 1);
        return 0;
    }


    template<typename KEY, typename VALUE>
    int HeapSort(SortQueue<KEY, VALUE>& heap, int n)
    {
        int i;
        SortPair<KEY, VALUE> temp;

        for (i = n - 1; i > 0; i--)
        {
            temp = heap[0];
            heap[0] = heap[i];
            heap[i] = temp;
            HeapAdjust(heap, 0, i);
        }
        return 0;
    }

    template<typename KEY, typename VALUE>
    int CreatHeap(SortQueue<KEY, VALUE>& heap, int n)
    {
        int i;
        for (i = (n - 2) / 2; i >= 0; i--)
        {
            HeapAdjust(heap, i, n);
        }
        return 0;
    }

    // key for sort, value for store
    template<typename KEY, typename VALUE>
    class AutoSortHeap {
    public:

        explicit AutoSortHeap(int max_size) {
            heap_ = SortQueue<KEY, VALUE>(max_size, {MAX<KEY>, withIndex<VALUE>(VALUE(), nullptr)});
        }

        void reset() {
            for(auto& element : heap_) {
                if(*element.second.index_in_queue_ != MAX<NodeId>) {
                    element = {MAX<KEY>, withIndex<VALUE>(VALUE(), nullptr)};
                } else {
                    break;
                }
            }
            count_ = 0;
        }

        int HeapInsert(const SortPair<KEY, VALUE>& element)
        {

            int i, j;
            if(count_ == heap_.size()) {
                std::cout << __FUNCTION__ << " heap over size " << std::endl;
            }
            heap_[count_] = element;
            * heap_[count_].second.index_in_queue_ = count_;
            i = count_;
            j = (count_ - 1) / 2;

            while (j >= 0 && i != 0)
            {
                if (heap_[j].first <= element.first)
                    break;
                heap_[i] = heap_[j];
                * heap_[i].second.index_in_queue_ = i;
                i = j;
                j = (i - 1) / 2;
            }
            heap_[i] = element;
            * heap_[i].second.index_in_queue_ = i;
            count_ ++;
            return 0;
        }

        SortPair<KEY, VALUE> HeapPopMin()
        {
            if(count_ <= 0) return {MAX<KEY>, withIndex<VALUE>(VALUE(), nullptr)};
            auto retv = heap_[0];
            heap_[0] = heap_[count_ - 1];
            * heap_[0].second.index_in_queue_ = 0;
            count_ --;
            HeapAdjust(0);
            * retv.second.index_in_queue_ = MAX<NodeId>;
            return retv;
        }

        const SortPair<KEY, VALUE>& HeapGetMin() const
        {
            if(count_ == 0) {
                return {MAX<KEY>, VALUE()};
            }
            auto retv = heap_[0];
            return retv;
        }

        std::string toKeysString() {
            if(heap_.empty()) return "";
            std::stringstream ssr;
            for(int i=0; i<count_; i++) {
                const auto& pair = heap_[i];
                ssr << "(" << pair.first << "," << pair.second.val_ << " | id: " << * (pair.second.index_in_queue_)
                << ") > ";
            }
            return ssr.str();
        }

        bool isEmpty() const {
            return count_ <= 0;
        }

        int size() const {
            return count_;
        }

        void updateValue(int index, const KEY& key) {
            if(index >= count_) {
                std::cout << "index " << index << " over size " << count_ << std::endl;
                return;
            }
            heap_[index].first = key;
            HeapAdjustWhenBecomeSmaller(index);
        }

        void HeapAdjustWhenBecomeSmaller(int index) {
            KEY key = heap_[index].first;
            int temp_index = index;
            while(1) {
                int parent_index = temp_index == 1 ? 0 : temp_index/2;
                if(heap_[parent_index].first > key) {
                    std::swap(heap_[parent_index], heap_[temp_index]);
                    *heap_[temp_index].second.index_in_queue_   = temp_index;
                    *heap_[parent_index].second.index_in_queue_ = parent_index;
                }
                if(parent_index == 0) break;
                temp_index = parent_index;
            }
        }


    private:

        int HeapAdjust(int top)
        {
            int j = 2 * top + 1;
            SortPair<KEY, VALUE> temp = heap_[top];

            while (j < count_)
            {
                if (j + 1 < count_ && heap_[j + 1].first < heap_[j].first)
                    j++;
                if (heap_[j].first >= temp.first)
                    break;
                heap_[top] = heap_[j];
                *heap_[top].second.index_in_queue_ = top;
                top = j;
                j = 2 * top + 1;
            }
            heap_[top] = temp;
            *heap_[top].second.index_in_queue_ = top;
            return 0;
        }

        SortQueue<KEY, VALUE> heap_;
        int count_ = 0;
    };

}
#endif //FREENAV_SELF_SORTED_QUEUE_H
