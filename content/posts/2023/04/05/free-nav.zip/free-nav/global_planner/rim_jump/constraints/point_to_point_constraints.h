//
// Created by yaozhuo on 2022/2/19.
//

#ifndef FREENAV_POINT_TO_POINT_CONSTRAINTS_H
#define FREENAV_POINT_TO_POINT_CONSTRAINTS_H

#include "rim_jump/graph_construction/tangent_graph.h"
#include "rim_jump/surface_processor/surface_process.h"

namespace freeNav::RimJump {

    /* PTC: point to point constraint
    * necessary constraint of tangent line, it must be collision free */
    // NOTICE: current PTC_DoNotCrossObstacle cause loss of useful line
    template <Dimension N>
    bool PTC_DoNotCrossObstacle(RoadMapGraphPtr<N>& tg, const GridPtr<N>& tc1, const GridPtr<N>& tc2, IS_OCCUPIED_FUNC<N> is_occupied, const Pointis<N - 1>& neightbor) {
        return !LineCrossObstacle(tc1->pt_, tc2->pt_, is_occupied, neightbor);
    }

    // cross locally means there is both collide and free connection from pt1 to sg2's nearby
    template <Dimension N>
    bool LineCrossObstacleLocal(const Pointi<N>& pt1, const GridPtr<N>& sg2, IS_OCCUPIED_FUNC<N> is_occupied) {
        if(pt1 == sg2->pt_) return true;
        bool collide_flag = false, free_flag = false;
        auto dist_square = (pt1 - sg2->pt_).Square();
        int min_free_dist = MAX<int>;
        int max_occ_dist = 0;

        for(const auto &surface_grid : sg2->nearby_surface_pts_) {
            // filter surface_grid that closer to pt1 than sg2
            for (const auto &obst : sg2->nearby_obst_pts_) {
                if(pointDistToLine(obst, pt1, surface_grid) < 1 - 1e-9) {
                    collide_flag = true;
                    int temp_dist = (pt1 - surface_grid).Square();
                    if(temp_dist > max_occ_dist) max_occ_dist = temp_dist;
                }
                else {
                    free_flag = true;
                    int temp_dist = (pt1 - surface_grid).Square();
                    if(temp_dist < min_free_dist) min_free_dist = temp_dist;
                }
            }
            if(collide_flag && free_flag) return true;
        }
        return false;
    }

    template <Dimension N>
    bool PTC_LocalCrossPartially(RoadMapGraphPtr<N>& tg, const GridPtr<N>& tc1, const GridPtr<N>& tc2, IS_OCCUPIED_FUNC<N> is_occupied, const Pointis<N - 1>& neightbor) {
        if(LineCrossObstacleLocal(tc1->pt_, tc2, is_occupied)) { return true; }
        else return false;
    }

    bool PTC_CrosserToObstacle_2D(RoadMapGraphPtr<2>& tg, const GridPtr<2>& tc1, const GridPtr<2>& tc2, IS_OCCUPIED_FUNC<2> is_occupied, const Pointis<1>& neightbor);

}

#endif //FREENAV_POINT_TO_POINT_CONSTRAINTS_H
