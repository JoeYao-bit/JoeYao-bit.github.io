//
// Created by yaozhuo on 2023/2/12.
//

#ifndef FREENAV_BREADTH_FIRST_SEARCH_WITHOUT_EDGE_H
#define FREENAV_BREADTH_FIRST_SEARCH_WITHOUT_EDGE_H

#include "search_path_with_node.h"

namespace freeNav::RimJump {


    template<Dimension N>
    template<typename TARGET_TYPE>
    ExitCode GeneralGraphPathPlannerWithNode<N>::BreadthFirstSearchWithNode(const PathPointWithNodePtrs <N> &init_set,
                                                                            const NodeIterationConstraints <N, TARGET_TYPE> &ics, // when dfs, only considering ics ?
                                                                            RoadMapNodeTraitDeques <N> &final_set, // resulted path set
                                                                            const TARGET_TYPE &target
    ) {
        auto & es = tg_->edges_;
        auto & ns = tg_->nodes_;
        global_minimum_path_length = MAX<PathLen>;

        if(init_set.empty()) {
            std::cerr << __FUNCTION__ << ": init_set.empty() " << std::endl;
            return ExitCode::ILLEGAL_INPUT_INITIAL_SET;
        }

        current_set_.reset();
        final_set.clear();
        /* 1, create initial set */
        PathPointWithNodePtr<N> shortest_path = nullptr; // the shortest path in the initial path
        PathLen init_shortest_len = MAX<PathLen>, temp_len;
        PathPointWithNodePtrs<N> current_set = init_set, next_set;


        PathLen future_length = MAX<PathLen>, temp_future_length;
        int count = 0;
        NodeId future_node_id = MAX<NodeId>;
        bool reach_target = false;
        int reach_target_count = 0;
        while(!current_set.empty() && !isAllReachTarget(current_set, -1, currentTime())) {
            count ++;
            next_set.clear();
            reach_target_count = 0;
            for(auto & current_path : current_set) {
                future_node_id = current_path->last_node_->sg_->node_id_;
                if(isReachTarget(current_path, currentTime())) {
                    if (data_->close_node_to(ns[future_node_id], false, currentTime()) != MAX<NodeId> &&
                        !isEdgeTransferLegal(tg_,
                                         current_path->from()->last_node_,
                                         ns[future_node_id],
                                         ns[data_->close_node_to(ns[future_node_id], false, currentTime())], tg_->etcs_))
                        continue;

                    reach_target_count ++;
                    PathLen complete_length = current_path->length_ + data_->dist_to(current_path->last_node_, false, currentTime());
                    if(global_minimum_path_length > complete_length) {
                        global_minimum_path_length = complete_length;
                        shortest_path = current_path;
                    };
                    next_set.push_back(current_path);
                    continue;
                }
                if(global_shortest_ && current_path->length_ > data_->dist_to(ns[future_node_id], true, currentTime()) + EPS_FR) continue;


                if(global_shortest_) {
                    heuristic_length_ = current_path->length_;
                    if(heuristic_length_ > global_minimum_path_length) continue;
                }
                for (const auto &candidate_node_id : tg_->nextNodes(ns[future_node_id])) {
                    if (!isEdgeTransferLegal(tg_,
                                             current_path->from()->last_node_,
                                             ns[future_node_id],
                                             ns[candidate_node_id], tg_->etcs_))
                        continue;

                    bool is_legal = true;
                    for (const auto &ic : ics) {
                        if (!ic(tg_, data_, current_path, ns[candidate_node_id], target)) {
                            is_legal = false;
                            break;
                        }
                    }
                    if(!is_legal) continue;
                    temp_future_length = current_path->length_ +
                                         (ns[future_node_id]->sg_->pt_ - ns[candidate_node_id]->sg_->pt_).Norm();

                    // TODO: allow update value in heap, when dist change to smaller value
                    if (global_shortest_) {

                        if(temp_future_length > data_->dist_to(ns[candidate_node_id], true, currentTime()) + EPS_FR)
                            continue;

                        data_->dist_to(ns[candidate_node_id], true, currentTime()) = temp_future_length;
                        data_->close_node_to(ns[candidate_node_id], true, currentTime()) = future_node_id;

                    }


                    next_set.push_back(std::make_shared<PathPointWithNode<N> >(tg_, current_path, ns[candidate_node_id]));
                }
            }
            if(first_reach_count_ > 0 && reach_target_count >= first_reach_count_) {
                break;
            }
            std::swap(next_set, current_set);
        }
        // get result path
        final_set.clear();
        if(!current_set.empty()) {
            if(!global_shortest_) {
                for (auto &final_path : current_set) {

                    if(!isReachTarget(final_path, currentTime())) continue;

                    auto final_node = data_->close_node_to(final_path->last_node_, false, currentTime());

                    if(final_node != MAX<NodeId> && !isEdgeTransferLegal(tg_, final_path->from()->last_node_,
                                            final_path->last_node_,
                                            ns[data_->close_node_to(final_path->last_node_, false, currentTime())],
                                            tg_->etcs_)) continue;

                    const auto &result_path = PathTransformToContinuousEdgesWithNode(tg_, data_, final_path, currentTime());
                    final_set.push_back(result_path);
                }
            } else {
                const auto &result_path = PathTransformToContinuousEdgesWithNode(tg_, data_, shortest_path, currentTime());
                final_set.push_back(result_path);
            }
        }

        if(!final_set.empty()) { return ExitCode::SUCCESS; }
        else { return ExitCode::FAILED; }
    }

}

#endif //FREENAV_BREADTH_FIRST_SEARCH_WITHOUT_EDGE_H
