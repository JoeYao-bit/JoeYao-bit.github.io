//
// Created by yaozhuo on 2022/1/3.
//

#include <cfloat>
#include "constraints/iteration_constraints.h"
#include "constraints/node_iteration_constraints.h"

namespace freeNav::RimJump {

    PathLen global_minimum_path_length = MAX<PathLen>;

    int determinant(const int& v1, const int& v2, const int& v3, const int& v4)  // 行列式
    {
        return (v1*v3-v2*v4);
    }

    bool intersect3(const Pointi<2>& a, const Pointi<2>& b, const Pointi<2>& c, const Pointi<2>& d)
    {
        if(max(c[0],d[0]) < min(a[0],b[0]) ||
           max(a[0],b[0]) < min(c[0],d[0]) ||
           max(c[1],d[1]) < min(a[1],b[1]) ||
           max(a[1],b[1]) < min(c[1],d[1])) {
            return false;
        }

        if ((((a[0] - c[0])*(d[1] - c[1]) - (a[1] - c[1])*(d[0] - c[0]))*
             ((b[0] - c[0])*(d[1] - c[1]) - (b[1] - c[1])*(d[0] - c[0]))) > 0 ||
            (((c[0] - a[0])*(b[1] - a[1]) - (c[1] - a[1])*(b[0] - a[0]))*
             ((d[0] - a[0])*(b[1] - a[1]) - (d[1] - a[1])*(b[0] - a[0]))) > 0)
        {
            return false;
        }
        return true;

    }

}