//
// Created by yaozhuo on 2022/5/14.
//

#include "rim_jump/online_search/self_sorted_queue.h"

namespace freeNav::RimJump {

    int HeapInsert(int *heap, int n, int num)
    {
        int i, j;

        heap[n] = num;
        i = n;
        j = (n - 1) / 2;

        while (j >= 0 && i != 0)
        {
            if (heap[j] <= num)
                break;
            heap[i] = heap[j];
            i = j;
            j = (i - 1) / 2;
        }
        heap[i] = num;

        return 0;
    }

    int HeapDelete(int *heap, int n)
    {
        heap[0] = heap[n - 1];
        HeapAdjust(heap, 0, n - 1);
        return 0;
    }

    int HeapAdjust(int *heap, int top, int n)
    {
        int j = 2 * top + 1;
        int temp = heap[top];

        while (j < n)
        {
            if (j + 1 < n&&heap[j + 1] < heap[j])
                j++;
            if (heap[j] >= temp)
                break;
            heap[top] = heap[j];
            top = j;
            j = 2 * top + 1;
        }
        heap[top] = temp;
        return 0;
    }

    int HeapSort(int *heap, int n)
    {
        int i;
        int temp;

        for (i = n - 1; i > 0; i--)
        {
            temp = heap[0];
            heap[0] = heap[i];
            heap[i] = temp;
            HeapAdjust(heap, 0, i);
        }
        return 0;
    }

    int CreatHeap(int *array, int n)
    {
        int i;
        for (i = (n - 2) / 2; i >= 0; i--)
        {
            HeapAdjust(array, i, n);
        }
        return 0;
    }

}