//
// Created by yaozhuo on 2022/1/20.
//

#ifndef FREENAV_LOG_MACROS_H
#define FREENAV_LOG_MACROS_H

// remove log that lower than the enum
#define GOOGLE_STRIP_LOG 0
#include <glog/logging.h>


#endif //FREENAV_LOG_MACROS_H
