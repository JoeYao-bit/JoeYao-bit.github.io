//
// Created by yaozhuo on 2021/9/2.
//

#ifndef _2D_GRID_ENVIRONMENT_H_
#define _2D_GRID_ENVIRONMENT_H_
#include "environment.h"

namespace freeNav::RimJump {

    class Grid_2D_Environment : Environment{
        //
    };

}
#endif //FREENAV_2D_GRID_ENVIRONMENT_H
