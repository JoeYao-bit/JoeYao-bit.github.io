//
// Created by yaozhuo on 2021/11/27.
//

#ifndef FREENAV_TEB_EDGES_H
#define FREENAV_TEB_EDGES_H


#include "g2o/stuff/sampler.h"
#include "g2o/stuff/command_args.h"
#include "g2o/core/sparse_optimizer.h"
#include "g2o/core/block_solver.h"
#include "g2o/core/solver.h"
#include "g2o/core/optimization_algorithm_levenberg.h"
#include "g2o/core/base_vertex.h"
#include "g2o/core/base_unary_edge.h"
#include "g2o/core/base_binary_edge.h"
#include "g2o/core/base_multi_edge.h"
#include "g2o/solvers/dense/linear_solver_dense.h"
#include "pose_se2.h"


#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/StdVector>

#include "misc.h"
#include "penalties.h"
#include "teb_vertex.h"
#include "basic_base_teb_edges.h"

using namespace std;

/**
 * @class EdgeVelocity
 * @brief Edge defining the cost function for limiting the translational and rotational velocity to a window.
 *
 * The edge depends on three vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \Delta T_i \f$ and minimizes: \n
 * \f$ \min \textrm{penaltyInterval}( [v,omega]^T ) \cdot weight \f$. \n
 * \e v is calculated using the difference quotient and the position parts of both poses. \n
 * \e omega is calculated using the difference quotient of both yaw angles followed by a normalization to [-pi, pi]. \n
 * \e weight can be set using setInformation(). \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval(). \n
 * The dimension of the error / cost vector is 2: the first component represents the translational velocity and
 * the second one the rotational velocity.
 * @see TebOptimalPlanner::AddEdgesVelocity
 * @remarks Do not forget to call setTebConfig()
 */
class EdgeVelocity : public BaseTebMultiEdge<2, double>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeVelocity()
    {
        this->resize(3); // Since we derive from a g2o::BaseMultiEdge, set the desired number of vertices
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        //ROS_ASSERT_MSG(cfg_, "You must call setTebConfig on EdgeVelocity()");
        const VertexPose* conf1 = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* conf2 = static_cast<const VertexPose*>(_vertices[1]);
        const VertexTimeDiff* deltaT = static_cast<const VertexTimeDiff*>(_vertices[2]);

        const Eigen::Vector2d deltaS = conf2->estimate().position() - conf1->estimate().position();

        double dist = deltaS.norm();
        const double angle_diff = g2o::normalize_theta(conf2->theta() - conf1->theta());
        /* use Euclid dist between two position or the arc that connect them ? */
        if (cfg_->trajectory.exact_arc_length && angle_diff != 0)
        {
            double radius =  dist/(2*sin(angle_diff/2));
            dist = fabs( angle_diff * radius ); // actual arg length!
        }
        /* calculate combined linear velocity */
        double vel = dist / deltaT->estimate();

        /* use fast_sigmoid to stable the value when near zero */
//     vel *= g2o::sign(deltaS[0]*cos(conf1->theta()) + deltaS[1]*sin(conf1->theta())); // consider direction
        vel *= fast_sigmoid( 100 * (deltaS.x()*cos(conf1->theta()) + deltaS.y()*sin(conf1->theta())) ); // consider direction

        const double omega = angle_diff / deltaT->estimate();

        _error[0] = penaltyBoundToInterval(vel, -cfg_->robot.max_vel_x_backwards, cfg_->robot.max_vel_x,cfg_->optim.penalty_epsilon);
        _error[1] = penaltyBoundToInterval(omega, cfg_->robot.max_vel_theta,cfg_->optim.penalty_epsilon);

        //ROS_ASSERT_MSG(std::isfinite(_error[0]), "EdgeVelocity::computeError() _error[0]=%f _error[1]=%f\n",_error[0],_error[1]);
    }

public:

    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

};

/**
 * @class EdgeTimeOptimal
 * @brief Edge defining the cost function for minimizing transition time of the trajectory.
 *
 * The edge depends on a single vertex \f$ \Delta T_i \f$ and minimizes: \n
 * \f$ \min \Delta T_i^2 \cdot scale \cdot weight \f$. \n
 * \e scale is determined using the penaltyEquality() function, since we experiences good convergence speeds with it. \n
 * \e weight can be set using setInformation() (something around 1.0 seems to be fine). \n
 * @see TebOptimalPlanner::AddEdgesTimeOptimal
 * @remarks Do not forget to call setTebConfig()
 */
class EdgeTimeOptimal : public BaseTebUnaryEdge<1, double, VertexTimeDiff>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeTimeOptimal()
    {
        this->setMeasurement(0.);
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        //ROS_ASSERT_MSG(cfg_, "You must call setTebConfig on EdgeTimeOptimal()");
        const VertexTimeDiff* timediff = static_cast<const VertexTimeDiff*>(_vertices[0]);

        _error[0] = timediff->dt();

        //ROS_ASSERT_MSG(std::isfinite(_error[0]), "EdgeTimeOptimal::computeError() _error[0]=%f\n",_error[0]);
    }


public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/**
 * @class EdgeShortestPath
 * @brief Edge defining the cost function for minimizing the Euclidean distance between two consectuive poses.
 *
 * @see TebOptimalPlanner::AddEdgesShortestPath
 */
class EdgeShortestPath : public BaseTebBinaryEdge<1, double, VertexPose, VertexPose> {
public:
    /**
     * @brief Construct edge.
     */
    EdgeShortestPath() { this->setMeasurement(0.); }

    /**
     * @brief Actual cost function
     */
    void computeError() {
        if(!cfg_)
            std::cerr << "You must call setTebConfig on EdgeShortestPath()" << std::endl;
        const VertexPose *pose1 = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose *pose2 = static_cast<const VertexPose*>(_vertices[1]);
        _error[0] = (pose2->position() - pose1->position()).norm();

        if(!std::isfinite(_error[0]))
            std::cerr << "EdgeShortestPath::computeError() _error[0]=" << _error[0] << std::endl;
    }

public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

/**
 * @class EdgeVelocityHolonomic
 * @brief Edge defining the cost function for limiting the translational and rotational velocity according to x,y and theta.
 *
 * The edge depends on three vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \Delta T_i \f$ and minimizes: \n
 * \f$ \min \textrm{penaltyInterval}( [vx,vy,omega]^T ) \cdot weight \f$. \n
 * \e vx denotes the translational velocity w.r.t. x-axis (computed using finite differneces). \n
 * \e vy denotes the translational velocity w.r.t. y-axis (computed using finite differneces). \n
 * \e omega is calculated using the difference quotient of both yaw angles followed by a normalization to [-pi, pi]. \n
 * \e weight can be set using setInformation(). \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval(). \n
 * The dimension of the error / cost vector is 3: the first component represents the translational velocity w.r.t. x-axis,
 * the second one w.r.t. the y-axis and the third one the rotational velocity.
 * @see TebOptimalPlanner::AddEdgesVelocity
 * @remarks Do not forget to call setTebConfig()
 */
class EdgeVelocityHolonomic : public BaseTebMultiEdge<3, double>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeVelocityHolonomic()
    {
        this->resize(3); // Since we derive from a g2o::BaseMultiEdge, set the desired number of vertices
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if(!cfg_) std::cerr << "You must call setTebConfig on EdgeVelocityHolonomic()" << std::endl;
        const VertexPose* conf1 = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* conf2 = static_cast<const VertexPose*>(_vertices[1]);
        const VertexTimeDiff* deltaT = static_cast<const VertexTimeDiff*>(_vertices[2]);
        Eigen::Vector2d deltaS = conf2->position() - conf1->position();

        double cos_theta1 = std::cos(conf1->theta());
        double sin_theta1 = std::sin(conf1->theta());

        // transform conf2 into current robot frame conf1 (inverse 2d rotation matrix)
        double r_dx =  cos_theta1*deltaS.x() + sin_theta1*deltaS.y();
        double r_dy = -sin_theta1*deltaS.x() + cos_theta1*deltaS.y();

        double vx = r_dx / deltaT->estimate();
        double vy = r_dy / deltaT->estimate();
        double omega = g2o::normalize_theta(conf2->theta() - conf1->theta()) / deltaT->estimate();

        _error[0] = penaltyBoundToInterval(vx, -cfg_->robot.max_vel_x_backwards, cfg_->robot.max_vel_x, cfg_->optim.penalty_epsilon);
        _error[1] = penaltyBoundToInterval(vy, cfg_->robot.max_vel_y, 0.0); // we do not apply the penalty epsilon here, since the velocity could be close to zero
        _error[2] = penaltyBoundToInterval(omega, cfg_->robot.max_vel_theta,cfg_->optim.penalty_epsilon);

        if(!(std::isfinite(_error[0]) && std::isfinite(_error[1]) && std::isfinite(_error[2])) )
                      printf("EdgeVelocityHolonomic::computeError() _error[0]=%f _error[1]=%f _error[2]=%f\n",_error[0],_error[1],_error[2]);
    }


public:

    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

};


/**
 * @class EdgeViaPoint
 * @brief Edge defining the cost function for pushing a configuration towards a via point
 *
 * The edge depends on a single vertex \f$ \mathbf{s}_i \f$ and minimizes: \n
 * \f$ \min  dist2point \cdot weight \f$. \n
 * \e dist2point denotes the distance to the via point. \n
 * \e weight can be set using setInformation(). \n
 * @see TebOptimalPlanner::AddEdgesViaPoints
 * @remarks Do not forget to call setTebConfig() and setViaPoint()
 */
class EdgeViaPoint : public BaseTebUnaryEdge<1, const Eigen::Vector2d*, VertexPose>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeViaPoint()
    {
        _measurement = NULL;
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if( !(cfg_ && _measurement) )
            std::cerr << "You must call setTebConfig(), setViaPoint() on EdgeViaPoint()" << std::endl;
        const VertexPose* bandpt = static_cast<const VertexPose*>(_vertices[0]);

        _error[0] = (bandpt->position() - *_measurement).norm();

        if(!std::isfinite(_error[0])) std::cerr << "EdgeViaPoint::computeError() _error[0]=" << _error[0] << std::endl;
    }

    /**
     * @brief Set pointer to associated via point for the underlying cost function
     * @param via_point 2D position vector containing the position of the via point
     */
    void setViaPoint(const Eigen::Vector2d* via_point)
    {
        _measurement = via_point;
    }

    /**
     * @brief Set all parameters at once
     * @param cfg TebConfig class
     * @param via_point 2D position vector containing the position of the via point
     */
    void setParameters(const TebConfig& cfg, const Eigen::Vector2d* via_point)
    {
        cfg_ = &cfg;
        _measurement = via_point;
    }

public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

};


/**
 * @class EdgeAcceleration
 * @brief Edge defining the cost function for limiting the translational and rotational acceleration.
 *
 * The edge depends on five vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \mathbf{s}_{ip2}, \Delta T_i, \Delta T_{ip1} \f$ and minimizes:
 * \f$ \min \textrm{penaltyInterval}( [a, omegadot } ]^T ) \cdot weight \f$. \n
 * \e a is calculated using the difference quotient (twice) and the position parts of all three poses \n
 * \e omegadot is calculated using the difference quotient of the yaw angles followed by a normalization to [-pi, pi]. \n
 * \e weight can be set using setInformation() \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval() \n
 * The dimension of the error / cost vector is 2: the first component represents the translational acceleration and
 * the second one the rotational acceleration.
 * @see TebOptimalPlanner::AddEdgesAcceleration
 * @see EdgeAccelerationStart
 * @see EdgeAccelerationGoal
 * @remarks Do not forget to call setTebConfig()
 * @remarks Refer to EdgeAccelerationStart() and EdgeAccelerationGoal() for defining boundary values!
 */
class EdgeAcceleration : public BaseTebMultiEdge<2, double>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeAcceleration()
    {
        this->resize(5);
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if(!cfg_) printf("You must call setTebConfig on EdgeAcceleration()");
        const VertexPose* pose1 = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* pose2 = static_cast<const VertexPose*>(_vertices[1]);
        const VertexPose* pose3 = static_cast<const VertexPose*>(_vertices[2]);
        const VertexTimeDiff* dt1 = static_cast<const VertexTimeDiff*>(_vertices[3]);
        const VertexTimeDiff* dt2 = static_cast<const VertexTimeDiff*>(_vertices[4]);

        // VELOCITY & ACCELERATION
        const Eigen::Vector2d diff1 = pose2->position() - pose1->position();
        const Eigen::Vector2d diff2 = pose3->position() - pose2->position();

        double dist1 = diff1.norm();
        double dist2 = diff2.norm();
        const double angle_diff1 = g2o::normalize_theta(pose2->theta() - pose1->theta());
        const double angle_diff2 = g2o::normalize_theta(pose3->theta() - pose2->theta());

        if (cfg_->trajectory.exact_arc_length) // use exact arc length instead of Euclidean approximation
        {
            if (angle_diff1 != 0)
            {
                const double radius =  dist1/(2*sin(angle_diff1/2));
                dist1 = fabs( angle_diff1 * radius ); // actual arg length!
            }
            if (angle_diff2 != 0)
            {
                const double radius =  dist2/(2*sin(angle_diff2/2));
                dist2 = fabs( angle_diff2 * radius ); // actual arg length!
            }
        }

        double vel1 = dist1 / dt1->dt();
        double vel2 = dist2 / dt2->dt();


        // consider directions
//     vel1 *= g2o::sign(diff1[0]*cos(pose1->theta()) + diff1[1]*sin(pose1->theta()));
//     vel2 *= g2o::sign(diff2[0]*cos(pose2->theta()) + diff2[1]*sin(pose2->theta()));
        vel1 *= fast_sigmoid( 100*(diff1.x()*cos(pose1->theta()) + diff1.y()*sin(pose1->theta())) );
        vel2 *= fast_sigmoid( 100*(diff2.x()*cos(pose2->theta()) + diff2.y()*sin(pose2->theta())) );

        const double acc_lin  = (vel2 - vel1)*2 / ( dt1->dt() + dt2->dt() );


        _error[0] = penaltyBoundToInterval(acc_lin,cfg_->robot.acc_lim_x,cfg_->optim.penalty_epsilon);

        // ANGULAR ACCELERATION
        const double omega1 = angle_diff1 / dt1->dt();
        const double omega2 = angle_diff2 / dt2->dt();
        const double acc_rot  = (omega2 - omega1)*2 / ( dt1->dt() + dt2->dt() );

        _error[1] = penaltyBoundToInterval(acc_rot,cfg_->robot.acc_lim_theta,cfg_->optim.penalty_epsilon);


        if(!std::isfinite(_error[0]))  printf("EdgeAcceleration::computeError() translational: _error[0]=%f\n",_error[0]);
        if(!std::isfinite(_error[1])) printf("EdgeAcceleration::computeError() rotational: _error[1]=%f\n",_error[1]);
    }



#ifdef USE_ANALYTIC_JACOBI
    #if 0
  /*
   * @brief Jacobi matrix of the cost function specified in computeError().
   */
  void linearizeOplus()
  {
    ROS_ASSERT_MSG(cfg_, "You must call setTebConfig on EdgeAcceleration()");
    const VertexPointXY* conf1 = static_cast<const VertexPointXY*>(_vertices[0]);
    const VertexPointXY* conf2 = static_cast<const VertexPointXY*>(_vertices[1]);
    const VertexPointXY* conf3 = static_cast<const VertexPointXY*>(_vertices[2]);
    const VertexTimeDiff* deltaT1 = static_cast<const VertexTimeDiff*>(_vertices[3]);
    const VertexTimeDiff* deltaT2 = static_cast<const VertexTimeDiff*>(_vertices[4]);
    const VertexOrientation* angle1 = static_cast<const VertexOrientation*>(_vertices[5]);
    const VertexOrientation* angle2 = static_cast<const VertexOrientation*>(_vertices[6]);
    const VertexOrientation* angle3 = static_cast<const VertexOrientation*>(_vertices[7]);

    Eigen::Vector2d deltaS1 = conf2->estimate() - conf1->estimate();
    Eigen::Vector2d deltaS2 = conf3->estimate() - conf2->estimate();
    double dist1 = deltaS1.norm();
    double dist2 = deltaS2.norm();

    double sum_time = deltaT1->estimate() + deltaT2->estimate();
    double sum_time_inv = 1 / sum_time;
    double dt1_inv = 1/deltaT1->estimate();
    double dt2_inv = 1/deltaT2->estimate();
    double aux0 = 2/sum_time_inv;
    double aux1 = dist1 * deltaT1->estimate();
    double aux2 = dist2 * deltaT2->estimate();

    double vel1 = dist1 * dt1_inv;
    double vel2 = dist2 * dt2_inv;
    double omega1 = g2o::normalize_theta( angle2->estimate() - angle1->estimate() ) * dt1_inv;
    double omega2 = g2o::normalize_theta( angle3->estimate() - angle2->estimate() ) * dt2_inv;
    double acc = (vel2 - vel1) * aux0;
    double omegadot = (omega2 - omega1) * aux0;
    double aux3 = -acc/2;
    double aux4 = -omegadot/2;

    double dev_border_acc = penaltyBoundToIntervalDerivative(acc, tebConfig.robot_acceleration_max_trans,optimizationConfig.optimization_boundaries_epsilon,optimizationConfig.optimization_boundaries_scale,optimizationConfig.optimization_boundaries_order);
    double dev_border_omegadot = penaltyBoundToIntervalDerivative(omegadot, tebConfig.robot_acceleration_max_rot,optimizationConfig.optimization_boundaries_epsilon,optimizationConfig.optimization_boundaries_scale,optimizationConfig.optimization_boundaries_order);

    _jacobianOplus[0].resize(2,2); // conf1
    _jacobianOplus[1].resize(2,2); // conf2
    _jacobianOplus[2].resize(2,2); // conf3
    _jacobianOplus[3].resize(2,1); // deltaT1
    _jacobianOplus[4].resize(2,1); // deltaT2
    _jacobianOplus[5].resize(2,1); // angle1
    _jacobianOplus[6].resize(2,1); // angle2
    _jacobianOplus[7].resize(2,1); // angle3

    if (aux1==0) aux1=1e-20;
    if (aux2==0) aux2=1e-20;

    if (dev_border_acc!=0)
    {
      // TODO: double aux = aux0 * dev_border_acc;
      // double aux123 = aux / aux1;
      _jacobianOplus[0](0,0) = aux0 * deltaS1[0] / aux1 * dev_border_acc; // acc x1
      _jacobianOplus[0](0,1) = aux0 * deltaS1[1] / aux1 * dev_border_acc; // acc y1
      _jacobianOplus[1](0,0) = -aux0 * ( deltaS1[0] / aux1 + deltaS2[0] / aux2 ) * dev_border_acc; // acc x2
      _jacobianOplus[1](0,1) = -aux0 * ( deltaS1[1] / aux1 + deltaS2[1] / aux2 ) * dev_border_acc; // acc y2
      _jacobianOplus[2](0,0) = aux0 * deltaS2[0] / aux2 * dev_border_acc; // acc x3
      _jacobianOplus[2](0,1) = aux0 * deltaS2[1] / aux2 * dev_border_acc; // acc y3
      _jacobianOplus[2](0,0) = 0;
      _jacobianOplus[2](0,1) = 0;
      _jacobianOplus[3](0,0) = aux0 * (aux3 + vel1 * dt1_inv) * dev_border_acc; // acc deltaT1
      _jacobianOplus[4](0,0) = aux0 * (aux3 - vel2 * dt2_inv) * dev_border_acc; // acc deltaT2
    }
    else
    {
      _jacobianOplus[0](0,0) = 0; // acc x1
      _jacobianOplus[0](0,1) = 0; // acc y1
      _jacobianOplus[1](0,0) = 0; // acc x2
      _jacobianOplus[1](0,1) = 0; // acc y2
      _jacobianOplus[2](0,0) = 0; // acc x3
      _jacobianOplus[2](0,1) = 0; // acc y3
      _jacobianOplus[3](0,0) = 0; // acc deltaT1
      _jacobianOplus[4](0,0) = 0; // acc deltaT2
    }

    if (dev_border_omegadot!=0)
    {
      _jacobianOplus[3](1,0) = aux0 * ( aux4 + omega1 * dt1_inv ) * dev_border_omegadot; // omegadot deltaT1
      _jacobianOplus[4](1,0) = aux0 * ( aux4 - omega2 * dt2_inv ) * dev_border_omegadot; // omegadot deltaT2
      _jacobianOplus[5](1,0) = aux0 * dt1_inv * dev_border_omegadot; // omegadot angle1
      _jacobianOplus[6](1,0) = -aux0 * ( dt1_inv + dt2_inv ) * dev_border_omegadot; // omegadot angle2
      _jacobianOplus[7](1,0) = aux0 * dt2_inv * dev_border_omegadot; // omegadot angle3
    }
    else
    {
      _jacobianOplus[3](1,0) = 0; // omegadot deltaT1
      _jacobianOplus[4](1,0) = 0; // omegadot deltaT2
      _jacobianOplus[5](1,0) = 0; // omegadot angle1
      _jacobianOplus[6](1,0) = 0; // omegadot angle2
      _jacobianOplus[7](1,0) = 0; // omegadot angle3
    }

    _jacobianOplus[0](1,0) = 0; // omegadot x1
    _jacobianOplus[0](1,1) = 0; // omegadot y1
    _jacobianOplus[1](1,0) = 0; // omegadot x2
    _jacobianOplus[1](1,1) = 0; // omegadot y2
    _jacobianOplus[2](1,0) = 0; // omegadot x3
    _jacobianOplus[2](1,1) = 0; // omegadot y3
    _jacobianOplus[5](0,0) = 0; // acc angle1
    _jacobianOplus[6](0,0) = 0; // acc angle2
    _jacobianOplus[7](0,0) = 0; // acc angle3
    }
#endif
#endif


public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

};

/**
 * @class EdgeAccelerationStart
 * @brief Edge defining the cost function for limiting the translational and rotational acceleration at the beginning of the trajectory.
 *
 * The edge depends on three vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \Delta T_i \f$, an initial velocity defined by setInitialVelocity()
 * and minimizes: \n
 * \f$ \min \textrm{penaltyInterval}( [a, omegadot ]^T ) \cdot weight \f$. \n
 * \e a is calculated using the difference quotient (twice) and the position parts of the poses. \n
 * \e omegadot is calculated using the difference quotient of the yaw angles followed by a normalization to [-pi, pi].  \n
 * \e weight can be set using setInformation(). \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval(). \n
 * The dimension of the error / cost vector is 2: the first component represents the translational acceleration and
 * the second one the rotational acceleration.
 * @see TebOptimalPlanner::AddEdgesAcceleration
 * @see EdgeAcceleration
 * @see EdgeAccelerationGoal
 * @remarks Do not forget to call setTebConfig()
 * @remarks Refer to EdgeAccelerationGoal() for defining boundary values at the end of the trajectory!
 */
class EdgeAccelerationStart : public BaseTebMultiEdge<2, const Eigen::Vector3d*>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeAccelerationStart()
    {
        _measurement = NULL;
        this->resize(3);
    }


    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if(!(cfg_ && _measurement)) printf("You must call setTebConfig() and setStartVelocity() on EdgeAccelerationStart()");
        const VertexPose* pose1 = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* pose2 = static_cast<const VertexPose*>(_vertices[1]);
        const VertexTimeDiff* dt = static_cast<const VertexTimeDiff*>(_vertices[2]);

        // VELOCITY & ACCELERATION
        const Eigen::Vector2d diff = pose2->position() - pose1->position();
        double dist = diff.norm();
        const double angle_diff = g2o::normalize_theta(pose2->theta() - pose1->theta());
        if (cfg_->trajectory.exact_arc_length && angle_diff != 0)
        {
            const double radius =  dist/(2*sin(angle_diff/2));
            dist = fabs( angle_diff * radius ); // actual arg length!
        }

        const double vel1 = _measurement->x();
        double vel2 = dist / dt->dt();

        // consider directions
        //vel2 *= g2o::sign(diff[0]*cos(pose1->theta()) + diff[1]*sin(pose1->theta()));
        vel2 *= fast_sigmoid( 100*(diff.x()*cos(pose1->theta()) + diff.y()*sin(pose1->theta())) );

        const double acc_lin  = (vel2 - vel1) / dt->dt();

        _error[0] = penaltyBoundToInterval(acc_lin,cfg_->robot.acc_lim_x,cfg_->optim.penalty_epsilon);

        // ANGULAR ACCELERATION
        const double omega1 = _measurement->z();
        const double omega2 = angle_diff / dt->dt();
        const double acc_rot  = (omega2 - omega1) / dt->dt();

        _error[1] = penaltyBoundToInterval(acc_rot,cfg_->robot.acc_lim_theta,cfg_->optim.penalty_epsilon);

        if(!std::isfinite(_error[0])) printf("EdgeAccelerationStart::computeError() translational: _error[0]=%f\n",_error[0]);
        if(!std::isfinite(_error[1])) printf("EdgeAccelerationStart::computeError() rotational: _error[1]=%f\n",_error[1]);
    }

    /**
     * @brief Set the initial velocity that is taken into account for calculating the acceleration
     * @param vel_start twist message containing the translational and rotational velocity
     */
    void setInitialVelocity(const Eigen::Vector3d& vel_start)
    {
        _measurement = &vel_start;
    }

public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};




/**
 * @class EdgeAccelerationGoal
 * @brief Edge defining the cost function for limiting the translational and rotational acceleration at the end of the trajectory.
 *
 * The edge depends on three vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \Delta T_i \f$, an initial velocity defined by setGoalVelocity()
 * and minimizes: \n
 * \f$ \min \textrm{penaltyInterval}( [a, omegadot ]^T ) \cdot weight \f$. \n
 * \e a is calculated using the difference quotient (twice) and the position parts of the poses \n
 * \e omegadot is calculated using the difference quotient of the yaw angles followed by a normalization to [-pi, pi].  \n
 * \e weight can be set using setInformation() \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval() \n
 * The dimension of the error / cost vector is 2: the first component represents the translational acceleration and
 * the second one the rotational acceleration.
 * @see TebOptimalPlanner::AddEdgesAcceleration
 * @see EdgeAcceleration
 * @see EdgeAccelerationStart
 * @remarks Do not forget to call setTebConfig()
 * @remarks Refer to EdgeAccelerationStart() for defining boundary (initial) values at the end of the trajectory
 */
class EdgeAccelerationGoal : public BaseTebMultiEdge<2, const Eigen::Vector3d*>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeAccelerationGoal()
    {
        _measurement = NULL;
        this->resize(3);
    }


    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if(!(cfg_ && _measurement)) printf("You must call setTebConfig() and setGoalVelocity() on EdgeAccelerationGoal()");
        const VertexPose* pose_pre_goal = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* pose_goal = static_cast<const VertexPose*>(_vertices[1]);
        const VertexTimeDiff* dt = static_cast<const VertexTimeDiff*>(_vertices[2]);

        // VELOCITY & ACCELERATION

        const Eigen::Vector2d diff = pose_goal->position() - pose_pre_goal->position();
        double dist = diff.norm();
        const double angle_diff = g2o::normalize_theta(pose_goal->theta() - pose_pre_goal->theta());
        if (cfg_->trajectory.exact_arc_length  && angle_diff != 0)
        {
            double radius =  dist/(2*sin(angle_diff/2));
            dist = fabs( angle_diff * radius ); // actual arg length!
        }

        double vel1 = dist / dt->dt();
        const double vel2 = _measurement->x();

        // consider directions
        //vel1 *= g2o::sign(diff[0]*cos(pose_pre_goal->theta()) + diff[1]*sin(pose_pre_goal->theta()));
        vel1 *= fast_sigmoid( 100*(diff.x()*cos(pose_pre_goal->theta()) + diff.y()*sin(pose_pre_goal->theta())) );

        const double acc_lin  = (vel2 - vel1) / dt->dt();

        _error[0] = penaltyBoundToInterval(acc_lin,cfg_->robot.acc_lim_x,cfg_->optim.penalty_epsilon);

        // ANGULAR ACCELERATION
        const double omega1 = angle_diff / dt->dt();
        const double omega2 = _measurement->z();
        const double acc_rot  = (omega2 - omega1) / dt->dt();

        _error[1] = penaltyBoundToInterval(acc_rot,cfg_->robot.acc_lim_theta,cfg_->optim.penalty_epsilon);

        if(!std::isfinite(_error[0])) printf("EdgeAccelerationGoal::computeError() translational: _error[0]=%f\n",_error[0]);
        if(!std::isfinite(_error[1])) printf("EdgeAccelerationGoal::computeError() rotational: _error[1]=%f\n",_error[1]);
    }

    /**
     * @brief Set the goal / final velocity that is taken into account for calculating the acceleration
     * @param vel_goal twist message containing the translational and rotational velocity
     */
    void setGoalVelocity(const Eigen::Vector3d& vel_goal)
    {
        _measurement = &vel_goal;
    }

public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};



/**
 * @class EdgeAccelerationHolonomic
 * @brief Edge defining the cost function for limiting the translational and rotational acceleration.
 *
 * The edge depends on five vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \mathbf{s}_{ip2}, \Delta T_i, \Delta T_{ip1} \f$ and minimizes:
 * \f$ \min \textrm{penaltyInterval}( [ax, ay, omegadot } ]^T ) \cdot weight \f$. \n
 * \e ax is calculated using the difference quotient (twice) and the x position parts of all three poses \n
 * \e ay is calculated using the difference quotient (twice) and the y position parts of all three poses \n
 * \e omegadot is calculated using the difference quotient of the yaw angles followed by a normalization to [-pi, pi]. \n
 * \e weight can be set using setInformation() \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval() \n
 * The dimension of the error / cost vector is 3: the first component represents the translational acceleration (x-dir),
 * the second one the strafing acceleration and the third one the rotational acceleration.
 * @see TebOptimalPlanner::AddEdgesAcceleration
 * @see EdgeAccelerationHolonomicStart
 * @see EdgeAccelerationHolonomicGoal
 * @remarks Do not forget to call setTebConfig()
 * @remarks Refer to EdgeAccelerationHolonomicStart() and EdgeAccelerationHolonomicGoal() for defining boundary values!
 */
class EdgeAccelerationHolonomic : public BaseTebMultiEdge<3, double>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeAccelerationHolonomic()
    {
        this->resize(5);
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if(!cfg_) printf("You must call setTebConfig on EdgeAcceleration()");
        const VertexPose* pose1 = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* pose2 = static_cast<const VertexPose*>(_vertices[1]);
        const VertexPose* pose3 = static_cast<const VertexPose*>(_vertices[2]);
        const VertexTimeDiff* dt1 = static_cast<const VertexTimeDiff*>(_vertices[3]);
        const VertexTimeDiff* dt2 = static_cast<const VertexTimeDiff*>(_vertices[4]);

        // VELOCITY & ACCELERATION
        Eigen::Vector2d diff1 = pose2->position() - pose1->position();
        Eigen::Vector2d diff2 = pose3->position() - pose2->position();

        double cos_theta1 = std::cos(pose1->theta());
        double sin_theta1 = std::sin(pose1->theta());
        double cos_theta2 = std::cos(pose2->theta());
        double sin_theta2 = std::sin(pose2->theta());

        // transform pose2 into robot frame pose1 (inverse 2d rotation matrix)
        double p1_dx =  cos_theta1*diff1.x() + sin_theta1*diff1.y();
        double p1_dy = -sin_theta1*diff1.x() + cos_theta1*diff1.y();
        // transform pose3 into robot frame pose2 (inverse 2d rotation matrix)
        double p2_dx =  cos_theta2*diff2.x() + sin_theta2*diff2.y();
        double p2_dy = -sin_theta2*diff2.x() + cos_theta2*diff2.y();

        double vel1_x = p1_dx / dt1->dt();
        double vel1_y = p1_dy / dt1->dt();
        double vel2_x = p2_dx / dt2->dt();
        double vel2_y = p2_dy / dt2->dt();

        double dt12 = dt1->dt() + dt2->dt();

        double acc_x  = (vel2_x - vel1_x)*2 / dt12;
        double acc_y  = (vel2_y - vel1_y)*2 / dt12;

        _error[0] = penaltyBoundToInterval(acc_x,cfg_->robot.acc_lim_x,cfg_->optim.penalty_epsilon);
        _error[1] = penaltyBoundToInterval(acc_y,cfg_->robot.acc_lim_y,cfg_->optim.penalty_epsilon);

        // ANGULAR ACCELERATION
        double omega1 = g2o::normalize_theta(pose2->theta() - pose1->theta()) / dt1->dt();
        double omega2 = g2o::normalize_theta(pose3->theta() - pose2->theta()) / dt2->dt();
        double acc_rot  = (omega2 - omega1)*2 / dt12;

        _error[2] = penaltyBoundToInterval(acc_rot,cfg_->robot.acc_lim_theta,cfg_->optim.penalty_epsilon);


        if(!std::isfinite(_error[0])) printf("EdgeAcceleration::computeError() translational: _error[0]=%f\n",_error[0]);
        if(!std::isfinite(_error[1])) printf("EdgeAcceleration::computeError() strafing: _error[1]=%f\n",_error[1]);
        if(!std::isfinite(_error[2])) printf("EdgeAcceleration::computeError() rotational: _error[2]=%f\n",_error[2]);
    }

public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

};


/**
 * @class EdgeAccelerationHolonomicStart
 * @brief Edge defining the cost function for limiting the translational and rotational acceleration at the beginning of the trajectory.
 *
 * The edge depends on three vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \Delta T_i \f$, an initial velocity defined by setInitialVelocity()
 * and minimizes: \n
 * \f$ \min \textrm{penaltyInterval}( [ax, ay, omegadot ]^T ) \cdot weight \f$. \n
 * \e ax is calculated using the difference quotient (twice) and the x-position parts of the poses. \n
 * \e ay is calculated using the difference quotient (twice) and the y-position parts of the poses. \n
 * \e omegadot is calculated using the difference quotient of the yaw angles followed by a normalization to [-pi, pi].  \n
 * \e weight can be set using setInformation(). \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval(). \n
 * The dimension of the error / cost vector is 3: the first component represents the translational acceleration,
 * the second one the strafing acceleration and the third one the rotational acceleration.
 * @see TebOptimalPlanner::AddEdgesAcceleration
 * @see EdgeAccelerationHolonomic
 * @see EdgeAccelerationHolonomicGoal
 * @remarks Do not forget to call setTebConfig()
 * @remarks Refer to EdgeAccelerationHolonomicGoal() for defining boundary values at the end of the trajectory!
 */
class EdgeAccelerationHolonomicStart : public BaseTebMultiEdge<3, const Eigen::Vector3d *>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeAccelerationHolonomicStart()
    {
        this->resize(3);
        _measurement = NULL;
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if(!(cfg_ && _measurement)) printf("You must call setTebConfig() and setStartVelocity() on EdgeAccelerationStart()");
        const VertexPose* pose1 = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* pose2 = static_cast<const VertexPose*>(_vertices[1]);
        const VertexTimeDiff* dt = static_cast<const VertexTimeDiff*>(_vertices[2]);

        // VELOCITY & ACCELERATION
        Eigen::Vector2d diff = pose2->position() - pose1->position();

        double cos_theta1 = std::cos(pose1->theta());
        double sin_theta1 = std::sin(pose1->theta());

        // transform pose2 into robot frame pose1 (inverse 2d rotation matrix)
        double p1_dx =  cos_theta1*diff.x() + sin_theta1*diff.y();
        double p1_dy = -sin_theta1*diff.x() + cos_theta1*diff.y();

        double vel1_x = _measurement->x();
        double vel1_y = _measurement->y();
        double vel2_x = p1_dx / dt->dt();
        double vel2_y = p1_dy / dt->dt();

        double acc_lin_x  = (vel2_x - vel1_x) / dt->dt();
        double acc_lin_y  = (vel2_y - vel1_y) / dt->dt();

        _error[0] = penaltyBoundToInterval(acc_lin_x,cfg_->robot.acc_lim_x,cfg_->optim.penalty_epsilon);
        _error[1] = penaltyBoundToInterval(acc_lin_y,cfg_->robot.acc_lim_y,cfg_->optim.penalty_epsilon);

        // ANGULAR ACCELERATION
        double omega1 = _measurement->z();
        double omega2 = g2o::normalize_theta(pose2->theta() - pose1->theta()) / dt->dt();
        double acc_rot  = (omega2 - omega1) / dt->dt();

        _error[2] = penaltyBoundToInterval(acc_rot,cfg_->robot.acc_lim_theta,cfg_->optim.penalty_epsilon);

        if(!std::isfinite(_error[0])) printf("EdgeAccelerationStart::computeError() translational: _error[0]=%f\n",_error[0]);
        if(!std::isfinite(_error[1])) printf("EdgeAccelerationStart::computeError() strafing: _error[1]=%f\n",_error[1]);
        if(!std::isfinite(_error[2])) printf("EdgeAccelerationStart::computeError() rotational: _error[2]=%f\n",_error[2]);
    }

    /**
     * @brief Set the initial velocity that is taken into account for calculating the acceleration
     * @param vel_start twist message containing the translational and rotational velocity
     */
    void setInitialVelocity(const Eigen::Vector3d& vel_start)
    {
        _measurement = &vel_start;
    }

public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};



/**
 * @class EdgeAccelerationHolonomicGoal
 * @brief Edge defining the cost function for limiting the translational and rotational acceleration at the end of the trajectory.
 *
 * The edge depends on three vertices \f$ \mathbf{s}_i, \mathbf{s}_{ip1}, \Delta T_i \f$, an initial velocity defined by setGoalVelocity()
 * and minimizes: \n
 * \f$ \min \textrm{penaltyInterval}( [ax, ay, omegadot ]^T ) \cdot weight \f$. \n
 * \e ax is calculated using the difference quotient (twice) and the x-position parts of the poses \n
 * \e ay is calculated using the difference quotient (twice) and the y-position parts of the poses \n
 * \e omegadot is calculated using the difference quotient of the yaw angles followed by a normalization to [-pi, pi].  \n
 * \e weight can be set using setInformation() \n
 * \e penaltyInterval denotes the penalty function, see penaltyBoundToInterval() \n
 * The dimension of the error / cost vector is 3: the first component represents the translational acceleration,
 * the second one is the strafing velocity and the third one the rotational acceleration.
 * @see TebOptimalPlanner::AddEdgesAcceleration
 * @see EdgeAccelerationHolonomic
 * @see EdgeAccelerationHolonomicStart
 * @remarks Do not forget to call setTebConfig()
 * @remarks Refer to EdgeAccelerationHolonomicStart() for defining boundary (initial) values at the end of the trajectory
 */
class EdgeAccelerationHolonomicGoal : public BaseTebMultiEdge<3, const Eigen::Vector3d*>
{
public:

    /**
     * @brief Construct edge.
     */
    EdgeAccelerationHolonomicGoal()
    {
        _measurement = NULL;
        this->resize(3);
    }

    /**
     * @brief Actual cost function
     */
    void computeError()
    {
        if(!(cfg_ && _measurement)) printf("You must call setTebConfig() and setGoalVelocity() on EdgeAccelerationGoal()");
        const VertexPose* pose_pre_goal = static_cast<const VertexPose*>(_vertices[0]);
        const VertexPose* pose_goal = static_cast<const VertexPose*>(_vertices[1]);
        const VertexTimeDiff* dt = static_cast<const VertexTimeDiff*>(_vertices[2]);

        // VELOCITY & ACCELERATION

        Eigen::Vector2d diff = pose_goal->position() - pose_pre_goal->position();

        double cos_theta1 = std::cos(pose_pre_goal->theta());
        double sin_theta1 = std::sin(pose_pre_goal->theta());

        // transform pose2 into robot frame pose1 (inverse 2d rotation matrix)
        double p1_dx =  cos_theta1*diff.x() + sin_theta1*diff.y();
        double p1_dy = -sin_theta1*diff.x() + cos_theta1*diff.y();

        double vel1_x = p1_dx / dt->dt();
        double vel1_y = p1_dy / dt->dt();
        double vel2_x = _measurement->x();
        double vel2_y = _measurement->y();

        double acc_lin_x  = (vel2_x - vel1_x) / dt->dt();
        double acc_lin_y  = (vel2_y - vel1_y) / dt->dt();

        _error[0] = penaltyBoundToInterval(acc_lin_x,cfg_->robot.acc_lim_x,cfg_->optim.penalty_epsilon);
        _error[1] = penaltyBoundToInterval(acc_lin_y,cfg_->robot.acc_lim_y,cfg_->optim.penalty_epsilon);

        // ANGULAR ACCELERATION
        double omega1 = g2o::normalize_theta(pose_goal->theta() - pose_pre_goal->theta()) / dt->dt();
        double omega2 = _measurement->z();
        double acc_rot  = (omega2 - omega1) / dt->dt();

        _error[2] = penaltyBoundToInterval(acc_rot,cfg_->robot.acc_lim_theta,cfg_->optim.penalty_epsilon);

        if(!std::isfinite(_error[0])) printf("EdgeAccelerationGoal::computeError() translational: _error[0]=%f\n",_error[0]);
        if(!std::isfinite(_error[1])) printf("EdgeAccelerationGoal::computeError() strafing: _error[1]=%f\n",_error[1]);
        if(!std::isfinite(_error[2])) printf("EdgeAccelerationGoal::computeError() rotational: _error[2]=%f\n",_error[2]);
    }


    /**
     * @brief Set the goal / final velocity that is taken into account for calculating the acceleration
     * @param vel_goal twist message containing the translational and rotational velocity
     */
    void setGoalVelocity(const Eigen::Vector3d& vel_goal)
    {
        _measurement = &vel_goal;
    }


public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};



#endif //FREENAV_TEB_EDGES_H
