%filename = '/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/all-output/Berlin-1-256.txt';
%filename = '/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/all-output/maze512-4-8.txt';
%filename = '/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/all-output/maze512-4-0.txt';
%filename = '/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/all-output/TheFrozenSea.txt';
%filename = '/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/all-output/Entanglement.txt';
filename = '/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/all-output/FloodedPlains.txt';
 

table1 =readtable(filename, 'Format', '%s%u%u%u%u%f%f%f%f%f');

table2 = table1(:, 6:9);

matrix1 = table2.Variables;

dimen = size(matrix1);

RJ_INIT = 0.;
RJ_SEARCH = 0.;
RJ_PATH_LEN = 0;
 
SVG_INIT = 0.;
SVG_SEARCH = 0.;
SVG_PATH_LEN = 0;
 
 for i = 1 : dimen(1)
    if mod(i, 2) == 1
        RJ_PATH_LEN = RJ_PATH_LEN + matrix1(i, 1);
        RJ_INIT     = RJ_INIT   + matrix1(i, 3);
        RJ_SEARCH   = RJ_SEARCH + matrix1(i, 4);
    elseif mod(i, 2) == 0        
       SVG_PATH_LEN = SVG_PATH_LEN + matrix1(i, 1);
       SVG_INIT     = SVG_INIT   + matrix1(i, 3);
       SVG_SEARCH   = SVG_SEARCH + matrix1(i, 4);
    end
   
 end
 
fprintf('\n%i experiments\n\n', dimen(1)/2); 
 
fprintf('RJ mean init =    %f\n',RJ_INIT/dimen(1));
fprintf('RJ mean search =    %f\n',RJ_SEARCH/dimen(1));
fprintf('RJ mean path len =    %f\n\n',RJ_PATH_LEN/dimen(1));


fprintf('SVG mean init =    %f\n',SVG_INIT/dimen(1));
fprintf('SVG mean search =    %f\n',SVG_SEARCH/dimen(1));
fprintf('SVG mean path len =    %f\n',SVG_PATH_LEN/dimen(1));




