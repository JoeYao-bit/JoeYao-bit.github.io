//
// Created by yaozhuo on 2022/3/25.
//

#ifndef FREENAV_2D_ENLSVG_GRID_H
#define FREENAV_2D_ENLSVG_GRID_H

#include "ENLSVG.h"
#include "rim_jump/basic_elements/point.h"

Pathfinding::Grid getENL_SVG_Module(freeNav::DimensionLength* dimension, freeNav::IS_OCCUPIED_FUNC<2> f1);

#endif //FREENAV_2D_ENLSVG_GRID_H
