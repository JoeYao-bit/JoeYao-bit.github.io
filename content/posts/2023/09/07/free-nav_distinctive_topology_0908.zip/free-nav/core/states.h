#ifndef _STATES_H_
#define _STATES_H_
#include <eigen3/Eigen/Core>
#include <memory>
#include <vector>
namespace freeNav {
    typedef Eigen::Vector3d Vec3d;

// use the uint64_t to describe the time of the system
//    typedef uint64_t Time;

// the double vector to describe the control cmd to low-level control system
// control the vehicle from current motion states to target motions states
    typedef Eigen::VectorXd ControlCmd;

    struct Velocity{
        Vec3d linear_vel_ = Vec3d(); // linear velocity of the motion center
        Vec3d angular_vel_ = Vec3d(); // angular velocity of the motion center

        // linear acceleration of the motion center, define by the total force that imposed to the vehicle
        Vec3d linear_acc = Vec3d();
        // angular acceleration of the motion center, define by the total torque that imposed to the vehicle
        Vec3d angular_acc = Vec3d();
    };

    typedef std::shared_ptr<Velocity> VelocityPtr;
    typedef std::vector<VelocityPtr> VelocityPtrs;
    typedef std::vector<Velocity> Velocities;


// to describe motion center's motion states, only describe the essential component of a rigid body motion
// if there is other necessary state to describe the motion, just inherit the MotionState
// such as WheeledMotionState or BipedalMotionState
    struct MotionState {

        Vec3d position_ = Vec3d(); // the Cartesian coordinates to describe the position of the motion center
        Vec3d pose_ = Vec3d(); // the Eular angle to describe the pose of the motion center
        Velocity velocity_; // the velocity and acceleration of the platform
    };

    typedef std::shared_ptr<MotionState> MotionStatePtr;
    typedef std::vector<MotionStatePtr> MotionStatePtrs;
    typedef std::vector<MotionState> MotionStates;
}
#endif