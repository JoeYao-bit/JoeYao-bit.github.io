//
// Created by yaozhuo on 2023/7/8.
//

#ifndef FREENAV_VORONOI_GRAPH_H
#define FREENAV_VORONOI_GRAPH_H

#include "point.h"
#include <memory> // std::shared_ptr

namespace freeNav::RimJump {

    using OtherNodeDatas = std::map<Id, PathLen>;

    // a undirected Voronoi graph structure
    template<Dimension N>
    struct VoronoiNode {

        explicit VoronoiNode(const Pointi<N>& pt,
                             const Id& id,
                             const Id& node_id,
                             bool is_hyper)
        :pt_(pt), id_(id), node_id_(node_id), is_hyper_(is_hyper) {
            //
        }

        Pointi<N> pt_;

        Id id_; // id in grid space

        Id node_id_; // id in node queue

        bool is_hyper_ = false;

        std::set<Id> edge_ids_;

        Id hyper_id_ = MAX<Id>;

        // visible nearby neighbor nodes
        // for un hyper node, there should be only two neighbor and two hyper
        OtherNodeDatas visible_neighbors_;

        // visible hyper (have more than two branches) nodes
        // for un hyper node, there should be only two neighbor and two hyper
        OtherNodeDatas visible_hypers_;

    };

    // define an unique id for VoronoiHyperEdge, even have the same head and tail
    // as two edges have no intersection, we choose the first point's id as unique id
    template <Dimension N>
    struct VoronoiHyperEdge {

        explicit VoronoiHyperEdge(const Id& start_hyper_node_id, const Id& start_hyper_group_id) {
            start_hyper_node_id_ = start_hyper_node_id;
            start_hyper_group_id_ = start_hyper_group_id;
        }

        Id start_hyper_node_id_, end_hyper_node_id_; // id in VoronoiHyperNode sequence

        Id start_hyper_group_id_, end_hyper_node_group_id_; // id in VoronoiHyperNode sequence

        Pointis<N> pts_; // in order of connection
    };

    template <Dimension N>
    using VoronoiHyperEdgePtr = std::shared_ptr<VoronoiHyperEdge<N> >;

    template <Dimension N>
    using VoronoiHyperEdgePtrs = std::vector<VoronoiHyperEdgePtr<N> >;

    template <Dimension N>
    struct VoronoiHyperNode {

        explicit VoronoiHyperNode(const Id& hyper_group_id) {
            hyper_group_id_ = hyper_group_id;
        }

        Id hyper_group_id_; // id in VoronoiHyperNode sequence

        Pointis<N> pts_; // a group connected voronoi nodes

        VoronoiHyperEdgePtrs<N> edges_;

    };

    template <Dimension N>
    using VoronoiHyperNodePtr = std::shared_ptr<VoronoiHyperNode<N> >;

    template <Dimension N>
    using VoronoiHyperNodePtrs = std::vector<VoronoiHyperNodePtr<N> >;

}

#endif //FREENAV_VORONOI_GRAPH_H
