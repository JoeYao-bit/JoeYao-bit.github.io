//
// Created by yaozhuo on 2023/7/5.
//

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <vector>
#include <gtest/gtest.h>
#include "dependencies/test_data.h"
#include "2d_grid/text_map_loader.h"
#include "canvas/canvas.h"

#include "dynamicvoronoi.h"

#include <rim_jump/surface_processor/surface_processor_ENLSVG_LineScanner.h>
#include "rim_jump/graph_construction/tangent_graph_build.h"
#include "rim_jump/online_search/create_initial_paths_with_edge.h"
#include "rim_jump/constraints/point_to_point_constraints.h"
#include "rim_jump/constraints/edge_transfer_constraints.h"
#include "rim_jump/online_search/search_path_with_node.h"

#include "rim_jump/online_search/search_path_with_node.h"
#include "rim_jump/online_search/breadth_first_search_with_node.h"
#include "rim_jump/online_search/depth_first_search_with_node.h"
#include "rim_jump/online_search/create_initial_paths_with_node.h"

#include "rim_jump/constraints/node_iteration_constraints.h"

// Open CV:
#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>

// DOSL
#include "encapsulations/cvMulticlassPathPlanner.tcc"
#include "aux-utils/string_utils.hpp" // compute_program_path

#ifndef _DOSL_ALGORITHM // can pass at command line during compilation: -D_DOSL_ALGORITHM=AStar
#define _DOSL_ALGORITHM  AStar
#endif

#include "sys/time.h"

#include "rhcf.h"

TEST(DOSL, RawDistinctiveTopologyPathPlanning)
{
    int nPaths = 1;
    std::string map_file = "/home/yaozhuo/code/DOSL/examples-dosl/files/expt/L457.png";
    cv::Point start (60,60);
    cv::Point goal (200,300);

    cv::Mat obs_map = cv::imread (map_file, CV_LOAD_IMAGE_GRAYSCALE);

    // find paths
    cvMulticlassPathPlanner<AStar> path_planner (obs_map, nullptr);
    path_planner.find_paths (start, goal, nPaths, false);

    // draw paths and display
    //obs_map = path_planner.draw_paths ({}, 2);

}


// load GPF map
using namespace freeNav;
using namespace freeNav::RimJump;
int zoom_rate = 1;

#if 0

//MapTestConfig_Shanghai_0_512
//MapTestConfig_Moscow_2_256
//MapTestConfig_TheFrozenSea
//MapTestConfig_Sydney_1_256
//MapTestConfig_Boston_0_1024
//MapTestConfig_London_2_512
auto map_test_config = MapTestConfig_London_2_512;
std::string vis_file_path    = map_test_config.at("vis_path");

auto is_char_occupied1 = [](const char& value) -> bool {
    if (value == '.') return false;
    return true;
};

TextMapLoader loader(map_test_config.at("map_path"), is_char_occupied1);

auto dimension = loader.getDimensionInfo();

auto is_occupied = [](const Pointi<2> & pt) -> bool {
    //if(pt[0] <= 0 || pt[0] >= dimension[0]-1 || pt[1] <= 0 || pt[1] >= dimension[1]-1 ) { return true; }
    return loader.isOccupied(pt);
};

auto set_occupied = [](const Pointi<2> & pt) { loader.setOccupied(pt); };

IS_OCCUPIED_FUNC<2> is_occupied_func = is_occupied;

SET_OCCUPIED_FUNC<2> set_occupied_func = set_occupied;


#else
//grid_2D_0 5 obstacle AC
//grid_2D_1 10 obstacle AC
//grid_2D_2 15 obstacle AC
//grid_2D_3 20 obstacle AC
//grid_2D_4 25 obstacle AC
//grid_2D_5 50 obstacle
//grid_2D_6
//grid_2D_7
//grid_2D_8

auto config = grid_2D_5;//random_maps_4d;

//RandomMapGenerator<N> random_map(dimension, cubic_half_width, cubic_number, random_file_path, false);
std::string vis_file_path    = "/home/yaozhuo/code/Grid-based Path Planning Competition Dataset/all-vis/random.vis";


RandomMapGenerator<2> random_map(config.dim_,
                                 config.cubic_half_width_,
                                 config.cubic_number_,
                                 config.random_file_path_,
                                 false, true);

auto dimension = random_map.dimen_;

auto is_occupied = [](const Pointi<2> & pt) -> bool {
    if(isOutOfBoundary(pt, dimension)) { return true; }
    Id id = PointiToId(pt, dimension);
    return random_map.occ_ids_.find(id) != random_map.occ_ids_.end();
};

IS_OCCUPIED_FUNC<2> is_occupied_func = is_occupied;

SET_OCCUPIED_FUNC<2> set_occupied_func;


#endif

std::shared_ptr<RoadMapGraphBuilder<2> > tgb = nullptr;
PointTransferConstraints<2> ptcs_ordered;
NodeIterationConstraints<2, GridPtr<2>> ics_node_topology({
                                                                  NIC_NoLoop, // if is global shortest, no need to add IC_NoLoop
                                                                  //IC_EdgeNLevelLimit
                                                                  NIC_NoStraightExtend
                                                          });

PointTransferConstraints<2> init_ptcs({PTC_CrosserToObstacle_2D});
EdgeTransferConstraints3<2> init_etcs({ETC_Taut_2D});

bool set_pt1 = true;
Pointi<2> pt1, pt2;
FractionPair pt1_f, pt2_f;
freeNav::RimJump::GridPtr<2> sg1 = std::make_shared<freeNav::RimJump::Grid<2>>(),
                             sg2 = std::make_shared<freeNav::RimJump::Grid<2>>();

bool plan_finish = false;
bool new_pair = false;
ThreadPool tp;
std::vector<Path<2>> rj_paths, paths, hstar_paths_as, hstar_paths_ts, rhcf_paths;

bool center_offset = false;
bool show_rj     = true;
bool show_hstar_as  = false;
bool show_hstar_ts  = false;

bool show_rhcf  = false;
bool draw_all_path = false;
bool draw_representation_point = false;
int current_show_index = 0;

struct timezone tz;
struct timeval  tv_pre;
struct timeval  tv_after;

TEST(DynamicVoronoi, test) {

    std::vector<std::vector<bool> > map;
    for(int i=0; i<dimension[0]; i++) {
        std::vector<bool> row(dimension[1], false);
        map.push_back(row);
    }
    Pointi<2> pt;
    for(int x=0; x<dimension[0]; x++) {
        for(int y=0; y<dimension[1]; y++) {
            pt[0] = x, pt[1] = y;
            if(is_occupied(pt)) {
                map[x][y] = true;
            }
        }
    }

    DynamicVoronoi voronoi;
    voronoi.initializeMap(dimension[0], dimension[1], map);
    voronoi.update(); // update distance map and Voronoi diagram
    voronoi.prune();
    //voronoi.visualize("initial.ppm");
    //voronoi.updateAlternativePrunedDiagram();

    Canvas canvas("DynamicVoronoiMap", dimension[0], dimension[1], .05, zoom_rate);

    while(1) {
        canvas.resetCanvas();
        canvas.drawEmptyGrid();
        canvas.drawGridMap(dimension, is_occupied_func);
        for(int x=0; x<dimension[0]; x++) {
            for(int y=0; y<dimension[1]; y++) {
                if(voronoi.isVoronoi(x, y)) {
                    canvas.drawGrid(x, y, cv::Vec3b(255, 0, 0));
                }
            }
        }
        canvas.show();
    }
}

TEST(DynamicVoronoiRRT, test) {

    DynamicVoronoiRRT voronoi;

    std::vector<std::vector<bool> > map;
    for(int i=0; i<dimension[0]; i++) {
        std::vector<bool> row(dimension[1], false);
        map.push_back(row);
    }
    Pointi<2> pt;
    for(int x=0; x<dimension[0]; x++) {
        for(int y=0; y<dimension[1]; y++) {
            pt[0] = x, pt[1] = y;
            if(is_occupied(pt)) {
                map[x][y] = true;
            }
        }
    }

    voronoi.initializeMap(dimension[0], dimension[1], map);
    voronoi.update();
    voronoi.updateAlternativePrunedDiagram();
    voronoi.prune();

    Canvas canvas("DynamicVoronoiMapRRT", dimension[0], dimension[1], .05, zoom_rate);

    while(1) {
        canvas.resetCanvas();
        canvas.drawEmptyGrid();
        canvas.drawGridMap(dimension, is_occupied_func);
        for(int x=0; x<dimension[0]; x++) {
            for(int y=0; y<dimension[1]; y++) {
                if(voronoi.isVoronoiAlternative(x, y)) {
                    canvas.drawGrid(x, y, cv::Vec3b(255, 0, 0));
                }
            }
        }
        canvas.show();
    }
}

TEST(RHCF, test) {

    freeNav::RimJump::RHCF rhcf(dimension, is_occupied_func);
    rhcf.scene_->setScene(1, 1, 0, 0, dimension[0], dimension[1]);
    rhcf.scene_->setRobot(91, 67, 0);
    rhcf.scene_->setGoal(123, 104);

    rhcf.buildVoronoiDiagram();

    Canvas canvas("RHCF", dimension[0], dimension[1], .05, zoom_rate);

    auto callback = [](int event, int x, int y, int flags, void *) {
        if(event == CV_EVENT_LBUTTONDOWN) {
            if(set_pt1) {
                pt1[0] = x;
                pt1[1] = y;
                sg1->pt_ = pt1;
                sg1->id_ = PointiToId<2>(pt1, dimension);
                set_pt1 = false;
                plan_finish = false;
                std::cout << "get point " << x << ", " << y << std::endl;
            } else {
                pt2[0] = x;
                pt2[1] = y;
                sg2->pt_ = pt2;
                sg2->id_ = PointiToId<2>(pt2, dimension);
                set_pt1 = true;
                std::cout << "get point " << x << ", " << y << std::endl;
                new_pair = true;
                plan_finish = false;
            }
        }
    };

    canvas.setMouseCallBack(callback);

    bool draw_voronoi_graph = false,
         draw_voronoi_without_loose_send = true,
         draw_close_to_voronoi = true,
         draw_result_path = false;

    int current_path_index = 0;

    while(1) {
        canvas.resetCanvas();
        canvas.drawEmptyGrid();
        canvas.drawGridMap(dimension, is_occupied_func);

        canvas.drawGrid(pt1[0], pt1[1], COLOR_TABLE[0]);
        canvas.drawGrid(pt2[0], pt2[1], COLOR_TABLE[1]);

        if(new_pair) {
            new_pair = false;
            if(tp.pool_[0].joinable() && !plan_finish)
                tp.Schedule([&] {
                    gettimeofday(&tv_pre, &tz);
                    double xrobot[3];
                    double xgoal[2];
                    xrobot[0] = pt1[0], xrobot[1] = pt1[1];
                    xgoal[0]  = pt2[0], xgoal[1]  = pt2[1];
                    rhcf.readScenario(xrobot, xgoal, 0, 1, 1, dimension[0], 0, dimension[1], 0);
                    rhcf.buildVoronoiDiagram();
                    rhcf.buildNavigationGraph();
                    gettimeofday(&tv_after, &tz);
                    double cost_ms1 = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
                    gettimeofday(&tv_pre, &tz);
                    rhcf.K_ = 3;
                    rhcf.findHomotopyClasses();
                    gettimeofday(&tv_after, &tz);
                    double cost_ms2 = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
                    std::cout << "-- RHCF find " << rhcf.all_result_path_.size() << " paths in " << cost_ms1 << "+" << cost_ms2 << " ms" << std::endl;
                });
        };

        if(draw_voronoi_graph) {
            for (int x = 0; x < dimension[0]; x++) {
                for (int y = 0; y < dimension[1]; y++) {
                    if (rhcf.voronoi_->isVoronoi(x, y)) {
                        canvas.drawGrid(x, y, cv::Vec3b(255, 0, 0));
                    }
                }
            }
        }
        if(draw_voronoi_without_loose_send) {
            for (int x = 0; x < dimension[0]; x++) {
                for (int y = 0; y < dimension[1]; y++) {
                    if (rhcf.voronoi_->isVoronoiAlternative(x, y))
                    {
                        canvas.drawGrid(x, y, cv::Vec3b(255, 255, 0));
                    }
                }
            }
        }
        if(draw_close_to_voronoi) {
            canvas.drawGrid(rhcf.posRV_[0], rhcf.posRV_[1], COLOR_TABLE[0]);
            canvas.drawGrid(rhcf.posGv_[0], rhcf.posGv_[1], COLOR_TABLE[1]);
        }
        if(draw_result_path) {
            if(!rhcf.best_path_.empty()) {
                const auto& best_path = rhcf.all_result_path_[current_path_index];
                for(int i=0; i<best_path.size()-1; i++) {
                    canvas.drawLineInt(best_path[i][0], best_path[i][1],
                                       best_path[i+1][0], best_path[i+1][1],
                                       center_offset, 2, cv::Vec3b(0,255,0));
                }
            }
        }
        char key = canvas.show();
        switch (key) {
            case 'v':
                draw_voronoi_graph = !draw_voronoi_graph;
                break;
            case 'a':
                draw_voronoi_without_loose_send = !draw_voronoi_without_loose_send;
                break;
            case 'c':
                draw_close_to_voronoi = !draw_close_to_voronoi;
                break;
            case 'r':
                draw_result_path = !draw_result_path;
                break;
            case 'w':
                if(!rhcf.all_result_path_.empty()) {
                    current_path_index = (current_path_index + 1)%rhcf.all_result_path_.size();
                }
                break;
            case 's':
                if(!rhcf.all_result_path_.empty()) {
                    current_path_index = (2*current_path_index - 1)%rhcf.all_result_path_.size();
                }
                break;
            default:
                break;
        }
    }
}

TEST(Comparison, DistinctiveTopologyPathPlanning) {

    gettimeofday(&tv_pre, &tz);
    auto surface_processor = std::make_shared<SurfaceProcess_ENLSVG_LineScanner>(dimension, is_occupied_func, set_occupied_func);
    tgb = std::make_shared<RoadMapGraphBuilder<2> >(surface_processor, init_ptcs, ptcs_ordered, init_etcs, vis_file_path, true, false, 1);
    freeNav::RimJump::RoadMapGraphPtr<2> tg = tgb->getRoadMapGraph();
    GeneralGraphPathPlannerWithNode<2> g2p2(tg);
    gettimeofday(&tv_after, &tz);

    double build_cost = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
    std::cout << "-- load GPF end in " << build_cost << "ms" << std::endl;

    gettimeofday(&tv_pre, &tz);
    freeNav::RimJump::RHCF rhcf(dimension, is_occupied_func);

    double xrobot[3];
    double xgoal[2];
    xrobot[0] = pt1[0], xrobot[1] = pt1[1];
    xgoal[0]  = pt2[0], xgoal[1]  = pt2[1];

    rhcf.readScenario(xrobot, xgoal,
                      0, 1, 1, dimension[0], 0, dimension[1], 0,
                      1e4); // wait at most 10 seconds
    gettimeofday(&tv_after, &tz);
    build_cost = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
    std::cout << "-- load RHCF end in " << build_cost << "ms" << std::endl;

    zoom_rate = min(2560/dimension[0], 1280/dimension[1]);

    Canvas canvas("RimJump::DistinctiveTopologyPathPlanning", dimension[0], dimension[1], .05, zoom_rate);
//231, 224) -> (233, 225
// 128, 45) -> (73, 0
// 219, 146) -> (255, 39
// {59, 72}, {109, 214}
    auto callback = [](int event, int x, int y, int flags, void *) {
        if(event == CV_EVENT_LBUTTONDOWN) {
            if(set_pt1) {
                pt1[0] = x;
                pt1[1] = y;
                sg1->pt_ = pt1;
                sg1->id_ = PointiToId<2>(pt1, dimension);
                set_pt1 = false;
                plan_finish = false;
                std::cout << "get point " << x << ", " << y << std::endl;
            } else {
                pt2[0] = x;
                pt2[1] = y;
                sg2->pt_ = pt2;
                sg2->id_ = PointiToId<2>(pt2, dimension);
                set_pt1 = true;
                std::cout << "get point " << x << ", " << y << std::endl;
                new_pair = true;
                plan_finish = false;
            }
        }
    };
    canvas.setMouseCallBack(callback);
    canvas.drawGridMap(dimension, is_occupied_func);

    Canvas canvas_map("RimJump::GetMap", dimension[0], dimension[1], .05, 1);
    canvas_map.drawGridMap(dimension, is_occupied_func);
    cv::Mat background = canvas_map.getCanvas();
    // find paths
    gettimeofday(&tv_pre, &tz);
    cvMulticlassPathPlanner<AStar> path_planner (background, is_occupied_func); // 2 path 13 ms
    gettimeofday(&tv_after, &tz);
    build_cost = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
    std::cout << "-- load H-star astar end in " << build_cost << "ms" << std::endl;

    ExitCode ec;
    int number_of_paths = 50;
    double total_cost_RJ = 0, total_cost_RHCF = 0, total_cost_HA = 0, total_cost_HT = 0;
    int count_planning = 0, repeat_of_planning = 1;
    while(1) {
        canvas.resetCanvas();
        canvas.drawEmptyGrid();
        canvas.drawGridMap(dimension, is_occupied_func);
        if(draw_representation_point) {
//            for(const auto& pt : path_planner.my_map.repPts) {
//                canvas.drawGrid(pt.x, pt.y, cv::Vec3b(0,255,0));
//            }
            canvas.drawNodes(tg, center_offset, COLOR_TABLE[0]);
        }
        if(new_pair) {
            new_pair = false;
            if(tp.pool_[0].joinable() && !plan_finish) {
                tp.Schedule([&] {
                    count_planning ++;
                    for(int i=0; i<repeat_of_planning; i++) {
                        ec = g2p2.planningWithNode(pt1, pt2, init_ptcs, init_etcs, ics_node_topology, rj_paths, false,
                                                   false, false, 10);
                        auto statistic_without = g2p2.getStatistic();
                        if (ec != ExitCode::SUCCESS) {
                            std::cout << "-- RimJump WithOut failed with " << ec << " in " << statistic_without[2]
                                      << " + " << statistic_without[3]
                                      << "ms" << std::endl;
                        } else {
                            std::cout << "-- RimJump WithOut success in " << statistic_without[2] << " + "
                                      << statistic_without[3] << "ms, find " << rj_paths.size()
                                      << " paths " << std::endl;
                        }
                        total_cost_RJ += (statistic_without[2] + statistic_without[3]);
//                    ec = g2p2.planningWithNode(pt1, pt2, init_ptcs, init_etcs, ics_node_topology, rj_paths, false, false, false, 320);//number_of_paths);
//                    statistic_without = g2p2.getStatistic();
//                    if (ec != ExitCode::SUCCESS) {
//                        std::cout << "-- RimJump WithOut failed with " << ec << " in " << statistic_without[2] << " + " << statistic_without[3]
//                                  << "ms" << std::endl;
//                    } else {
//                        std::cout << "-- RimJump WithOut success in " << statistic_without[2] << " + " << statistic_without[3] << "ms, find " << rj_paths.size()
//                                  << " paths " << std::endl;
//                    }

                        gettimeofday(&tv_pre, &tz);

                        double xrobot[3];
                        double xgoal[2];

                        xrobot[0] = pt1[0], xrobot[1] = pt1[1];
                        xgoal[0] = pt2[0], xgoal[1] = pt2[1];

                        rhcf.scene_->setRobot(pt1[0], pt1[1], 0);
                        rhcf.scene_->setGoal(pt2[0], pt2[1]);
                        rhcf.buildVoronoiDiagram();
                        rhcf.buildNavigationGraph();
                        gettimeofday(&tv_after, &tz);
                        double cost_ms1 =
                                (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
                        gettimeofday(&tv_pre, &tz);
                        rhcf.K_ = 10;
                        rhcf.findHomotopyClasses();
                        gettimeofday(&tv_after, &tz);
                        double cost_ms2 =
                                (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
                        std::cout << "-- RHCF find " << rhcf.all_result_path_.size() << " paths in " << cost_ms1 << "+"
                                  << cost_ms2 << " ms" << std::endl;
                        total_cost_RHCF += (cost_ms1 + cost_ms2);
                        rhcf_paths = rhcf.all_result_path_;

                        // do DOSL(HStar) homotopy path planning
                        gettimeofday(&tv_pre, &tz);
                        cv::Point start(pt1[0], pt1[1]), target(pt2[0], pt2[1]);
                        cvMulticlassPathPlanner<AStar> path_planner_as(background, is_occupied_func); // something wrong
                        path_planner_as.find_paths(start, target, 10, false);//number_of_paths, false);
                        auto raw_hstar_paths = path_planner_as.paths;
                        hstar_paths_as.clear();
                        for (const auto &hstar_path : raw_hstar_paths) {
                            Path<2> path;
                            for (const auto &pt : hstar_path) {
                                Pointi<2> rj_pt({pt.x, pt.y});
                                path.push_back(rj_pt);
                            }
                            hstar_paths_as.push_back(path);
                        }
                        gettimeofday(&tv_after, &tz);
                        double cost_hstar =
                                (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
                        total_cost_HA += (cost_hstar);
                        std::cout << "-- HAstar as find " << hstar_paths_as.size() << " paths in " << cost_hstar
                                  << " ms" << std::endl;

                        gettimeofday(&tv_pre, &tz);
                        cvMulticlassPathPlanner<ThetaStar> path_planner_ts(background,
                                                                           is_occupied_func); // something wrong
                        path_planner_ts.find_paths(start, target, 10, false);//number_of_paths, false);
                        raw_hstar_paths = path_planner_ts.paths;
                        hstar_paths_ts.clear();
                        for (const auto &hstar_path : raw_hstar_paths) {
                            Path<2> path;
                            for (const auto &pt : hstar_path) {
                                Pointi<2> rj_pt({pt.x, pt.y});
                                path.push_back(rj_pt);
                            }
                            hstar_paths_ts.push_back(path);
                        }
                        gettimeofday(&tv_after, &tz);
                        cost_hstar =
                                (tv_after.tv_sec - tv_pre.tv_sec) * 1e3 + (tv_after.tv_usec - tv_pre.tv_usec) / 1e3;
                        total_cost_HT += (cost_hstar);
                        std::cout << "-- HTstar ts find " << hstar_paths_ts.size() << " paths in " << cost_hstar
                                  << " ms" << std::endl;
                    }
                    std::cout << "mean RJ      = " << total_cost_RJ/repeat_of_planning/count_planning << std::endl
                              << "mean RHCF    = " << total_cost_RHCF/repeat_of_planning/count_planning << std::endl
                              << "mean HA*     = " << total_cost_HA/repeat_of_planning/count_planning << std::endl
                              << "mean HTheta* = " << total_cost_HT/repeat_of_planning/count_planning << std::endl;
                    plan_finish = true;
                });
            }
        }

        if(plan_finish && !paths.empty()) {
            if(draw_all_path) {
                for (int i=0; i<paths.size(); i++) {
                    canvas.drawPath(paths[i], center_offset, COLOR_TABLE[i%30]);
                }
            } else {
                canvas.drawPath(paths[current_show_index], center_offset, COLOR_TABLE[current_show_index]);
            }
        }

        canvas.drawCircleInt(pt1[0], pt1[1], 5, center_offset, -1, COLOR_TABLE[0]);
        canvas.drawCircleInt(pt2[0], pt2[1], 5, center_offset, -1, COLOR_TABLE[1]);
        char key_value = canvas.show(33);
        if(key_value == 'r') {
            show_rj = !show_rj;
            paths = rj_paths;
        } else if(key_value == 'h') {
            show_hstar_as = !show_hstar_as;
            paths = hstar_paths_as;
        } else if(key_value == 't') {
            show_hstar_ts = !show_hstar_ts;
            paths = hstar_paths_ts;
        } else if(key_value == 'v') {
            show_rhcf = !show_rhcf;
            paths = rhcf_paths;
        }
        else if(key_value == 'a') {
            draw_all_path = !draw_all_path;
        } else if(key_value == 'w' && plan_finish) {
            if(!paths.empty()) {
                current_show_index++;
                current_show_index = current_show_index % paths.size();
            }
        } else if(key_value == 's' && plan_finish) {
            if(!paths.empty()) {
                current_show_index--;
                current_show_index += paths.size();
                current_show_index = current_show_index % paths.size();
            }
        } else if(key_value == 'p') {
            draw_representation_point = !draw_representation_point;
        }
    }

}