//
// Created by yaozhuo on 2022/3/24.
//

#include "canvas/canvas.h"
#include "gtest/gtest.h"
#include "2d_grid/picture_loader.h"

#include "dependencies/thread_pool.h"
#include "sys/time.h"

#include "ENLSVG.h"

std::shared_ptr<Pathfinding::Grid> grid_ptr = nullptr;
using namespace freeNav;
using namespace freeNav::RimJump;

auto is_occupied = [](const Pointi<2> & pt) -> bool { return grid_ptr->isBlocked(pt[0], pt[1]); };

bool (*f1)(const Pointi<2>&) = is_occupied;

int zoom_rate = 1;

Pointi<2> pt1, pt2;

bool set_pt1 = true;

bool new_pair = false;
bool plan_finish = false;

using namespace freeNav::RimJump;

int main() {
}

