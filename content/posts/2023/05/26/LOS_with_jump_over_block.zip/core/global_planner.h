#ifndef _GLOBAL_PLANNER_H_
#define _GLOBAL_PLANNER_H_

#include "states.h"
#include "vehicle.h"
#include "environment.h"
namespace freeNav {
    class GlobalPlanner {
    public:

        virtual bool plan(MotionStates& result_path) = 0;

        bool setTarget(MotionStatePtr target_state) {
            if(target_state == nullptr) { return false; }
            target_state_ = std::move(target_state);
            return true;
        }

        MotionStatePtr getTargetState() {
            return target_state_;
        }

        bool setVehicle(VehiclePtr vehicle) {
            if(vehicle == nullptr) { return false; }
            vehicle_ = std::move(vehicle);
            return true;
        }

        bool setEnvironment(EnvironmentPtr environment) {
            if(environment == nullptr) { return false; }
            environment_ = std::move(environment);
            return true;
        }

        VehiclePtr getVehicle() const {
            return vehicle_;
        }

        EnvironmentPtr getEnvironment() const {
            return environment_;
        }

    private:
        EnvironmentPtr environment_;
        VehiclePtr vehicle_;
        MotionStatePtr target_state_;
    };

    typedef std::shared_ptr<GlobalPlanner> GlobalPlannerPtr;
}
#endif