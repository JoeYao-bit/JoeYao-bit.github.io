#ifndef _VEHICLE_H_
#define _VEHICLE_H_

#include "states.h"
#include "environment.h"
#include <memory>
namespace freeNav {

/* the abstract interfaces of a general motion model */
    class MotionModel {
    public:
        // PROJECTION: return false cannot find a feasible cmd solution
        virtual bool calcControlCmd(MotionStatePtr current_states,
                                    MotionStatePtr target_states,
                                    ControlCmd &cmd,
                                    double control_frequency) = 0;

        // CONSTRAINT: return false doesn't in reach
        virtual bool positionInReach(MotionStatePtr current_states,
                                     const Vec3d &target_position,
                                     double predict_time) = 0;

        // CONSTRAINT: return false doesn't in reach
        virtual bool motionStatesInReach(MotionStatePtr current_states,
                                         MotionStatePtr target_states,
                                         double control_frequency) = 0;
    };

    typedef std::shared_ptr<MotionModel> MotionModelPtr;
    class Vehicle {
    public:
        explicit Vehicle(std::shared_ptr<MotionModel> motion_model,
                         std::shared_ptr<MotionState> initial_motion_states) {
            motion_model_  = std::move(motion_model);
            motion_state_  = std::move(initial_motion_states);
        }

        // update current center state of the vehicle
        // return true if new motion state within the limitation of motion model
        // return false if not
        bool update(MotionStatePtr motion_state) {
            if(motion_state == nullptr) { return false; }
            motion_state_ = std::move(motion_state);
            return true;
        }

        // whether the position in the vehicle's reach in next predict_time (s),
        // used to limit the range of path planning
        bool positionInReach(const Vec3d &position, double predict_time) {
            if(motion_model_ == nullptr) { return false; }
            return motion_model_->positionInReach(motion_state_, position, predict_time);
        }

        // whether the next motion states in the vehicle's reach in next predict_time (s),
        // used to limit the range of trajectory planning
        bool motionStatesInReach(MotionStatePtr next_state, double control_frequency) {
            if(motion_model_ == nullptr) { return false; }
            return motion_model_->motionStatesInReach(motion_state_, next_state, control_frequency);
        }

        bool setMotionModel(MotionModelPtr motion_model) {
            if(motion_model == nullptr) { return false; }
            motion_model_ = std::move(motion_model);
            return true;
        }

        virtual bool isCollide(EnvironmentPtr environment, MotionStatePtr motion_state) = 0;

        virtual bool distanceToObstacle(EnvironmentPtr environment, MotionStatePtr motion_state) = 0;


        MotionStatePtr getMotionState() {
            return motion_state_;
        }

    private:
        // motion model defines the limitation of motion states,
        // assume the movement of vehicle is a Markov process,
        // the next motion state is only determined by current motion state and control input
        MotionModelPtr motion_model_;
        MotionStatePtr motion_state_;
    };

    typedef std::shared_ptr<Vehicle> VehiclePtr;
}


#endif