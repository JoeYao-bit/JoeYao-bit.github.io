//
// Created by yaozhuo on 2023/6/19.
//

#ifndef FREENAV_SINGLE_PATH_PLANNING_H
#define FREENAV_SINGLE_PATH_PLANNING_H

#include "basic.h"
#include<boost/unordered_set.hpp>

namespace freeNav::CBS {

    typedef double HeuristicValue;

    typedef std::vector<HeuristicValue> HeuristicTable;

    typedef std::vector<HeuristicTable> HeuristicTables;

    // calculate static heuristic table, using BFS, dist to target = 0
    template <Dimension N>
    HeuristicTable calculateStaticHeuristic(const Pointi<N>& start, const Pointi<N>& target,
                                             DimensionLength* dim, const IS_OCCUPIED_FUNC<N>& isoc) {
        Id total_index = getTotalIndexOfSpace<N>(dim);
        HeuristicTable heuristic(total_index, MAX<HeuristicValue>);
        std::vector<Pointi<N> > current_set;
        current_set.push_back(target);
        Id id = PointiToId(target, dim), next_id;
        heuristic[id] = 0; // in target, dist to target = 0
        HeuristicValue current_h, next_h;
        Pointi<N> next_pt;
        auto neighbors = GetNearestOffsetGrids<N>();
        while(!current_set.empty()) {
            std::vector<Pointi<N> > next_set;
            for(const auto& pt : current_set) {
                id = PointiToId(pt, dim);
                current_h = heuristic[id];
                next_h = current_h + 1;
                for(const auto& offset : neighbors) {
                    next_pt = pt + offset;
                    next_id = PointiToId(next_pt, dim);
                    if(isoc(next_pt)) continue;
                    if(heuristic[next_id] > next_h) {
                        heuristic[next_id] = next_h;
                        next_set.push_back(next_pt);
                    }
                }
            }
            current_set.clear();
            std::swap(current_set, next_set);
        }
        // use BFS to calculate heuristic value for all free grid, and obstacle heuristic
        return heuristic;
    }

    template <Dimension N>
    struct SinglePathPlanning {
    public:
        // return empty if found no path
        virtual Path<N> solve(const Pointi<N>& start, const Pointi<N>& target, const ConstraintTablePtr<N>& ct, const Id& step_upper_bound) = 0;
    };

    template <Dimension N>
    using SinglePathPlanningPtr = std::shared_ptr<SinglePathPlanning<N> >;

    template <Dimension N>
    Path<N> retrievePathFromNode(const LowLvNodePtr<N>& node_ptr) {
        auto current_node = node_ptr;
        Pointi<N> pt;
        Path<N> retv;
        while(current_node != nullptr) {
            pt = current_node->pt_;
            retv.push_back(pt);
            current_node = current_node->pa_;
        }
        std::reverse(retv.begin(), retv.end());
        return retv;
    }

    template <Dimension N>
    struct SpaceTimeAStar : public SinglePathPlanning<N> {
    public:

        enum LowLvSolverType {Astar, AstarFocal};


        void setHeuristicTable(const HeuristicTable& ht) {
            ht_ = ht;
        }

        virtual Path<N> solve(const Pointi<N>& start, const Pointi<N>& target,
                              const ConstraintTablePtr<N>& ct,
                              const Id& step_upper_bound) {
            // add root to open set
            auto root = generateRootNode(start, target, ct, step_upper_bound);
            root->open_handle_ = open_set_.push(root);
            root->focal_handle_ = open_set_focal_.push(root);
            // DFS
            auto neighbors = GetNearestOffsetGrids<N>();
            neighbors.push_back(Pointi<N>());
            int count = 0;
            auto max_heap_size = open_set_.size();
            Id max_time = 0;
            while(!open_set_.empty()) {
                //std::cout << count << " th, open size =" << open_set_.size() << " focal size = " << open_set_focal_.size() << std::endl;
                // pop out current expansion
                LowLvNodePtr<N> current_node = selectNode();

                Pointi<N> new_pt;
                max_heap_size = std::max(open_set_.size(), max_heap_size);
                for(const auto& offset : neighbors) {
                    new_pt = current_node->pt_ + offset;
                    // do static map check
                    if(ct->isoc_(new_pt)) { continue; }
                    // create next node
                    LowLvNodePtr<N> next_node = std::make_shared<LowLvNode<N> >(current_node, step_upper_bound);
                    next_node->pt_ = new_pt;
                    next_node->id_ = PointiToId(new_pt, ct->dimen_);
                    next_node->t_ = current_node->t_ + 1;


                    max_time = std::max(max_time, next_node->t_);
//                    if(next_node->t_ == MAX_TIME) {
//                        std::cout << " time reach MAX_TIME " << std::endl;
//                    }
                    if(next_node->t_ >= step_upper_bound) { continue; }
                    // set cost about focal search
                    if(close_set_.find(next_node) != close_set_.end()) { continue; }
                    close_set_.insert(next_node);

                    // do vertex constraint and edge constraint check
                    if(!pathConstraintCheck(current_node, next_node, ct)) { continue; }

                    next_node->cc_ = next_node->t_;
                    //std::cout << " pt " << next_node->pt_ << " / t " << next_node->t_ << std::endl;
                    next_node->fc_ = ht_.empty() ? (target - new_pt).manhattan() : ht_[next_node->id_];
                    if(solver_type_ == LowLvSolverType::AstarFocal) {
                        next_node->cc_f_ = 0;
                        next_node->fc_f_ = current_node->fc_f_ + pathSoftConstraintCount(current_node, next_node, ct);
                    }
                    if(new_pt == target) {
                        // reach target
                        //std::cout << "after " << count << " iteration with maximum heap size = "
                        //          << max_heap_size << ", with maximum time = " << max_time << ", success" << std::endl;
                        auto retv = retrievePathFromNode(next_node);
                        //std::cout << " retv path: " << retv << std::endl;
                        return retv;
                    } else {
                        // add to open set
                        pushNode(next_node);
                    }
                }
                count ++;
            }
            //std::cout << "after " << count << " iteration with maximum heap size = "
            //          << max_heap_size << ", with maximum time = " << max_time << ", failed" << std::endl;
            return {};
        }

    private:

        LowLvNodePtr<N> generateRootNode(const Pointi<N>& start, const Pointi<N>& target,
                                     const ConstraintTablePtr<N>& ct,
                                     const Id& step_upper_bound) {
            LowLvNodePtr<N> root = std::make_shared<LowLvNode<N> >(nullptr, step_upper_bound);
            root->pt_ = start;
            root->id_ = PointiToId(start, ct->dimen_);
            root->cc_ = 0;
            root->fc_ = ht_.empty() ? (target - target).manhattan() : ht_[root->id_];
            root->cc_f_ = 0;
            root->fc_f_ = 0;
            root->t_ = 0;
            return root;
        }

        LowLvNodePtr<N> selectNode() {
            LowLvNodePtr<N> current_node;
            switch (solver_type_) {
                case LowLvSolverType::Astar:
                default:
                    current_node = std::dynamic_pointer_cast<LowLvNode<N> >(open_set_.top());
                    open_set_.pop();
                    break;
                case LowLvSolverType::AstarFocal:
                    if(open_set_focal_.empty()) {
                        open_set_.top()->focal_handle_ = open_set_focal_.push(open_set_.top());
                        //std::cout << " new focal cost 3 = " << open_set_.top()->cc_f_ + open_set_.top()->fc_f_ << std::endl;
                    }
                    current_node = std::dynamic_pointer_cast<LowLvNode<N> >(open_set_focal_.top());
                    open_set_focal_.pop();
                    open_set_.erase(current_node->open_handle_);
                    //std::cout << " pop focal cost = " << current_node->cc_f_ + current_node->fc_f_ << std::endl;
                    break;
            }
            return current_node;
        }

        void pushNode(const LowLvNodePtr<N>& next_node) {
            switch (solver_type_) {
                case LowLvSolverType::Astar:
                default:
                    next_node->open_handle_ = open_set_.push(next_node);
                    break;
                case LowLvSolverType::AstarFocal:
                    next_node->open_handle_ = open_set_.push(next_node);
                    // check whether insert to focal set
                    const auto& min_node = open_set_.top();
                    auto min_cost = min_node->cc_ + min_node->fc_;
                    if(open_set_focal_.empty()) {
                        open_set_.top()->focal_handle_ = open_set_focal_.push(open_set_.top());
                        //std::cout << " new focal cost 1 = " << open_set_.top()->cc_f_ + open_set_.top()->fc_f_ << std::endl;
                    } else {
                        if (next_node->cc_ + next_node->fc_ <= min_cost * focal_w_) {
                            next_node->focal_handle_ = open_set_focal_.push(next_node);
                            //std::cout << " new focal cost 2 = " << next_node->cc_f_ + next_node->fc_f_ << std::endl;
                        }
                    }
                    break;
            }
        }

        HeuristicSortHeap<N, LowLvNode<N> > open_set_; // vertex that will be expand
        HeuristicSortHeapFocal<N, LowLvNode<N> > open_set_focal_; // vertex that will be expand

        boost::unordered_set<LowLvNodePtr<N>,
                             typename LowLvNode<N>::LowLvNodeHash,
                             typename LowLvNode<N>::LowLvNodeEqual> close_set_; // id of vertex that have been expand
        HeuristicTable ht_;

        LowLvSolverType solver_type_ = LowLvSolverType::Astar;//Focal;

        // larger w result faster search, but longer path
        // smaller w result slower search, but shorter path
        float focal_w_ = 4; // focal ratio must >= 1, should be too small



    };

    template <Dimension N>
    using SpaceTimeAStarPtr = std::shared_ptr<SpaceTimeAStar<N> >;

}
#endif //FREENAV_SINGLE_PATH_PLANNING_H
