//
// Created by yaozhuo on 2023/6/18.
//

#ifndef FREENAV_CONFLICT_H
#define FREENAV_CONFLICT_H

#include <memory>
#include <boost/unordered_map.hpp>
#include "rim_jump/basic_elements/point.h"
#include <boost/heap/pairing_heap.hpp>

namespace freeNav::CBS {

    //const Id MAX_TIME = 60;

    typedef float Cost;

    template <Dimension N>
    struct HeuristicNode;

    template <Dimension N>
    using HeuristicNodePtr = std::shared_ptr<HeuristicNode<N> >;

    template <Dimension N, typename T>
    using HeuristicSortHeap      = boost::heap::pairing_heap<std::shared_ptr<T>, boost::heap::compare<typename T::compare_node> >;

    template <Dimension N, typename T>
    using HeuristicSortHeapFocal = boost::heap::pairing_heap<std::shared_ptr<T>, boost::heap::compare<typename T::compare_node_focal> >;


    template <Dimension N>
    struct HeuristicNode {

        explicit HeuristicNode() {}

        struct compare_node {
            bool operator() (const HeuristicNodePtr<N>& n1, const HeuristicNodePtr<N>& n2) const {
                return (n1->cc_ + n1->fc_) >= (n2->cc_ + n2->fc_);
            }
        };

        struct compare_node_focal {
            bool operator() (const HeuristicNodePtr<N>& n1, const HeuristicNodePtr<N>& n2) const {
                if(n1->cc_f_ + n1->fc_f_ == n2->cc_f_ + n2->fc_f_) {
                    if(n1->cc_ + n1->fc_ == n2->cc_ + n2->fc_) {
                        return n1->fc_ >= n2->fc_;
                    }
                    return n1->cc_ + n1->fc_ >= n2->cc_ + n2->fc_;
                }
                return (n1->cc_f_ + n1->fc_f_) >= (n2->cc_f_ + n2->fc_f_);
            }
        };

        Cost cc_ = 0; // current cost

        Cost fc_ = 0; // future cost estimation

        Cost cc_f_ = 0; // current cost for focal A*

        Cost fc_f_ = 0; // future cost for focal A*

    };

    template <Dimension N, typename NODE>
    struct TreeNode {

        explicit TreeNode(const NODE& pa) : pa_(pa) {
            if(pa != nullptr) {
                depth_ = pa->depth_ + 1;
            }
        }

        NODE pa_ = nullptr; // parent node

        std::vector<NODE> ch_ = {}; // children node, optional

        int depth_ = 0;

    };

    // constraint that forbid the agent pass the vertex or edge at time index
    template <Dimension N>
    class Constraint {
    public:

        explicit Constraint(const Id& agent_id, const Pointis<N>& pts, const IdVector& tz)
        : id_(agent_id), pts_(pts), tz_(tz)
        {}

        // al_ only affect the performance of edge constraint, do not affect the performance of vertex constraint
        Id id_; // what agent in conflict that are limited by this constraint, false = a1 limited / true = a2 limited

        Pointis<N> pts_; // conflict that generate current constraint

        IdVector tz_; // agent id that limited by current constraint

    };

    template <Dimension N>
    using ConstraintPtr = std::shared_ptr<Constraint<N> >;

    template <Dimension N>
    using ConstraintPtrs = std::vector<ConstraintPtr<N> >;

    template <Dimension N>
    struct Conflict;

    template <Dimension N>
    using ConflictPtr = std::shared_ptr<Conflict<N> >;

    template <Dimension N>
    using ConflictPtrs = std::vector<ConflictPtr<N> >;

    template <Dimension N>
    using ConflictPtrss = std::vector<ConflictPtrs<N> >;

    // define that two agents a1, a2 have conflict in vertex v1 or edge (v1->v2) at time t
    template <Dimension N>
    struct Conflict : public HeuristicNode<N>  {

        explicit Conflict(const ConstraintPtr<N>& cs1, const ConstraintPtr<N>& cs2)
        :cs1_(cs1), cs2_(cs2) {}

        ConstraintPtr<N> cs1_;
        ConstraintPtr<N> cs2_;

    };

    // agent 1 <=> ps1, agent 2 <=> ps2
    // only check the earliest conflict, as when fix previous conflict, may make following conflict may disappear
    template <Dimension N>
    ConflictPtrs<N> determineConflictBetweenTwoPath(const Id& a1, const Id& a2, const Path<N>& ps1, const Path<N>& ps2, const Id& step_upper_bound_) {
        Id common_range = std::min(ps1.size(), ps2.size());
        ConflictPtrs<N> retv;
        for(Id t=0; t<common_range-1; t++) {
            // determine vertex conflict
            if(ps1[t] == ps2[t]) {
                //std::cout << " vc1 " << ps1[t] << std::endl;
                ConstraintPtr<N> cs1 = std::make_shared<Constraint<N>>(a1, Pointis<N>{ps1[t]}, IdVector{t, t+1});
                ConstraintPtr<N> cs2 = std::make_shared<Constraint<N>>(a2, Pointis<N>{ps1[t]}, IdVector{t, t+1});

                ConflictPtr<N> cf = std::make_shared<Conflict<N> >(cs1, cs2);

                retv.push_back(cf);
                return retv;
            }
            // determine edge conflict
            if(ps1[t] == ps2[t+1] && ps1[t+1] == ps2[t]) {
                if(ps1[t] == ps1[t+1]) { continue; }
                ConstraintPtr<N> cs1 = std::make_shared<Constraint<N>>(a1, Pointis<N>{ps1[t], ps1[t+1]}, IdVector{t, t+1});
                ConstraintPtr<N> cs2 = std::make_shared<Constraint<N>>(a2, Pointis<N>{ps2[t], ps2[t+1]}, IdVector{t, t+1});

                ConflictPtr<N> cf = std::make_shared<Conflict<N> >(cs1, cs2);

                retv.push_back(cf);
                return retv;
            }
        }
        if(ps1.back() == ps2.back()) {
            std::cout << " agent " << a1 << "/" << a2 << " have the same target" << std::endl;
        }
        // assume two agent do not have the same target, means if they have different end
        if(ps1.size() == ps2.size()) { return retv; }
        // determine over size conflict
        Id max_range = std::max(ps1.size(), ps2.size());
        const auto & longer_id    = ps1.size() > ps2.size() ? a1  : a2;
        const auto & shorter_id   = ps1.size() < ps2.size() ? a1  : a2;

        const auto & longer_path  = ps1.size() > ps2.size() ? ps1 : ps2;
        const auto & shorter_path = ps1.size() < ps2.size() ? ps1 : ps2;
        //std::cout << "shorter_path.back() = " << shorter_path.back() << std::endl; //
        for(Id t=common_range; t<max_range; t++) {
            if(shorter_path.back() == longer_path[t]) {

                // add vertex conflict
//                ConflictPtr<N> cf = std::make_shared<Conflict<N> >();
//                cf->ag_ = {a1, a2};
//                cf->pt_ = {longer_path[t]};
                //std::cout << " vc2 " << longer_path[t] << " / t " << common_range -1 << std::endl;
//                cf->t1_ = t, cf->t2_ = t + 1;
//                retv.push_back(cf);

                ConstraintPtr<N> cs1 = std::make_shared<Constraint<N> >(longer_id,
                                                                        Pointis<N>{longer_path[t]},
                                                                        IdVector{common_range-1, step_upper_bound_});

                // considering previous path have constrained by previous constraint
                ConstraintPtr<N> cs2 = std::make_shared<Constraint<N> >(shorter_id,
                                                                        Pointis<N>{shorter_path.back()},
                                                                        IdVector{0, t+1}); // common_range-1 too slow

                ConflictPtr<N> cf = std::make_shared<Conflict<N> >(cs1, cs2);

                retv.push_back(cf);
                return retv;
            }
        }
        return retv;
    }

    template <Dimension N>
    struct LowLvNode;

    template <Dimension N>
    using LowLvNodePtr = std::shared_ptr<LowLvNode<N> >;

    template <Dimension N>
    struct LowLvNode : public HeuristicNode<N>, TreeNode<N, LowLvNodePtr<N> > {

        explicit LowLvNode(const LowLvNodePtr<N>& parent, const Id& step_upper_bound)
                 : TreeNode<N, LowLvNodePtr<N>>(parent), step_upper_bound_(step_upper_bound) {
            //
        }

        struct LowLvNodeHash {
            Id operator() (const LowLvNodePtr<N>& node_ptr) const {
                return node_ptr->id_ * node_ptr->step_upper_bound_ + node_ptr->t_;
            }
        };

        struct LowLvNodeEqual
        {
            bool operator()(const LowLvNodePtr<N>& n1, const LowLvNodePtr<N>& n2) const
            {
                // yz: the same pointer or the same value
                return (n1->id_ * n1->step_upper_bound_ + n1->t_ == n2->id_ * n2->step_upper_bound_ + n2->t_);
            }
        };


        Pointi<N> pt_;

        Id id_;

        Id t_;

        Id step_upper_bound_;

        typename HeuristicSortHeap<N, LowLvNode<N> >::handle_type open_handle_;

        typename HeuristicSortHeapFocal<N, LowLvNode<N> >::handle_type focal_handle_;

    };


    template <Dimension N>
    struct UpLvNode;

    template <Dimension N>
    using UpLvNodePtr = std::shared_ptr<UpLvNode<N> >;

    template <Dimension N>
    using UpLvNodePtrs = std::vector<UpLvNode<N> >;

    template <Dimension N>
    struct UpLvNode : public HeuristicNode<N>, TreeNode<N, UpLvNodePtr<N> > {

        explicit UpLvNode(const UpLvNodePtr<N>& parent, const ConstraintPtr<N>& cs) : TreeNode<N, UpLvNodePtr<N> >(parent), cs_(cs) {
        }

        // conflict under of path under all history constraints, include current constraint
        // save conflict in time order
        ConflictPtrs<N> cfs_;

        ConstraintPtr<N> cs_; // current selected conflict and constraint from it

        // replanned path under current constraint
        // generally, only one new constraint is added for one agent, replanned only once
        //boost::unordered_map<Id, Path<N> > rpps_;
        Path<N> rpps_;

        typename HeuristicSortHeap<N, UpLvNode<N> >::handle_type open_handle_;

        typename HeuristicSortHeapFocal<N, UpLvNode<N> >::handle_type focal_handle_;

    };

    // including both dynamic and static constraint (grid map), for an agent
    template <Dimension N>
    struct ConstraintTable {

    public:

        explicit ConstraintTable(const Id& agent_id, DimensionLength* dim, const IS_OCCUPIED_FUNC<N>& isoc) : id_(agent_id), dimen_(dim),isoc_(isoc) {}

        boost::unordered_map<Id, ConstraintPtrs<N> > ctm_; // store vertex/edge constraints for each grid, if found no a grid, it has no constraint

        boost::unordered_map<Id, ConstraintPtrs<N> > ctm_soft_; // store soft constraints for each grid, if found no a grid, it has no constraint

        IS_OCCUPIED_FUNC<N> isoc_;// grid occupied state check, in other words, static grid constraint
        DimensionLength* dimen_; // space scale info
        Id id_;

        void setPathsConstraint(const Paths<N>& paths, int excluted_agent_id, bool soft = false) {
            for(int i=0; i<paths.size(); i++) {
                if(i == excluted_agent_id) { continue; }
                setPathConstraint(i, paths[i], soft);
            }
        }

        void setPathConstraint(const Id& other_agent_id, const Path<N>& other_agent_path, bool soft=false) {
            // set waypoint as vertex constraint
            for(Id t=0; t<other_agent_path.size(); t++) {

                ConstraintPtr<N> cs = std::make_shared<Constraint<N>>(id_,
                                                                      Pointis<N>{other_agent_path[t]},
                                                                      IdVector{t, t+1});

                setConstraint(cs, soft);
            }
            // set edge as edge constraint
            for(Id t=0; t<other_agent_path.size()-1; t++) {
                ConstraintPtr<N> cs = std::make_shared<Constraint<N>>(id_,
                                                                      Pointis<N>{other_agent_path[t+1], other_agent_path[t]},
                                                                      IdVector{t, t+1});
                setConstraint(cs, soft);
            }
        }

        // insert constraint to constraint table
        // the constraint must belong to current agent
        inline void setConstraint(const ConstraintPtr<N>& cs, bool soft=false) {
            Id tid;
            if(cs->pts_.size() == 1) {
                tid = PointiToId(cs->pts_[0], dimen_);
            } else if(cs->pts_.size() == 2) {
                tid = PointiToId(cs->pts_[1], dimen_);
            } else {
                std::cerr << " wrong cs pt size = " << cs->pts_.size() << std::endl;
                exit(0);
            }
            addConstraintToTable(tid, cs, soft);
        }

        // inherit previous constraint that involve current agent
        void setUpLvNodePtrConstraints(const UpLvNodePtr<N>& node_ptr, int agent_id) {
            UpLvNodePtr<N> current_node = node_ptr;
            while(current_node != nullptr) {
                if(current_node->cs_ == nullptr) { break; }
                if(current_node->cs_->id_ == agent_id) {
                    setConstraint(current_node->cs_);
                }
                current_node = current_node->pa_;
            }
        }

    private:

        inline void addConstraintToTable(Id& grid_id, const ConstraintPtr<N>& cs, bool soft=false) {
            if(soft) {
                auto iterator = ctm_soft_.find(grid_id);
                if (iterator == ctm_soft_.end()) {
                    ctm_soft_.insert({grid_id, {cs}});
                } else {
                    iterator->second.push_back(cs);
                }
            } else {
                auto iterator = ctm_.find(grid_id);
                if (iterator == ctm_.end()) {
                    ctm_.insert({grid_id, {cs}});
                } else {
                    iterator->second.push_back(cs);
                }
            }
        }
    };

    // edge conflict store in the vertex it head in

    template <Dimension N>
    using ConstraintTablePtr = std::shared_ptr<ConstraintTable<N> >;

    // assume current node satisfied vertex constraint
    template <Dimension N>
    bool pathConstraintCheck(const LowLvNodePtr<N>& current_node, const LowLvNodePtr<N>& new_node, const ConstraintTablePtr<N>& ct) {
        assert(new_node->t_ == current_node->t_ + 1);
        // do static map collide check before check dynamic constraint
        auto dynamic_constraint = ct->ctm_.find(new_node->id_);
        // if no dynamic constraint
        if(dynamic_constraint == ct->ctm_.end()) { return true; }
        const auto& constraints = dynamic_constraint->second;
        if(constraints.empty()) { return true; }
        for(const auto& cs : constraints) {
            //std::cout << "ct " << ct << std::endl;
            if(cs->pts_.size() == 1) {
                // vertex constraint check
                // check whether time range match
                if(new_node->t_ >= cs->tz_[0] && new_node->t_ < cs->tz_[1]) {
                    //std::cout << " vc new_node " << new_node->pt_ << " / " << new_node->t_ << std::endl;
                    return false;
                }
            } else if(cs->pts_.size() == 2) {
                // edge constraint check
                // check whether is the same edge
                //std::cout << " new node " << new_node->pt_ << " / current node " << current_node->pt_ << std::endl;
                //std::cout << " ct->cf_ pt " << ct->cf_->pt_ << std::endl;
                if (cs->pts_[0] != current_node->pt_) { continue; }

                if(current_node->t_ >= cs->tz_[0] && new_node->t_ <= cs->tz_[1]) {
                    //std::cout << " ec new_node " << current_node->pt_ << "->" << new_node->pt_ << " / " << new_node->t_ << std::endl;
                    return false;
                }
            }
        }
        return true;
    }

    // assume current node satisfied vertex constraint
    template <Dimension N>
    int pathSoftConstraintCount(const LowLvNodePtr<N>& current_node, const LowLvNodePtr<N>& new_node, const ConstraintTablePtr<N>& ct) {
        assert(new_node->t_ == current_node->t_ + 1);
        // do static map collide check before check dynamic constraint
        auto dynamic_constraint = ct->ctm_soft_.find(new_node->id_);
        // if no dynamic constraint
        if(dynamic_constraint == ct->ctm_soft_.end()) { return 0; }
        const auto& constraints = dynamic_constraint->second;
        if(constraints.empty()) { return 0; }
        int count_of_conflicts = 0;
        for(const auto& cs : constraints) {
            //std::cout << "ct " << ct << std::endl;
            if(cs->pts_.size() == 1) {
                // vertex constraint check
                // check whether time range match
                if(new_node->t_ >= cs->tz_[0] && new_node->t_ < cs->tz_[1]) {
                    //std::cout << " vc new_node " << new_node->pt_ << " / " << new_node->t_ << std::endl;
                    count_of_conflicts ++;
                }
            } else if(cs->pts_.size() == 2) {
                // edge constraint check
                // check whether is the same edge
                //std::cout << " new node " << new_node->pt_ << " / current node " << current_node->pt_ << std::endl;
                //std::cout << " ct->cf_ pt " << ct->cf_->pt_ << std::endl;
                if (cs->pts_[0] != current_node->pt_) { continue; }

                if(current_node->t_ >= cs->tz_[0] && new_node->t_ <= cs->tz_[1]) {
                    //std::cout << " ec new_node " << current_node->pt_ << "->" << new_node->pt_ << " / " << new_node->t_ << std::endl;
                    count_of_conflicts ++;
                }
            }
        }
        return count_of_conflicts;
    }

    // check whether the two path still have the conflict
    // when a path is replanned, all conflict related to it will be updated, so no need to check validity
    template <Dimension N>
    bool conflictValidCheck(const Id& a1, const Id& a2,
                            const Path<N>& ps1, const Path<N>& ps2,
                            const ConflictPtr<N>& cf) {
        // check whether belong to the same agents, may be deleted
        const auto& max_id = std::max(a1, a2), min_id = std::min(a1, a2);

        const auto& max_id_path = a1 > a2 ? ps1 : ps2;
        const auto& min_id_path = a1 < a2 ? ps1 : ps2;

        const auto& max_id_cs = cf->cs1_->id_ > cf->cs2_->id_ ? cf->cs1_ : cf->cs2_;
        const auto& min_id_cs = cf->cs1_->id_ < cf->cs2_->id_ ? cf->cs1_ : cf->cs2_;

        if(max_id_cs->id_ != max_id || min_id_cs->id_ != min_id) {
            std::cout << " unmatch agent id " << std::endl;
        }
        // check whether conflict still valid
        if(max_id_cs->pts_.size() == 1) {
            if(max_id_cs->tz_[0] != 0 && min_id_cs->tz_[0] != 0) {
                // size check
                if (max_id_cs->tz_[0] >= max_id_path.size()) { return false; }
                // vertex constraint check
                if (max_id_cs->pts_[0] != max_id_path[max_id_cs->tz_[0]]) { return false; }

                // size check
                if (min_id_cs->tz_[0] >= min_id_path.size()) { return false; }
                // vertex constraint check
                if (min_id_cs->pts_[0] != min_id_path[max_id_cs->tz_[0]]) { return false; }
            } else {
                // TODO: considering conflict involve target
            }
        } else {
            // edge constraint check
            // size check
            if (max_id_cs->tz_[0] >= max_id_path.size()-1) { return false; }
            // vertex constraint check
            if (max_id_cs->pts_[0] != max_id_path[max_id_cs->tz_[0]] || max_id_cs->pts_[1] != max_id_path[max_id_cs->tz_[0]+1]) { return false; }

            if (min_id_cs->tz_[0] >= min_id_path.size()-1) { return false; }
            // vertex constraint check
            if (min_id_cs->pts_[0] != min_id_path[min_id_cs->tz_[0]] || min_id_cs->pts_[1] != min_id_path[min_id_cs->tz_[0]+1]) { return false; }

        }
        return true;
    }

}

#endif //FREENAV_CONFLICT_H
