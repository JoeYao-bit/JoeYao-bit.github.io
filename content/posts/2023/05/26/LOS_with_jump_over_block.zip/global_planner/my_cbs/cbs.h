//
// Created by yaozhuo on 2023/6/19.
//

#ifndef FREENAV_MY_CBS_H
#define FREENAV_MY_CBS_H

#include "single_path_planning.h"

namespace freeNav::CBS {

    template <Dimension N>
    using Instance = std::pair<Pointi<N>, Pointi<N> >;

    template<Dimension N>
    Cost calculatePathCost(const Path<N>& path, bool ignore_wait = false) {
        Cost cost = path.size();
        if(!ignore_wait) return cost;
        for(int i=0; i<path.size()-1; i++) {
            if(path[i] == path[i+1]) {
                cost --;
            }
        }
        return cost;
    }

    template<Dimension N>
    Cost calculatePathCost(const Paths<N>& paths, bool ignore_wait = false) {
        Cost cost;
        for(const auto& path : paths) {
            cost += calculatePathCost(path, ignore_wait);
        }
        return cost;
    }

    template <Dimension N>
    using Instances = std::vector<Instance<N> >;

    template <Dimension N>
    class ConflictBasedSearch {
    public:

        enum UpLvSolverType {Astar, AstarFocal};

        explicit ConflictBasedSearch(DimensionLength* dim, const IS_OCCUPIED_FUNC<N>& isoc)
                     : dim_(dim), isoc_(isoc) {}

        // find solution for current start and target pairs, if failed, return empty set
        Paths<N> solve(const Instances<N> & ists, const Id& step_upper_bound) {
            step_upper_bound_ = step_upper_bound;
            ps_.resize(ists.size());
            ips_.resize(ists.size());
            if(!setStartAndTarget(ists)) {
                std::cout << "a agent have no legal path under static maps " << std::endl;
                return {};
            }
            if(haveSameStartOrTargetCheck(ists)) {
                std::cout << "two agents have same start or target, exit " << std::endl;
                return {};
            }
            if(ists_.size() == 1) {
                std::cout << " only one agent, MAPF exit" << std::endl;
                return ps_;
            }
            UpLvNodePtr<N> root = generateRootNode(); // add root node to open set
            root->open_handle_ = open_set_.push(root);
            root->focal_handle_ = open_set_focal_.push(root);
            //std::cout << " finish generate " << ips_.size() << " initial paths " << std::endl;
            int count = 0;
            while(!open_set_.empty()) {
                //std::cout << count << "th iteration, open set size = " << open_set_.size();
                const auto& current_node = selectUpNode();
                //std::cout << ", get current node " << current_node << ", cf size = " << current_node->cfs_.size() << std::endl;
                retrievePathsFromUpLvNode(current_node); // update ps_ to paths under its constraint and its parent nodes' constraint
                if(generateChildNode(current_node)) {
                    printHyperNode(current_node);
                    if(!resultLegalCheck()) {}
                    std::cout << " after " << count << " iteration " << std::endl;
                    return ps_;
                }
                count ++;
                //if(count >= 1) { break; }
            }
            std::cout << " after " << count << " iteration " << std::endl;
//            if(finish_set_.empty()) { return {}; }
//            else {
//                auto retv = finish_set_.top();
//                finish_set_.pop();
//                retrievePathsFromUpLvNode(retv);
//                if(!resultLegalCheck()) {}
//                return ps_;
//            }
            if(!resultLegalCheck()) {}
            return ps_;
        }

        bool resultLegalCheck() {
            bool is_legal = true;
            for(int a1=0; a1<ps_.size(); a1++) {
                for(int a2=a1+1; a2<ps_.size(); a2++) {
                    ConflictPtrs<2> cfs = determineConflictBetweenTwoPath(a1, a2, ps_[a1], ps_[a2], step_upper_bound_);
                    if(!cfs.empty()) {
                        std::cout << " result path have conflict between " << a1 << " and " << a2 << std::endl;
                        is_legal = false;
                    }
                }
            }
            if(is_legal) { std::cout << " result path find no conflict !" << std::endl; }
            return is_legal;
        }

        void printConstraint(const ConstraintPtr<N>& cs) {
            std::cout << "id[" << cs->id_ << "]";
            if(cs->pts_.size() == 1) {
                std::cout << "{" << cs->pts_[0] << "}<" << cs->tz_[0] << ", " << cs->tz_[1] << "><-";
            } else if(cs->pts_.size() == 2) {
                std::cout << "{" << cs->pts_[0] << "," << cs->pts_[1] << "}" << "<" << cs->tz_[0] << ", " << cs->tz_[1] << "><-";
            }
        }

        void printHyperNode(const UpLvNodePtr<N>& node_ptr) {
            auto current_node = node_ptr;
            std::cout << "depth = " << node_ptr->depth_ << std::endl;
            while(current_node != nullptr) {
                if(current_node->cs_ == nullptr) { break; }
                printConstraint(current_node->cs_);
                current_node = current_node->pa_;
            }
            std::cout << std::endl;
        }

    private:

        bool haveSameStartOrTargetCheck(const Instances<N> & ists) {
            // same start check
            Id new_id;
            boost::unordered_set<Id> id_set;
            for(const auto& ist : ists) {
                new_id = PointiToId(ist.first, dim_);
                if(id_set.find(new_id) != id_set.end()) { return true; }
            }
            id_set.clear();
            // same target check
            for(const auto& ist : ists) {
                new_id = PointiToId(ist.second, dim_);
                if(id_set.find(new_id) != id_set.end()) { return true; }
            }
            return false;
        }

        void retrievePathsFromUpLvNode(const UpLvNodePtr<N>& node_ptr) {
            std::vector<bool> retrieve_table(ists_.size(), false);
            auto current_node = node_ptr;
            while(current_node != nullptr) {
                if(current_node->cs_ == nullptr) { break; }
                for(int i=0; i<retrieve_table.size(); i++) {
                    if(retrieve_table[i]) { continue; }
                    if(current_node->cs_->id_ != i) { continue; }
                    retrieve_table[i] = true;
                    ps_[i] = current_node->rpps_;
                }
                current_node = current_node->pa_;
            }
            // for path that never been modified under constraint, copy from initial paths
            for(int id=0; id<retrieve_table.size(); id++) {
                if(!retrieve_table[id]) {
                    ps_[id] = ips_[id];
                }
            }
        }

        // pop out node with minimum future cost expectation
        UpLvNodePtr<N> selectUpNode() {
            UpLvNodePtr<N> top_node;
            //std::cout << " open_set_ size " << open_set_.size() << " / focal size " << open_set_focal_.size() << std::endl;
            switch (solver_type_) {
                case UpLvSolverType::Astar:
                default:
                    top_node = open_set_.top();
                    open_set_.pop();
                    break;
                case UpLvSolverType::AstarFocal:
                    if(open_set_focal_.empty()) {
                        open_set_.top()->focal_handle_ = open_set_focal_.push(open_set_.top());
                    }
                    top_node = open_set_focal_.top();
                    open_set_focal_.pop();
                    open_set_.erase(top_node->open_handle_);
                    //std::cout << " pop focal cost = " << top_node->cc_f_ + top_node->fc_f_ << std::endl;
                    break;
            }

//            if(!open_set_.empty()) {
//                std::cout << " second  cc_ " << open_set_.top()->cc_ << std::endl;
//            } else {
//                std::cout << std::endl;
//            }
            return top_node;
        }

        // select conflict with minimum time index
        ConflictPtr<N> selectConflictFromNode(const UpLvNodePtr<N>& node_ptr) {
            Id min_time = MAX<Id>;
            ConflictPtr<N> retv;
            for(const auto& cf : node_ptr->cfs_) {
                auto cf_min_time = std::min(cf->cs1_->tz_[0], cf->cs2_->tz_[0]);
                if (cf_min_time < min_time) {
                    min_time = cf_min_time;
                    retv = cf;
                }
            }
            //std::cout << "-- select cf with cs ";
            //printConstraint(retv->cs1_);
            //std::cout << " / ";
            //printConstraint(retv->cs2_);
            //std::cout << std::endl;
            return retv;
        }

        // new up level node inherit conflict from previous node
        // do not inherit conflict that involve new planned agent
        void inheritConflict(const ConflictPtrs<N>& parent_cfs, ConflictPtrs<N>& child_cfs, const Id& exclude_agent) {
            child_cfs.clear();
            for(const auto& pcf : parent_cfs) {
                if(pcf->cs1_->id_ == exclude_agent || pcf->cs2_->id_ == exclude_agent) { continue; }
                child_cfs.push_back(pcf);
            }
        }

        // check new conflict between the new path and previous determined paths
        void determineNewConflict(const UpLvNodePtr<N>& node_ptr) {
            assert(!node_ptr->rpps_.empty());
            const auto& agent_with_new_path = node_ptr->cs_->id_;
            for(int i=0; i<ps_.size(); i++) {
                if(i != agent_with_new_path) {
                    const ConflictPtrs<N>& new_cf = determineConflictBetweenTwoPath(i, agent_with_new_path, ps_[i], node_ptr->rpps_, step_upper_bound_);
                    node_ptr->cfs_.insert(node_ptr->cfs_.end(), new_cf.begin(), new_cf.end());
                }
            }
        }

        // update instances but still the same space
        // return whether current instance have legal single agent path for each agent
        bool setStartAndTarget(const Instances<N> & ists) {
            ists_ = ists;
            updateStaticHeuristicTable();
            return calculateInitialPaths();
        }

        UpLvNodePtr<N> generateRootNode() {
            assert(ips_.size() == ists_.size());
            UpLvNodePtr<N> root = std::make_shared<UpLvNode<N> >(nullptr, nullptr);
            for(int ag1=0; ag1<ists_.size(); ag1++) {
                for(int ag2=ag1+1; ag2<ists_.size(); ag2++) {
                    ConflictPtrs<N> cf = determineConflictBetweenTwoPath(ag1, ag2, ips_[ag1], ips_[ag2], step_upper_bound_);
                    root->cfs_.insert(root->cfs_.end(), cf.begin(), cf.end());
                }
            }
            calculateCostOfNode(root); // calculate future cost and current cost of the hyper node
            return root;
        }

        // TODO: considering only update path that from current constraint's time stamp, do not update previous partial path
        //       to save computational resource
        bool updateUpLvNodePath(const UpLvNodePtr<N>& node_ptr) {
            assert(node_ptr->cs_ != nullptr);
            SpaceTimeAStarPtr<2> planner = std::make_shared<SpaceTimeAStar<2> >();
            const auto& agent_id = node_ptr->cs_->id_;
            planner->setHeuristicTable(hts_[agent_id]);
            ConstraintTablePtr<2> ct = std::make_shared<ConstraintTable<2> >(agent_id, dim_, isoc_);
            // when generate new paths from the same parent node, do not need to update ps_
            // set other path as conflict to avoid other path still conflict with new path
            ct->setPathsConstraint(ps_, agent_id);//, true); // without this will be very solve under lots of agents, set to soft constraint
            ct->setUpLvNodePtrConstraints(node_ptr, agent_id); // infinite loop in here
            auto path = planner->solve(ists_[agent_id].first, ists_[agent_id].second, ct, step_upper_bound_);
            node_ptr->rpps_ = path;
            return !(path.empty());
        }

        // return whether should terminate CBS
        bool tryExpandChildNode(const UpLvNodePtr<N>& node) {
            if(updateUpLvNodePath(node)) {
                //std::cout << " left expand success " << std::endl;
                // add new conflict to child node
                determineNewConflict(node);
                //printHyperNode(node_left);
                if (node->cfs_.empty()) {
                    ps_[node->cs_->id_] = node->rpps_;
                    //std::cout << " find solution with sum of cost = " << calculatePathCost(ps_) << std::endl;
                    //finish_set_.push(node_left);
                    return true;
                }
                calculateCostOfNode(node);
                switch (solver_type_) {
                    case UpLvSolverType::Astar:
                    default:
                        node->open_handle_ = open_set_.push(node);
                        break;
                    case UpLvSolverType::AstarFocal:
                        node->open_handle_ = open_set_.push(node);
                        // check whether insert to focal set
                        const auto& min_node = open_set_.top();
                        auto min_cost = min_node->cc_ + min_node->fc_;
                        if(open_set_focal_.empty()) {
                            open_set_.top()->focal_handle_ = open_set_focal_.push(open_set_.top());
                            //std::cout << " new focal cost = " << open_set_.top()->cc_f_ + open_set_.top()->fc_f_ << std::endl;
                        } else {
                            if (node->cc_ + node->fc_ <= min_cost * focal_w_) {
                                node->focal_handle_ = open_set_focal_.push(node);
                                //std::cout << " new focal cost = " << open_set_.top()->cc_f_ + open_set_.top()->fc_f_ << std::endl;
                            }
                        }
                        break;
                }
            }
            return false;
        }

        // return whether reach target (find no conflict path for each agent)
        bool generateChildNode(const UpLvNodePtr<N>& node_ptr) {
            // pick the most important conflict from node
            ConflictPtr<N> conflict = selectConflictFromNode(node_ptr);
            // when a path is replanned, all conflict related to it will be updated, so no need to check validity
            //if(!conflictValidCheck(conflict->cs1_->id_, conflict->cs2_->id_, ps_[conflict->cs1_->id_], ps_[conflict->cs2_->id_], conflict)) {
            //    std::cout << " invalid conflict in upper node "; printHyperNode(node_ptr); // find no invalid conflict
            //}

            // split the current conflict into two constraints
            const ConstraintPtr<N>& left  = conflict->cs1_;
            UpLvNodePtr<N> node_left  = std::make_shared<UpLvNode<N> >(node_ptr, left);
            inheritConflict(node_ptr->cfs_, node_left->cfs_,  left->id_);
            if(tryExpandChildNode(node_left)) { return true; }

            const ConstraintPtr<N>& right = conflict->cs2_;
            UpLvNodePtr<N> node_right = std::make_shared<UpLvNode<N> >(node_ptr, right);
            inheritConflict(node_ptr->cfs_, node_right->cfs_, right->id_);
            if(tryExpandChildNode(node_right)) { return true; }

            return false;
        }

        bool calculateInitialPaths() {
            ips_.clear();
            ips_.reserve(ists_.size());
            for(int i=0; i<ists_.size(); i++) {
                ConstraintTablePtr<2> ct = std::make_shared<ConstraintTable<2> >(i, dim_, isoc_);
                SpaceTimeAStarPtr<2> planner = std::make_shared<SpaceTimeAStar<2> >();
                planner->setHeuristicTable(hts_[i]);
                auto path = planner->solve(ists_[i].first, ists_[i].second, ct, step_upper_bound_);
                if(path.empty()) { return false; }
                ips_.push_back(path);
            }
            ps_ = ips_;
//            std::cout << "initial paths: " << std::endl;
//            for(const auto& ips : ips_) {
//                std::cout << ips << std::endl;
//            }
            return true;
        }

        void updateStaticHeuristicTable() {
            hts_.clear();
            hts_.reserve(ists_.size());
            for(const auto& ist : ists_) {
                hts_.push_back(calculateStaticHeuristic(ist.first, ist.second, dim_, isoc_));
            }
        }

        // including current cost and future cost
        void calculateCostOfNode(const UpLvNodePtr<N>& node_ptr) {
            // calculate current cost
            switch (solver_type_) {
                case Astar:
                default:
                    node_ptr->cc_ = 0;
                    node_ptr->fc_ = node_ptr->cfs_.size(); // future conflicts that need to be solved
                    break;
                case AstarFocal:
                    node_ptr->cc_ = 0;
                    for(int id=0; id<ists_.size(); id++) {
                        if(node_ptr->cs_ != nullptr && node_ptr->cs_->id_ == id) {
                            node_ptr->cc_ += node_ptr->rpps_.size();
                        } else {
                            node_ptr->cc_ += ps_[id].size();
                        }
                    }
                    //std::cout << " node_ptr->cc_ " << node_ptr->cc_ << std::endl;
                    node_ptr->fc_ = 0;
                    node_ptr->cc_f_ = 0;
                    node_ptr->fc_f_ = node_ptr->cfs_.size();
                    //std::cout << " new focal cost = " << node_ptr->cc_f_ + node_ptr->fc_f_ << std::endl;
                    break;
            }
        }

        // all conflict under current constraint and history constraints, for each agent
        // for current select UpNode, change when UpNode change
        //std::vector<ConflictPtrs<N> > cfs_;

        // path for each agent, temporary till no conflict
        Paths<N> ps_;

        Paths<N> ips_; // initial paths, single agent optimal path for each agent, do not

        Instances<N> ists_;// starts and targets for each agent

        HeuristicTables hts_; // heuristic table for each agent, change when agent start or target change

        DimensionLength* dim_; // dimension info of the grid space, static

        IS_OCCUPIED_FUNC<N> isoc_; // is grid occupied state checker, static

        Id step_upper_bound_; // maximum step for a single agent path

        UpLvSolverType solver_type_ = UpLvSolverType::Astar;//Focal;

        HeuristicSortHeap<N, UpLvNode<N> > open_set_; // hyper node that will be expand

        HeuristicSortHeapFocal<N, UpLvNode<N> > open_set_focal_; // hyper node that will be expand

        //HeuristicSortHeap<N, UpLvNode<N>> finish_set_; // hyper nodes that have reach target

        // large the ratio, more faster, smaller the ratio, smaller sum of path cost
        float focal_w_ = 1.2; // focal ratio must >= 1, should be too small

    };

    template <Dimension N>
    using ConflictBasedSearchPtr = std::shared_ptr<ConflictBasedSearch<N> >;

}

#endif //FREENAV_MY_CBS_H
