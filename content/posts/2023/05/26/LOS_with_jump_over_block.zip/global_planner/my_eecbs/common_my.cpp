//
// Created by yaozhuo on 2023/6/30.
//
#include "common_my.h"

namespace freeNav::my_eecbs {

    bool isSamePath(const MAPFPath& p1, const MAPFPath& p2)
    {
        if (p1.size() != p2.size())
            return false;
        for (unsigned i = 0; i < p1.size(); i++)
        {
            if (p1[i].location != p2[i].location)
                return false;
        }
        return true;
    }

}
