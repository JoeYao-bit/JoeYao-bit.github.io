//
// Created by yaozhuo on 2023/6/30.
//

#ifndef FREENAV_COMMON_H
#define FREENAV_COMMON_H

#include <tuple>
#include <map>
#include <list>
#include <vector>
#include <set>
#include <ctime>
#include <fstream>
#include <iostream>     // std::cout, std::fixed
#include <iomanip>      // std::setprecision
#include <boost/heap/pairing_heap.hpp>
#include <boost/unordered_set.hpp>
#include <boost/unordered_map.hpp>
#include "rim_jump/basic_elements/point.h"

namespace freeNav::my_eecbs{

#define MAX_TIMESTEP INT_MAX / 2
#define MAX_COST INT_MAX / 2
#define MAX_NODES INT_MAX / 2

// yz: as a waypoint in path, location is grid index, not coordinate
struct PathEntry
{

    PathEntry(int loc = -1) { location = loc; }
    int location = -1;

};

typedef vector<PathEntry> MAPFPath;


// yz: check whether two path is the same path
bool isSamePath(const MAPFPath& p1, const MAPFPath& p2);

};


#endif //FREENAV_COMMON_H
