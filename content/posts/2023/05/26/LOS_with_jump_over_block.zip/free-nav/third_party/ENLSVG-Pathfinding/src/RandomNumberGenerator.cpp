#include "RandomNumberGenerator.h"

namespace Pathfinding {

RNG global_rng(time(0));

}
