//
// Created by yaozhuo on 2021/9/4.
//

#ifndef _NAVIGATOR_H_
#define _NAVIGATOR_H_

#include <utility>

#include "global_planner.h"
#include "motion_planner.h"
#include "vehicle.h"
#include "environment.h"

namespace freeNav {
    class Navigator {
    public:
        explicit Navigator(GlobalPlannerPtr globalPlanner,
                  MotionPlannerPtr motionPlanner,
                  VehiclePtr vehicle,
                  EnvironmentPtr environment) {
            globalPlanner_ = std::move(globalPlanner);
            motionPlanner_ = std::move(motionPlanner);
            vehicle_       = std::move(vehicle);
            environment_   = std::move(environment);

            globalPlanner_->setEnvironment(environment_);
            globalPlanner_->setVehicle(vehicle_);
            motionPlanner_->setEnvironment(environment_);
            motionPlanner_->setVehicle(vehicle_);
        }

        bool updateGlobalPathViaTarget(MotionStatePtr target_state) {
            if(target_state == nullptr) { return false; }
            globalPlanner_->setTarget(target_state);
            return globalPlanner_->plan(global_path_);
        }

        bool getOptimalControlCmd(ControlCmd & cmd) {
            if(!motionPlanner_->updateTarget(global_path_)) { return false; }
            return motionPlanner_->plan(cmd);
        }

        bool updateEnvironmentAndVehicle(MotionStatePtr motion_state) {
            if(motion_state == nullptr) { return false; }
            return environment_->update() && vehicle_->update(motion_state);
        }

        MotionStates getGlobalPath() const {
            return global_path_;
        }

        GlobalPlannerPtr getGlobalPlanner() const {
            return globalPlanner_;
        }

        MotionPlannerPtr getMotionPlanner() const {
            return motionPlanner_;
        }

        VehiclePtr getVehicle() const {
            return vehicle_;
        }

        EnvironmentPtr getEnvironment() const {
            return environment_;
        }

    private:

        GlobalPlannerPtr globalPlanner_;
        MotionPlannerPtr motionPlanner_;
        VehiclePtr vehicle_;
        EnvironmentPtr environment_;

        MotionStates global_path_;

    };
}

#endif // _NAVIGATOR_H_
