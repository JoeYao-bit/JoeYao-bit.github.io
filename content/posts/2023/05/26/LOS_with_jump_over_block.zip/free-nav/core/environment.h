#ifndef _ENVIRONMENT_H_
#define _ENVIRONMENT_H_

#include "states.h"
#include "rim_jump/basic_elements/point.h"
namespace freeNav {

    class Environment {
    public:

        virtual bool isPositionPassable(const Vec3d &position) = 0;

        virtual bool isLinePassable(const Vec3d &start, const Vec3d &end) = 0;

        virtual bool isPositionOutOfBound(const Vec3d &position) = 0;

        // if update successful, return turn, else return -1
        virtual bool update() = 0;

    private:
        // define the current boundary of the environment the vehicle move in
        // the boundary may change dynamically ...
        // is that essential ?
        Vec3d min_boundary_;
        Vec3d max_boundary_;
    };

    typedef std::shared_ptr<Environment> EnvironmentPtr;

    enum GridState {
        OCCUPIED,
        FREE
    };

    typedef std::vector<GridState> GridMap;


    template <freeNav::RimJump::Dimension N>
    class Grid_Loader {

    public:

        Grid_Loader() {}

        virtual bool isOccupied(const RimJump::Pointi<N> & pt) const = 0;

        virtual void setOccupied(const RimJump::Pointi<N> & pt) = 0;

        virtual RimJump::DimensionLength* getDimensionInfo() {
            return dimen_;
        }

    protected:

        RimJump::DimensionLength dimen_[N];

        /* the editable map */
        //GridMap grid_map_; // storage the whole map take too many space

    };
}
#endif