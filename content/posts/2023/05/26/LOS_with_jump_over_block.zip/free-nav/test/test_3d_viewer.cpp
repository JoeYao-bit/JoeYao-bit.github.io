//
// Created by yaozhuo on 2022/2/26.
//

#include "3d_viewer.h"
#include "octomap/octomap.h"

#include "rim_jump/los_check_for_sparse_check/block_detect.h"
#include "rim_jump/los_check_for_sparse_check/line_of_sight_jump_between_block.h"
#include "color_table.h"
#include "rim_jump/surface_processor/surface_process_jump_block.h"
#include "test_data.h"

Viewer3D* viewer_3d;
ThreadPool viewer_thread(1);

using namespace freeNav::RimJump;

struct timezone tz;
struct timeval tv_pre;
struct timeval tv_after;


#define OCTO_MAP 0
#if OCTO_MAP
OctoMapLoader* oml_ = nullptr;
#else
TextMapLoader_3D* oml_ = nullptr;
#endif

std::shared_ptr<RoadMapGraphBuilder<3> > tgb = nullptr;

//bool (*f1)(const freeNav::RimJump::Pointi<3>&) = is_occupied;
//void (*f2)(const freeNav::RimJump::Pointi<3>&) = set_occupied;


bool plan_finish = false;

freeNav::RimJump::Pointi<3> pt1(3), pt2(3);
freeNav::RimJump::GridPtr<3> sg1 = std::make_shared<Grid<3>>(), sg2 = std::make_shared<Grid<3>>();

std::vector<freeNav::RimJump::Path<3> > paths;
freeNav::RimJump::Path<3> path_rrt, path_jps, path_astar;
freeNav::RimJump::GridPtrs<3> visible_points_start;
freeNav::RimJump::GridPtrs<3> visible_points_target;

// MapTestConfig_Full4 // run out of space, shrink space 4
// MapTestConfig_Simple // success
// MapTestConfig_DA2
// MapTestConfig_DC1 // one bywave, need 8~14s
// MapTestConfig_Complex
// MapTestConfig_A1
// MapTestConfig_FA2
// MapTestConfig_A5
auto config = MapTestConfig_Complex;

std::string file_path = "/home/yaozhuo/code/free-nav/resource/binary/fr_campus.vis";

int main() {
#if OCTO_MAP
    oml_ = new OctoMapLoader("/home/yaozhuo/code/free-nav/resource/map/fr_campus.bt", 6);
#else
    std::string map_path = config.at("map_path");
    oml_ = new TextMapLoader_3D(map_path, atoi(config.at("shrink_level").c_str())); // shrink to enable load
    file_path = config.at("vis_path");
#endif
    // load octomap
    auto is_occupied = [](const freeNav::RimJump::Pointi<3> & pt) -> bool { return oml_->isOccupied(pt); };
    auto set_occupied = [](const freeNav::RimJump::Pointi<3> & pt) { oml_->setOccupied(pt); };

    IS_OCCUPIED_FUNC<3> is_occupied_func = is_occupied;

    SET_OCCUPIED_FUNC<3> set_occupied_func = set_occupied;

    gettimeofday(&tv_pre, &tz);
    auto surface_processor = std::make_shared<SurfaceProcessorSparseWithJumpBlock<3> >(oml_->getDimensionInfo(),
                                                                                      is_occupied_func,
                                                                                      set_occupied_func,
                                                                                      oml_->occ_voxels_,
                                                                                      oml_->occ_voxel_ids_,
                                                                                       atoi(config.at("minimum_block_width").c_str()),
                                                                                       config.at("block_path").c_str(),
                                                                                       false);

    std::string config_file_path = config.at("config_path");


//    auto surface_processor = std::make_shared<SurfaceProcessorSparseWithJumpBlockOctoMap>(oml_->getDimensionInfo(),
//                                                                                       is_occupied_func,
//                                                                                       set_occupied_func,
//                                                                                       oml_->occ_voxels_,
//                                                                                       oml_->occ_voxel_ids_,
//                                                                                       atoi(config.at("minimum_block_width").c_str()),
//                                                                                       config.at("block_path_oc").c_str(),
//                                                                                       true);

//    auto surface_processor = std::make_shared<SurfaceProcessor<3> >(oml_->getDimensionInfo(),
//                                                                          is_occupied_func,
//                                                                          set_occupied_func);




    std::vector<Pointi<3> > visited_pts;
    Pointis<2> neighbor = GetNeightborOffsetGrids<2>();

    gettimeofday(&tv_after, &tz);


#if WITH_EDGE
    GeneralGraphPathPlannerWithEdge<3> g2p2(tangent_graph);
#else
    //GeneralGraphPathPlannerWithNode<3> g2p2(tangent_graph);
#endif


    ThreadPool tp(1);

    // start (193, 72, 138) target(45, 87, 86) for complex
    // 53, 78, 56) to (52, 52, 52 simple
    // (94, 89, 126)->(160, 59, 94) complex
    // 94, 89, 126)->(160, 59, 94
    // 630, 230, 134)->(739, 278, 121 A5
    // 761, 254, 117)->(85, 90, 171 A5
    // start (44, 108, 199) target(234, 14, 20) complex los
    // start (857, 74, 25) target(85, 327, 121) A5 los
    // 38, 130, 204)->(138, 26, 0 Complex Los
    // set viewer
    viewer_3d = new Viewer3D();
    viewer_3d->start_[0] = 38;
    viewer_3d->start_[1] = 130;
    viewer_3d->start_[2] = 204;
    viewer_3d->target_[0] = 138;
    viewer_3d->target_[1] = 26;
    viewer_3d->target_[2] = 0;

    //std::cout << "MAX<uint_least32_t> " << MAX<uint_least32_t> << std::endl;

    viewer_thread.Schedule([&]{
        viewer_3d->init();

        pangolin::Var<bool> menu_octomap = pangolin::Var<bool>("menu.OctoMap",false, true);
        pangolin::Var<bool> menu_occupied_surface = pangolin::Var<bool>("menu.DrawOctomap",true, true);
        pangolin::Var<bool> menu_path = pangolin::Var<bool>("menu.DrawPath",true, true);
        //pangolin::Var<bool> menu_grid("menu.GridOn",false, true);
        pangolin::Var<bool> menu_vlo = pangolin::Var<bool>("menu.DrawVoxelLine",false, true);
        pangolin::Var<bool> menu_gv = pangolin::Var<bool>("menu.DrawGreyVoxel",false, true);
        pangolin::Var<bool> menu_state = pangolin::Var<bool>("menu.DrawStart&Target",true, true);
        pangolin::Var<bool> menu_bound = pangolin::Var<bool>("menu.DrawBoundary",false, true);
        pangolin::Var<bool> menu_tangent_candidate_grid = pangolin::Var<bool>("menu.DrawTangentCandidate",false, true);
        pangolin::Var<bool> menu_set_state = pangolin::Var<bool>("menu.SetStartNow",true, true);
        pangolin::Var<bool> menu_start_plan = pangolin::Var<bool>("menu.StartPlan",false, false);
        pangolin::Var<bool> menu_rimjump = pangolin::Var<bool>("menu.RimJump*",true, true);
        pangolin::Var<bool> menu_dijk = pangolin::Var<bool>("menu.Dijkstra",true, true);
        pangolin::Var<bool> menu_astar = pangolin::Var<bool>("menu.Astar",true, true);
        pangolin::Var<bool> menu_theta = pangolin::Var<bool>("menu.Theta*",true, true);
        pangolin::Var<bool> menu_rrt = pangolin::Var<bool>("menu.RRT",true, true);
        pangolin::Var<bool> menu_jps = pangolin::Var<bool>("menu.JPS",true, true);
        pangolin::Var<bool> menu_visible_start = pangolin::Var<bool>("menu.visible_of_start",false, true);
        pangolin::Var<bool> menu_visible_target = pangolin::Var<bool>("menu.visible_of_target",false, true);
        pangolin::Var<bool> menu_surface_grids = pangolin::Var<bool>("menu.surface_grids",false, true);
        pangolin::Var<bool> menu_draw_block = pangolin::Var<bool>("menu.draw_block",false, true);
        // 3D Mouse handler requires depth testing to be enabled
        glEnable(GL_DEPTH_TEST);
        // Issue specific OpenGl we might need
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        // Define Camera Render Object (for view / scene browsing)
        viewer_3d->mViewpointX = oml_->getDimensionInfo()[0]/2;
        viewer_3d->mViewpointY = oml_->getDimensionInfo()[1]/2;
        // set parameters for the window
        pangolin::OpenGlRenderState s_cam(
                pangolin::ProjectionMatrix(1024,768,viewer_3d->mViewpointF,viewer_3d->mViewpointF,512,389,0.1,2000),
//                pangolin::ModelViewLookAt(0,0, 4*oml_->getDimensionInfo()[2],//2*planner_3d->space_3d->max_z,
//                                          0,0,0, 0.0,-1.0, 0.0)
                pangolin::ModelViewLookAt(0,0, oml_->getDimensionInfo()[2],//2*planner_3d->space_3d->max_z,
                                          0,0,0, 0.0,-1.0, 0.0)
        );
        MyHandler3D* handle_3d = new MyHandler3D(s_cam);
        // Add named OpenGL viewport to window and provide 3D Handler
        pangolin::View& d_cam = pangolin::CreateDisplay()
                .SetBounds(0.0, 1.0, pangolin::Attach::Pix(175), 1.0, -1024.0f/768.0f)
                .SetHandler(handle_3d);
        pangolin::OpenGlMatrix Twc;
        Twc.SetIdentity();

        while( !pangolin::ShouldQuit() )
        {
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            d_cam.Activate(s_cam);
            glClearColor(1.0f,1.0f,1.0f,1.0f);
            if(menu_vlo) viewer_3d->show_line_for_voxel = true;
            else viewer_3d->show_line_for_voxel = false; ;
            if(menu_gv) viewer_3d->show_grey_voxel = true;
            else viewer_3d->show_grey_voxel = false;
            //if(menu_grid) DrawGrid();

            if(menu_octomap && oml_ != nullptr) {
#if OCTO_MAP
                viewer_3d->DrawOctoMapGrid(*oml_);
#else
                viewer_3d->DrawVoxelMap(*oml_);
#endif
            }

            // if(menu_surface) DrawSurface(planner_3d->space_3d);
            if(menu_state) {
//                viewer_3d->DrawPoint(viewer_3d->start_[0], viewer_3d->start_[1], viewer_3d->start_[2]);
//                viewer_3d->DrawPoint(viewer_3d->target_[0], viewer_3d->target_[1], viewer_3d->target_[2]);
//                viewer_3d->DrawLine(viewer_3d->start_[0], viewer_3d->start_[1], viewer_3d->start_[2],
//                                    viewer_3d->target_[0], viewer_3d->target_[1], viewer_3d->target_[2]);
            }
            if(menu_start_plan) {
                menu_start_plan = false;
                viewer_3d->under_planning = true;
                tp.Schedule([&]{

                    std::cout << "-- start RimJump " << std::endl;
                    std::cout << "start " << viewer_3d->start_ << " target" << viewer_3d->target_ << std::endl;
                    plan_finish = false;
                    sg1->pt_ = viewer_3d->start_;
                    sg1->id_ = PointiToId<3>(sg1->pt_, oml_->getDimensionInfo());
                    sg2->pt_ = viewer_3d->target_;
                    sg2->id_ = PointiToId<3>(sg2->pt_, oml_->getDimensionInfo());
                    plan_finish = true;

                });
            }
            if(menu_set_state) viewer_3d->viewer_set_start = true;
            else viewer_3d->viewer_set_start = false;

            if(menu_tangent_candidate_grid) {
                for(const auto& grid_ptr : surface_processor->getTangentCandidates()) {
                    viewer_3d->DrawPoint(grid_ptr->pt_[0], grid_ptr->pt_[1], grid_ptr->pt_[2]);
                }
            }
            if(menu_bound) {
                viewer_3d->DrawBound(0, oml_->getDimensionInfo()[0], 0, oml_->getDimensionInfo()[1], 0, oml_->getDimensionInfo()[2]);
            }
            if(menu_visible_start) {
                for(const auto& vp : visible_points_start) {
                    viewer_3d->DrawPoint(vp->pt_[0], vp->pt_[1], vp->pt_[2]);
                    viewer_3d->DrawLine(viewer_3d->start_, vp->pt_, 0, 1, 0);

                }
            }
            if(menu_surface_grids) {
                for(const auto& sfp : surface_processor->getSurfaceGrids()) {
                    viewer_3d->DrawPoint(sfp->pt_[0], sfp->pt_[1], sfp->pt_[2]);
                }
            }
            if(menu_visible_target) {
                for(const auto& vp : visible_points_target) {
                    viewer_3d->DrawPoint(vp->pt_[0], vp->pt_[1], vp->pt_[2]);
                    viewer_3d->DrawLine(viewer_3d->start_, vp->pt_, 0, 0, 1);
                }
            }
            if(menu_rimjump) {
                //viewer_3d->drawRoadMapEdges(pps);
                for(const auto& path : paths) {
                    viewer_3d->DrawPath(path);
                }
            }
            if(menu_rrt) {
                viewer_3d->DrawPath(path_rrt);
            }
            if(menu_jps) {
                viewer_3d->DrawPath(path_jps);
            }
            if(menu_astar) {
                viewer_3d->DrawPath(path_astar);
            }
            if(menu_draw_block) {
                for(int i=0; i< surface_processor->block_detector_->all_block_ptrs_.size(); i++) {
                    const auto& block_ptr =  surface_processor->block_detector_->all_block_ptrs_[i];
                    viewer_3d->DrawBlock(block_ptr->min_, block_ptr->max_,
                                         ((int)COLOR_TABLE[i%30][0])/255., ((int)COLOR_TABLE[i%30][1])/255., ((int)COLOR_TABLE[i%30][2])/255.);
                }
            }
            pangolin::FinishFrame();
        }

    });
    return 0;
}

