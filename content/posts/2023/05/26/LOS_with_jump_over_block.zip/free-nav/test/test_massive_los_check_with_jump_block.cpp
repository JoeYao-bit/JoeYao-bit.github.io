//
// Created by yaozhuo on 2023/5/7.
//

#include "rim_jump/los_check_for_sparse_check/line_of_sight_jump_between_block.h"
#include "rim_jump/surface_processor/surface_process_jump_block.h"
#include "test_data.h"
#include "3d_textmap/voxel_loader.h"
#include "massive_test_interfaces.h"

using namespace freeNav::RimJump;

auto is_char_occupied = [](const char& value) -> bool {
    if (value != '.' && value != 'G' && value != 'S') return true;
    return false;
};

struct timezone tz;
struct timeval tv_pre;
struct timeval tv_after;

bool SingleMapLOSCheck3D(const SingleMapTestConfig <3> &map_test_config, int repeat = 100, int test_cases = 10000, int random_select = 100) {

    TextMapLoader_3D tl(map_test_config.at("map_path"));
    std::cout << "start SingleMapTest from map " << map_test_config.at("map_path") << std::endl;
    auto dimension = tl.getDimensionInfo();

    IS_OCCUPIED_FUNC<3> is_occupied_func;

    SET_OCCUPIED_FUNC<3> set_occupied_func;

    auto is_occupied = [&tl](const freeNav::RimJump::Pointi<3> &pt) -> bool { return tl.isOccupied(pt); };
    is_occupied_func = is_occupied;

    auto set_occupied = [&tl](const freeNav::RimJump::Pointi<3> &pt) { tl.setOccupied(pt); };
    set_occupied_func = set_occupied;

    auto surface_processor =
            std::make_shared<SurfaceProcessorSparseWithJumpBlock<3> >(dimension, is_occupied_func, set_occupied_func,
                                                                      tl.occ_voxels_,
                                                                      tl.occ_voxel_ids_,
                                                                      atoi(map_test_config.at("minimum_block_width").c_str()),
                                                                      map_test_config.at("block_path").c_str(),
                                                                      false);

    auto surface_processor_octomap =
            std::make_shared<SurfaceProcessorSparseWithJumpBlockOctoMap>(dimension, is_occupied_func, set_occupied_func,
                                                                      tl.occ_voxels_,
                                                                      tl.occ_voxel_ids_,
                                                                      atoi(map_test_config.at("minimum_block_width").c_str()),
                                                                         map_test_config.at("block_path_oc").c_str(),//map_test_config.at("block_path").c_str(),
                                                                      false);

    auto los_with_jump_block = [&](const freeNav::RimJump::Pointi<3> &start,
                                    const freeNav::RimJump::Pointi<3> &target,
                                    freeNav::RimJump::Pointis<3> &path,
                                    Statistic &statistic,
                                    OutputStream &output_stream) {
        path.clear();
        statistic.clear();
        output_stream.clear();
        path.push_back(start);
        path.push_back(target);
        bool is_collide;
        Pointis<3> visited_pt;
        int count_of_block;
        gettimeofday(&tv_pre, &tz);
        for(int i=0; i<repeat; i++) {
            is_collide = surface_processor->lineCrossObstacleWithVisitedPoint(start, target, visited_pt, count_of_block);
        }
        gettimeofday(&tv_after, &tz);
        double los_cost = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
        statistic.push_back(los_cost);
        std::stringstream ss;
        ss << "JumpBlock " << start[0]  << " " << start[1]  << " " << start[2] << " "
                           << target[0] << " " << target[1] << " " << target[2] << " ";
        ss << los_cost << " " << visited_pt.size() << " " << count_of_block << " " << (is_collide ? 1 : 0) << " " ;
        output_stream = ss.str();
    };

    auto los_with_jump_block_octomap = [&](const freeNav::RimJump::Pointi<3> &start,
                                           const freeNav::RimJump::Pointi<3> &target,
                                           freeNav::RimJump::Pointis<3> &path,
                                           Statistic &statistic,
                                           OutputStream &output_stream) {
        path.clear();
        statistic.clear();
        output_stream.clear();
        path.push_back(start);
        path.push_back(target);
        bool is_collide;
        Pointis<3> visited_pt;
        int count_of_block;
        gettimeofday(&tv_pre, &tz);
        for(int i=0; i<repeat; i++) {
            is_collide = surface_processor_octomap->lineCrossObstacleWithVisitedPoint(start, target, visited_pt, count_of_block);
        }
        gettimeofday(&tv_after, &tz);
        double los_cost = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
        statistic.push_back(los_cost);
        std::stringstream ss;
        ss << "JumpBlockOcM " << start[0]  << " " << start[1]  << " " << start[2] << " "
           << target[0] << " " << target[1] << " " << target[2] << " ";
        ss << los_cost << " " << visited_pt.size() << " " << count_of_block << " " << (is_collide ? 1 : 0) << " " ;
        output_stream = ss.str();
    };

    Pointis<2> neighbor = GetNeightborOffsetGrids<2>();
    auto los_raw = [&](const freeNav::RimJump::Pointi<3> &start,
                       const freeNav::RimJump::Pointi<3> &target,
                       freeNav::RimJump::Pointis<3> &path,
                       Statistic &statistic,
                       OutputStream &output_stream) {
        path.clear();
        statistic.clear();
        output_stream.clear();
        path.push_back(start);
        path.push_back(target);
        bool is_collide;
        int count_of_block = 0;
        gettimeofday(&tv_pre, &tz);
        for(int i=0; i<repeat; i++) {
            is_collide = LineCrossObstacle(start, target, is_occupied_func, neighbor);
        }
        gettimeofday(&tv_after, &tz);
        double los_cost = (tv_after.tv_sec - tv_pre.tv_sec)*1e3 + (tv_after.tv_usec - tv_pre.tv_usec)/1e3;
        statistic.push_back(los_cost);
        std::stringstream ss;
        ss << "Raw " << start[0]  << " " << start[1]  << " " << start[2] << " "
                     << target[0] << " " << target[1] << " " << target[2] << " ";
        Line<3> line(start, target);
        ss << los_cost << " " << line.step << " " << count_of_block << " " << (is_collide ? 1 : 0) << " ";
        output_stream = ss.str();
    };

    Point2PointPathPlannings<3, Pointi<3>, Pointi<3> > path_plannings = {los_with_jump_block,
                                                                         los_with_jump_block_octomap,
                                                                         los_raw
                                                                         };
    StatisticSS statisticss;
    OutputStreamSS output_streamss;
    SceneTest3D_Random(surface_processor, test_cases, path_plannings, statisticss, output_streamss, random_select);

    std::ofstream os(map_test_config.at("los_output_path"));
    //os << "TYPE START_X START_Y TARGET_X TARGET_Y PATH_LENGTH RESET_TIME INITIAL_TIME SEARCH_TIME" << std::endl;
    for (const auto &multi_method_output : output_streamss) {
        for (const auto method_output : multi_method_output) {
            os << method_output << std::endl;
        }
    }
    os.close();
    return true;
};


template<freeNav::RimJump::Dimension N>
bool SingleMapLosTestDataAnalysis(const SingleMapTestConfig <N> &test_data, int planner_count = -1) {
    const auto &data_path = test_data.at("los_output_path");
    std::cout << " map minimum block width = " << test_data.at("minimum_block_width") << std::endl;
    std::ifstream fin(data_path);
    std::string line;
    std::vector<double> time_costs;
    std::vector<double> visited_pt_counts;
    std::vector<double> visited_block_counts;
    std::vector<int> collision_free_line_counts;
    std::vector<std::pair<Pointi<N>, Pointi<N>> > checked_lines;

    int expected_size = 6 + 2*N;
    int count_of_line = 0;
    bool find_all_type = false;
    std::vector<std::string> type_names;
    while (getline(fin, line)) {
        //std::cout << line << std::endl;
        std::istringstream sin(line);
        std::vector<string> fields;
        std::string field;
        while (sin.rdbuf()->in_avail() != 0) {
            sin >> field;
            fields.push_back(field);
        }
        if (fields.size() != expected_size) {
            std::cout << " FATAL: field.size() " << field.size() << " != expected_size " << expected_size
                      << std::endl;
            return false;
        }
        if(type_names.size() == 0) {
            type_names.push_back(fields[0]);
        } else if(!find_all_type && type_names[0] != fields[0]) {
            type_names.push_back(fields[0]);
        } else if(type_names[0] == fields[0]) {
            find_all_type = true;
        }
        time_costs.push_back(atof(fields[1 + 2*N].c_str()));
        visited_pt_counts.push_back(atof(fields[2 + 2*N].c_str()));
        visited_block_counts.push_back(atof(fields[3 + 2*N].c_str()));
        collision_free_line_counts.push_back(atoi(fields[4 + 2*N].c_str()));
        Pointi<N> start, target;

        start[0] = atoi(fields[3 + 2*N].c_str());
        for(int i=0; i<N; i++) {
            start[i] = atoi(fields[1 + i].c_str());
            target[i] = atoi(fields[1 + N + i].c_str());
        }
        checked_lines.push_back(std::make_pair(start, target));
        //std::cout << "line collied ? " << fields[3 + 2*N] << std::endl;
        //std::cout << " line " << start << "->" << target << std::endl;
        count_of_line ++;
    }
    std::vector<double> each_time_cost(type_names.size(), 0);
    std::vector<double> each_visited_pt(type_names.size(), 0);
    std::vector<double> each_visited_block(type_names.size(), 0);
    std::vector<int> each_collision_free_line(type_names.size(), 0);

    for(int i=0; i<time_costs.size(); i++) {
        each_time_cost[i%type_names.size()] += time_costs[i];
    }
    for(int i=0; i<visited_pt_counts.size(); i++) {
        each_visited_pt[i%type_names.size()] += visited_pt_counts[i];
    }
    for(int i=0; i<visited_block_counts.size(); i++) {
        each_visited_block[i%type_names.size()] += visited_block_counts[i];
    }
    for(int i=0; i<collision_free_line_counts.size(); i++) {
        each_collision_free_line[i%type_names.size()] += collision_free_line_counts[i];
    }
    // check whether have the same result
    for(int i=0; i<collision_free_line_counts.size()/type_names.size(); i++) {
        auto pre_val = collision_free_line_counts[i*type_names.size()];
        for(int j=i*type_names.size()+1; j<(i+1)*type_names.size(); j++) {
            if(collision_free_line_counts[j] != pre_val) {
                std::cout << type_names[j-i*type_names.size()] << " los check" << checked_lines[j].first << "->" << checked_lines[j].second << " not the same " << std::endl;
            }
        }
    }
    for(int i=0; i<type_names.size(); i++) {
        std::cout << type_names[i] << " mean time cost " << type_names.size()*each_time_cost[i]/count_of_line << "\t / "
                  << "visited pt " << type_names.size()*each_visited_pt[i]/count_of_line << " / "
                    << "visited block " << type_names.size()*each_visited_block[i]/count_of_line << " / "
                    << " collide ratio " << 100.*type_names.size()*each_collision_free_line[i]/((double)count_of_line) << "%"
                  << std::endl;
    }
    return true;
}

// los check between random uniform sample free grid
SingleMapTestConfigs<3> configs = {
            MapTestConfig_Simple,
            MapTestConfig_Complex, // AC
            MapTestConfig_A1, // AC
            MapTestConfig_A2, // AC
            MapTestConfig_A3, // AC
            MapTestConfig_A4, // AC
            MapTestConfig_A5, // AC

            MapTestConfig_BC1, //
            MapTestConfig_BC2, // AC
            MapTestConfig_DA1, // AC
            MapTestConfig_DA2, // AC
            MapTestConfig_DB1, // AC
            MapTestConfig_DB2, // AC

            MapTestConfig_DC1, // AC
            MapTestConfig_DC2, // AC
            MapTestConfig_EB1, // AC
            MapTestConfig_EB2, // AC
            MapTestConfig_EC1, // AC
            MapTestConfig_EC2, // AC
            //MapTestConfig_Full4
};

int main() {
    for(const auto& config : configs) {
        SingleMapLOSCheck3D(config, 10,10000);
    }
    for(const auto& config : configs) {
        std::cout << config.at("map_name") << ":" << std::endl;
        SingleMapLosTestDataAnalysis<3>(config);
        std::cout << std::endl;
    }
}
